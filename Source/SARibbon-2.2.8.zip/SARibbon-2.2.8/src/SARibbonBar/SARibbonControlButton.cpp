﻿#include "SARibbonControlButton.h"

SARibbonControlButton::SARibbonControlButton(QWidget* parent) : QToolButton(parent)
{
}

SARibbonControlButton::~SARibbonControlButton()
{
}
SARibbonControlToolButton::SARibbonControlToolButton(QWidget* parent) : QToolButton(parent)
{
}

SARibbonControlToolButton::~SARibbonControlToolButton()
{
}
