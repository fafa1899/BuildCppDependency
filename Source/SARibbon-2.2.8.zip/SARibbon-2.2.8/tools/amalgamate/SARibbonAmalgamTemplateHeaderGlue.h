// This file provides an extra level of indirection for the @remap in the template
#include "SARibbonAmalgamTemplatePublicHeaders.h"
