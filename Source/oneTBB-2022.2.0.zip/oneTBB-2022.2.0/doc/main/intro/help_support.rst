.. _help_support:

Getting Help and Support
========================


.. container:: section


   .. rubric:: Getting Technical Support
      :class: sectiontitle

   For general information about |short_name| technical support, product
   updates, user forums, FAQs, tips and tricks and other support
   questions, see `oneTBB Support <https://github.com/uxlfoundation/oneTBB/blob/master/SUPPORT.md>`_.
