.. _System_Requirements:

System Requirements
*******************

|full_name| supports a broad list of hardware platforms, operating systems, and compilers. 
For details, see `oneTBB System Requirements <https://github.com/uxlfoundation/oneTBB/blob/master/SYSTEM_REQUIREMENTS.md>`_.