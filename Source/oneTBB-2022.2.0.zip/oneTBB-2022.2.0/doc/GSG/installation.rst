.. _installation:

Installation
============

See the `installation instructions <https://github.com/uxlfoundation/oneTBB/blob/master/INSTALL.md>`_ 
that will help you to install |short_name| successfully.  