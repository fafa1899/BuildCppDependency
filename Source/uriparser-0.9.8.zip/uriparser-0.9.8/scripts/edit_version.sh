#! /usr/bin/env bash
kwrite \
	include/uriparser/Uri.h \
	include/uriparser/UriBase.h \
	configure.ac \
	ChangeLog \
	&
