---
orphan: true
---

% Copyright Contributors to the OpenImageIO project.
% SPDX-License-Identifier: CC-BY-4.0

:::{only} not latex
# Copyright Notice
:::

The code that implements OpenImageIO is licensed under the Apache 2.0 license
for all new code contributed after July 1, 2023, and any code from prior to
that date which has been relicensed under Apache-2.0 by their owners. The tiny
amount of code (approximately 0.1%) that remains in OpenImageIO source files
dating from prior to July 1, 2023 that has not been relicensed by their owners
is licensed under the BSD 3-clause (also sometimes known as "new BSD" or
"modified BSD") license.

```{eval-rst}
  .. include:: ../../LICENSE.md
```

This manual and other text documentation about OpenImageIO are licensed under
the Creative Commons Attribution 4.0 International License.

```{image} figures/CC-BY.png
```

<http://creativecommons.org/licenses/by/4.0/>

OpenImageIO incorporates code from several other software packages with
compatible licenses. Copies of their licenses are reproduced here:
<https://github.com/AcademySoftwareFoundation/OpenImageIO/blob/main/THIRD-PARTY.md>
