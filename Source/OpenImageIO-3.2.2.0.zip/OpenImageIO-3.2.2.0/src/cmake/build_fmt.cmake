# Copyright Contributors to the OpenImageIO project.
# SPDX-License-Identifier: Apache-2.0
# https://github.com/AcademySoftwareFoundation/OpenImageIO

######################################################################
# fmt by hand!
######################################################################

set_cache (fmt_BUILD_VERSION 12.1.0 "fmt version for local builds")
set (fmt_GIT_REPOSITORY "https://github.com/fmtlib/fmt")
set (fmt_GIT_TAG "${fmt_BUILD_VERSION}")
set_cache (fmt_GIT_COMMIT "407c905e45ad75fc29bf0f9bb7c5c2fd3475976f"
           "fmt commit hash to verify tag against")
# Note: fmt doesn't put "v" in front of version for its git tags

build_dependency_with_cmake(fmt
    VERSION         ${fmt_BUILD_VERSION}
    GIT_REPOSITORY  ${fmt_GIT_REPOSITORY}
    GIT_TAG         ${fmt_GIT_TAG}
    GIT_COMMIT      ${fmt_GIT_COMMIT}
    CMAKE_ARGS
        # -D CMAKE_INSTALL_LIBDIR=lib
        # Don't build unnecessary parts of fmt
        -D FMT_DOC=OFF
        -D FMT_TEST=OFF
    )

# Signal to caller that we need to find again at the installed location
set (fmt_REFIND TRUE)
set (fmt_REFIND_ARGS CONFIG)
set (fmt_VERSION ${fmt_BUILD_VERSION})
