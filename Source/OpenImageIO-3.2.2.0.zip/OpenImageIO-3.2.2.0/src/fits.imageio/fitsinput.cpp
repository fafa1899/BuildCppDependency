// Copyright Contributors to the OpenImageIO project.
// SPDX-License-Identifier: Apache-2.0
// https://github.com/AcademySoftwareFoundation/OpenImageIO


#include <cctype>
#include <cmath>
#include <cstdlib>
#include <limits>

#include "fits_pvt.h"

#include <OpenImageIO/filesystem.h>
#include <OpenImageIO/fmath.h>
#include <OpenImageIO/strutil.h>


OIIO_PLUGIN_NAMESPACE_BEGIN


// Obligatory material to make this a recognizable imageio plugin
OIIO_PLUGIN_EXPORTS_BEGIN

OIIO_EXPORT int fits_imageio_version = OIIO_PLUGIN_VERSION;

OIIO_EXPORT const char*
fits_imageio_library_version()
{
    return nullptr;
}

OIIO_EXPORT ImageInput*
fits_input_imageio_create()
{
    return new FitsInput;
}

OIIO_EXPORT const char* fits_input_extensions[] = { "fits", nullptr };

OIIO_PLUGIN_EXPORTS_END



bool
FitsInput::valid_file(const std::string& filename) const
{
    FILE* fd = Filesystem::fopen(filename, "rb");
    if (!fd)
        return false;

    char magic[6] = { 0 };
    bool ok = (fread(magic, 1, 6, fd) == 6) && !strncmp(magic, "SIMPLE", 6);

    fclose(fd);
    return ok;
}



bool
FitsInput::open(const std::string& name, ImageSpec& spec)
{
    // saving 'name' for later use
    m_filename = name;

    // checking if the file exists and can be opened in READ mode
    m_fd = Filesystem::fopen(m_filename, "rb");
    if (!m_fd) {
        errorfmt("Could not open file \"{}\"", m_filename);
        return false;
    }

    // checking if the file is FITS file
    char magic[6] = { 0 };
    if (fread(magic, 1, 6, m_fd) != 6 || strncmp(magic, "SIMPLE", 6)) {
        errorfmt("{} isn't a FITS file", m_filename);
        close();
        return false;
    }
    // moving back to the start of the file
    if (Filesystem::fseek(m_fd, 0, SEEK_SET)) {
        errorfmt("Seek error");
        close();
        return false;
    }

    if (!subimage_search()) {
        close();
        return false;
    }

    if (!set_spec_info()) {
        close();
        return false;
    }

    spec = m_spec;
    return true;
};



bool
FitsInput::read_native_scanline(int subimage, int miplevel, int y, int z,
                                void* data)
{
    lock_guard lock(*this);
    if (!seek_subimage(subimage, miplevel))
        return false;

    // we return true just to support 0x0 images
    if (!m_naxes)
        return true;

    std::vector<unsigned char> data_tmp(m_spec.scanline_bytes());

    if (!planar_channels()) {
        size_t scanline_off = (size_t(z) * m_spec.height
                               + (m_spec.height - 1 - y))
                              * size_t(m_spec.scanline_bytes());
        if (Filesystem::fseek(m_fd, scanline_off, SEEK_CUR)) {
            errorfmt("Seek error");
            return false;
        }
        size_t n = fread(&data_tmp[0], 1, m_spec.scanline_bytes(), m_fd);
        if (n != m_spec.scanline_bytes()) {
            if (feof(m_fd))
                errorfmt("Hit end of file unexpectedly (offset={}, scanline {})",
                         ftell(m_fd), y);
            else
                errorfmt("read error");
            return false;  // Read failed
        }
    } else {
        // Channels are stored as separate contiguous width * height (or
        // width * height * depth for NAXIS=4) blocks rather than interleaved,
        // so we must gather one row from each block and interleave them into
        // the scanline buffer.
        size_t comp_size   = m_spec.format.size();
        size_t row_bytes   = size_t(m_spec.width) * comp_size;
        size_t plane_bytes = row_bytes * size_t(m_spec.height)
                             * size_t(m_spec.depth);
        size_t row_off = (size_t(z) * m_spec.height + (m_spec.height - 1 - y))
                         * row_bytes;
        std::vector<unsigned char> chan_row(row_bytes);
        for (int c = 0; c < m_spec.nchannels; ++c) {
            fsetpos(m_fd, &m_filepos);
            if (Filesystem::fseek(m_fd, size_t(c * plane_bytes) + row_off,
                                  SEEK_CUR)) {
                errorfmt("Seek error");
                return false;
            }
            size_t n = fread(&chan_row[0], 1, row_bytes, m_fd);
            if (n != row_bytes) {
                if (feof(m_fd))
                    errorfmt(
                        "Hit end of file unexpectedly (offset={}, scanline {})",
                        ftell(m_fd), y);
                else
                    errorfmt("read error");
                return false;  // Read failed
            }
            for (int x = 0; x < m_spec.width; ++x)
                memcpy(&data_tmp[(size_t(x) * m_spec.nchannels + c) * comp_size],
                       &chan_row[size_t(x) * comp_size], comp_size);
        }
    }

    // in FITS image data is stored in big-endian so we have to switch to
    // little-endian on little-endian machines
    if (littleendian()) {
        if (m_spec.format == TypeDesc::USHORT
            || m_spec.format == TypeDesc::SHORT)
            swap_endian((unsigned short*)&data_tmp[0],
                        data_tmp.size() / sizeof(unsigned short));
        else if (m_spec.format == TypeDesc::UINT
                 || m_spec.format == TypeDesc::INT)
            swap_endian((unsigned int*)&data_tmp[0],
                        data_tmp.size() / sizeof(unsigned int));
        else if (m_spec.format == TypeDesc::FLOAT)
            swap_endian((float*)&data_tmp[0], data_tmp.size() / sizeof(float));
        else if (m_spec.format == TypeDesc::DOUBLE)
            swap_endian((double*)&data_tmp[0],
                        data_tmp.size() / sizeof(double));
    }

    memcpy(data, &data_tmp[0], data_tmp.size());

    // after reading scanline we set file pointer to the start of image data
    fsetpos(m_fd, &m_filepos);
    return true;
};



bool
FitsInput::seek_subimage(int subimage, int miplevel)
{
    if (miplevel != 0)
        return false;
    if (subimage < 0 || subimage >= (int)m_subimages.size())
        return false;

    if (subimage == m_cur_subimage) {
        return true;
    }

    // We're about to overwrite m_spec and the file position, so give up the
    // current subimage first. Failing partway then leaves us on none, rather
    // than on one whose spec was never validated.
    m_cur_subimage = -1;
    m_spec         = ImageSpec();
    if (Filesystem::fseek(m_fd, m_subimages[subimage].offset, SEEK_SET)) {
        errorfmt("Seek error");
        return false;
    }

    if (!set_spec_info()) {
        // Nor keep the spec of an HDU we refused: spec() would report it,
        // and read_scanline() would size its buffer from it.
        m_spec = ImageSpec();
        return false;
    }

    m_cur_subimage = subimage;
    return true;
}



bool
FitsInput::set_spec_info()
{
    keys.clear();
    // FITS spec doesn't say anything about color space or
    // number of channels, so we read all images as if they
    // all were one-channel images
    m_spec = ImageSpec(0, 0, 1, TypeDesc::UNKNOWN);

    // reading info about current subimage
    if (!read_fits_header())
        return false;

    // now we can get the current position in the file
    // this is the start of the image data
    // we will need it in the read_native_scanline method
    fgetpos(m_fd, &m_filepos);

    if (m_bitpix == 8)
        m_spec.set_format(TypeDesc::UCHAR);
    else if (m_bitpix == 16)
        m_spec.set_format(TypeDesc::SHORT);
    else if (m_bitpix == 32)
        m_spec.set_format(TypeDesc::INT);
    else if (m_bitpix == -32)
        m_spec.set_format(TypeDesc::FLOAT);
    else if (m_bitpix == -64)
        m_spec.set_format(TypeDesc::DOUBLE);

    // Validate dimensions and implied size for non-empty images. FITS permits
    // an empty (0x0) primary HDU, which we pass through as metadata-only.
    if (m_spec.width > 0 && m_spec.height > 0) {
        if (m_spec.format == TypeDesc::UNKNOWN) {
            errorfmt("Unsupported FITS BITPIX value {}", m_bitpix);
            return false;
        }
        if (!check_open(m_spec, { 0, 1 << 20, 0, 1 << 20, 0, 1 << 16, 0, 12 }))
            return false;
        if (!check_compression_ratio(m_spec, Filesystem::file_size(m_filename)))
            return false;
    }
    return true;
}



bool
FitsInput::close(void)
{
    if (m_fd)
        fclose(m_fd);
    init();
    return true;
}



bool
FitsInput::read_fits_header(void)
{
    // Arbitrary limit to the number of header blocks in a file before we
    // conclude that it's a corrupted file. There are FITS files that *could*
    // have more headers, but there is no real limit, so we just pick one.
    // Somebody will let us know if they ever encounter a real world file that
    // intentionally exceeds this.
    constexpr int max_blocks = 10000;

    for (int h = 0; h < max_blocks; ++h) {
        std::string fits_header(HEADER_SIZE, 0);

        // we read whole header at once
        if (fread(&fits_header[0], 1, HEADER_SIZE, m_fd) != HEADER_SIZE) {
            if (feof(m_fd))
                errorfmt("Hit end of file unexpectedly (offset={})",
                         ftell(m_fd));
            else
                errorfmt("read error");
            return false;  // Read failed
        }

        bool found_end = false;
        for (int i = 0; i < CARDS_PER_HEADER; ++i) {
            std::string card(CARD_SIZE, 0);
            // reading card number i
            memcpy(&card[0], &fits_header[i * CARD_SIZE], CARD_SIZE);

            std::string keyname, value;
            fits_pvt::unpack_card(card, keyname, value);

            // END means that this is end of the FITS header
            // we can now add to the ImageSpec COMMENT, HISTORY and HIERARCH keys
            if (keyname == "END") {
                // removing white spaces that we use to separate lines of comments
                // from the end ot the string
                m_comment  = m_comment.substr(0,
                                              m_comment.size() - m_sep.size());
                m_history  = m_history.substr(0,
                                              m_history.size() - m_sep.size());
                m_hierarch = m_hierarch.substr(0, m_hierarch.size()
                                                      - m_sep.size());
                add_to_spec("Comment", m_comment);
                add_to_spec("History", m_history);
                add_to_spec("Hierarch", m_hierarch);
                found_end = true;
                break;
            }

            if (keyname == "SIMPLE" || keyname == "XTENSION")
                continue;

            // setting up some important fields
            // m_bitpix - format of the data (eg. bpp)
            // m_naxes - number of axes
            // width, height and depth of the image
            if (keyname == "BITPIX") {
                m_bitpix = Strutil::stoi(&card[10]);
                continue;
            }
            if (keyname == "NAXIS") {
                m_naxes = Strutil::stoi(&card[10]);
                // NAXIS is 0-999 per the FITS spec. Reject bogus values before
                // sizing m_naxis, so a negative or huge count can't wrap/blow
                // up the resize into an OOM or crash.
                if (m_naxes < 0 || m_naxes > 999) {
                    errorfmt("Invalid FITS NAXIS value {}", m_naxes);
                    return false;
                }
                m_naxis.resize(m_naxes);
                continue;
            }
            if (Strutil::starts_with(keyname, "NAXIS")) {
                int i = Strutil::stoi(keyname.substr(5));
                if (i > 0 && i <= m_naxes)
                    m_naxis[i - 1] = Strutil::stoi(&card[10]);
                continue;
            }
            if (keyname == "ORIENTAT") {
                add_to_spec("Orientation", value);
                continue;
            }
            if (keyname == "DATE") {
                add_to_spec("DateTime", convert_date(value));
                continue;
            }
            if (keyname == "COMMENT") {
                m_comment += (value + m_sep);
                continue;
            }
            if (keyname == "HISTORY") {
                m_history += (value + m_sep);
                continue;
            }
            if (keyname == "HIERARCH") {
                m_hierarch += (value + m_sep);
                continue;
            }

            Strutil::to_lower(keyname);  // make lower case
            if (keyname.size() >= 1)
                keyname[0] = toupper(keyname[0]);
            add_to_spec(keyname, value);
        }

        // Fix up dimensions
        while (m_naxes > 1 && m_naxis[m_naxes - 1] == 1) {
            --m_naxes;
        }
        if (m_naxes < 0 || m_naxes > 4) {
            errorfmt("Number of data axes {} not supported", m_naxes);
            return false;
        }
        m_spec.nchannels = 1;
        m_spec.depth     = 1;
        if (m_naxes == 0 || m_naxis[0] == 0) {
            m_spec.width = m_spec.height = 0;
        } else if (m_naxes == 1) {
            m_spec.width  = m_naxis[0];
            m_spec.height = 1;
        } else if (m_naxes == 2) {
            m_spec.width  = m_naxis[0];
            m_spec.height = m_naxis[1];
        } else if (m_naxes == 3 && m_naxis[2] <= 4) {
            // 3D, small number of most-slowly changing dimension: color
            // image, one full width x height plane per channel (NAXIS3 =
            // nchannels). This is the only real-world FITS color-cube
            // convention -- see the git history for how we know that.
            m_spec.width     = m_naxis[0];
            m_spec.height    = m_naxis[1];
            m_spec.nchannels = m_naxis[2];
        } else if (m_naxes == 3) {
            // 3D, no small axis: volume
            m_spec.width  = m_naxis[0];
            m_spec.height = m_naxis[1];
            m_spec.depth  = m_naxis[2];
        } else if (m_naxes == 4) {
            // 4D volume+color: NAXIS1-3 are x,y,z and NAXIS4 = nchannels,
            // one full-resolution volume per channel. No real-world
            // convention to confirm this against (unlike the 3D color case
            // above), but it's the natural extension of the same pattern:
            // the slowest-varying axis is the channel axis.
            m_spec.width     = m_naxis[0];
            m_spec.height    = m_naxis[1];
            m_spec.depth     = m_naxis[2];
            m_spec.nchannels = m_naxis[3];
        } else {
            errorfmt("Don't know now to read {}-channel FITS image", m_naxes);
            return false;
        }
        m_spec.full_width  = m_spec.width;
        m_spec.full_height = m_spec.height;
        m_spec.full_depth  = m_spec.depth;

        m_spec.attribute("oiio:subimages", (int)m_subimages.size());
        assign_channel_names();

        // if (m_spec.width < 1 || m_spec.height < 1 || m_spec.depth < 1 ||
        //     m_spec.nchannels < 1) {
        //     errorfmt("Don't know now to read empty (0 pixel) FITS image");
        //     return false;
        // }

        // if we didn't found END keyword in current header, we read next one
        if (found_end)
            return true;
    }

    errorfmt("No END keyword found after reading {} header blocks", max_blocks);
    return false;  // Never found the end
}



void
FitsInput::add_to_spec(const std::string& keyname, const std::string& value)
{
    // we don't add empty keys (or keys with empty values) to ImageSpec
    if (!keyname.size() || !value.size())
        return;

    // COMMENT, HISTORY, HIERARCH and DATE keywords we save AS-IS
    bool speckey = (keyname == "Comment" || keyname == "History"
                    || keyname == "Hierarch");
    if (speckey || keyname == "DateTime") {
        m_spec.attribute(keyname, value);
        return;
    }

    // converting string to float or integer
    bool isNumSign = (value[0] == '+' || value[0] == '-' || value[0] == '.');
    if (isdigit(value[0]) || isNumSign) {
        float val = Strutil::stof(value);
        if (val >= float(std::numeric_limits<int>::min())
            && val < -float(std::numeric_limits<int>::min()) && val == (int)val)
            m_spec.attribute(keyname, (int)val);
        else
            m_spec.attribute(keyname, val);
    } else
        m_spec.attribute(keyname, value);
}



void
FitsInput::assign_channel_names()
{
    m_spec.default_channel_names();
    if (m_spec.nchannels <= 1)
        return;

    // Which physical FITS axis (1-based) is the channel axis, so we know
    // which CTYPEn/FILTERn-style keywords describe it?
    int axis = 0;
    if (m_naxes == 3)
        axis = 3;
    else if (m_naxes == 4)
        axis = 4;  // volume+color: channel is the slowest-varying axis
    if (!axis)
        return;

    // The FITS WCS standard defines a STOKES axis (polarization) with fixed
    // integer codes per plane. If that's what this axis is, decode the
    // per-plane values via the standard linear WCS mapping and use the Stokes
    // names as channel names.
    std::string ctype = m_spec.get_string_attribute(
        Strutil::format("Ctype{}", axis));
    if (Strutil::iequals(ctype, "STOKES")) {
        // Standard FITS WCS linear axis mapping and Stokes codes, see:
        // https://fits.gsfc.nasa.gov/standard40/fits_standard40aa.pdf
        static const std::map<int, const char*> stokes_names
            = { { 1, "I" },   { 2, "Q" },   { 3, "U" },   { 4, "V" },
                { -1, "RR" }, { -2, "LL" }, { -3, "RL" }, { -4, "LR" },
                { -5, "XX" }, { -6, "YY" }, { -7, "XY" }, { -8, "YX" } };
        float crval    = m_spec.get_float_attribute(Strutil::format("Crval{}",
                                                                    axis),
                                                    1.0f);
        float crpix    = m_spec.get_float_attribute(Strutil::format("Crpix{}",
                                                                    axis),
                                                    1.0f);
        float cdelt    = m_spec.get_float_attribute(Strutil::format("Cdelt{}",
                                                                    axis),
                                                    1.0f);
        bool all_found = true;
        std::vector<std::string> names(m_spec.nchannels);
        for (int c = 0; c < m_spec.nchannels && all_found; ++c) {
            int code  = int(std::lround(crval + (c + 1 - crpix) * cdelt));
            auto find = stokes_names.find(code);
            if (find == stokes_names.end())
                all_found = false;
            else
                names[c] = find->second;
        }
        if (all_found) {
            for (int c = 0; c < m_spec.nchannels; ++c)
                m_spec.channelnames[c] = names[c];
            return;
        }
    }

    // No standard WCS description of the axis. Some pipelines instead tag
    // each plane with an informal FILTERn or BANDn keyword (e.g. FILTER1,
    // FILTER2, FILTER3 giving the name of the filter used for that plane).
    // This isn't part of the FITS standard, just a convention we've seen in
    // the wild, so only trust it if every plane has one.
    for (const char* prefix : { "Filter", "Band" }) {
        std::vector<std::string> names(m_spec.nchannels);
        bool all_found = true;
        for (int c = 0; c < m_spec.nchannels && all_found; ++c) {
            std::string key = Strutil::format("{}{}", prefix, c + 1);
            auto* param     = m_spec.find_attribute(key, TypeDesc::STRING);
            if (!param)
                all_found = false;
            else
                names[c] = *(const char**)param->data();
        }
        if (all_found) {
            for (int c = 0; c < m_spec.nchannels; ++c)
                m_spec.channelnames[c] = names[c];
            return;
        }
    }
}



bool
FitsInput::subimage_search()
{
    // saving position of the file, just for safe)
    fpos_t fpos;
    fgetpos(m_fd, &fpos);

    // starting reading headers from the beginning of the file
    if (Filesystem::fseek(m_fd, 0, SEEK_SET)) {
        errorfmt("Seek error");
        return false;
    }

    // we search for subimages by reading whole header and checking if it
    // starts by "SIMPLE" keyword (primary header is always image header)
    // or by "XTENSION= 'IMAGE   '" (it is image extensions)
    std::string hdu(HEADER_SIZE, 0);
    size_t offset = 0;
    while (fread(&hdu[0], 1, HEADER_SIZE, m_fd) == HEADER_SIZE) {
        if (!strncmp(&hdu[0], "SIMPLE", 6)
            || !strncmp(&hdu[0], "XTENSION= 'IMAGE   '", 20)) {
            fits_pvt::Subimage newSub;
            newSub.number = m_subimages.size();
            newSub.offset = offset;
            m_subimages.push_back(newSub);
        }
        offset += HEADER_SIZE;
    }
    fsetpos(m_fd, &fpos);
    return true;
}



std::string
FitsInput::convert_date(const std::string& date)
{
    using Strutil::stoi;
    std::string ndate;
    if (date[4] == '-') {
        // YYYY-MM-DDThh:mm:ss convention is used since 1 January 2000
        ndate = Strutil::fmt::format("{:04d}:{:02d}:{:02d}", stoi(&date[0]),
                                     stoi(&date[5]), stoi(&date[8]));
        if (date.size() >= 11 && date[10] == 'T')
            ndate += Strutil::fmt::format(" {:02d}:{:02d}:{:02d}",
                                          stoi(&date[11]), stoi(&date[14]),
                                          stoi(&date[17]));
        return ndate;
    }

    if (date[2] == '/') {
        // DD/MM/YY convention was used before 1 January 2000
        ndate = Strutil::fmt::format("19{:02d}:{:02d}:{:02d} 00:00:00",
                                     stoi(&date[6]), stoi(&date[3]),
                                     stoi(&date[0]));
        return ndate;
    }
    // unrecognized format
    return date;
}

OIIO_PLUGIN_NAMESPACE_END
