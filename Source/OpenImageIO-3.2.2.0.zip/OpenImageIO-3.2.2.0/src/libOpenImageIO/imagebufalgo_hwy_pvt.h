// Copyright Contributors to the OpenImageIO project.
// SPDX-License-Identifier: Apache-2.0
// https://github.com/AcademySoftwareFoundation/OpenImageIO

#pragma once

#include <OpenImageIO/half.h>
#include <OpenImageIO/imagebuf.h>
#include <OpenImageIO/imagebufalgo_util.h>
#include <OpenImageIO/imageio.h>
#include <algorithm>
#include <cstddef>
#include <hwy/contrib/math/math-inl.h>
#include <hwy/highway.h>
#include <tuple>
#include <type_traits>

OIIO_NAMESPACE_BEGIN

// Alias for Highway's namespace for convenience
namespace hn = hwy::HWY_NAMESPACE;

// -----------------------------------------------------------------------
// ImageBuf local pixel helpers (header-only)
// -----------------------------------------------------------------------

template<class ByteT> struct HwyLocalPixelsView {
    ByteT* base           = nullptr;
    size_t pixel_bytes    = 0;
    size_t scanline_bytes = 0;
    int xbegin            = 0;
    int ybegin            = 0;
    int nchannels         = 0;
};

inline HwyLocalPixelsView<std::byte>
HwyPixels(ImageBuf& img)
{
    const ImageSpec& spec = img.spec();
    return { reinterpret_cast<std::byte*>(img.localpixels()),
             static_cast<size_t>(img.pixel_stride()),
             static_cast<size_t>(img.scanline_stride()),
             img.xbegin(),
             img.ybegin(),
             spec.nchannels };
}

inline HwyLocalPixelsView<const std::byte>
HwyPixels(const ImageBuf& img)
{
    const ImageSpec& spec = img.spec();
    return { reinterpret_cast<const std::byte*>(img.localpixels()),
             static_cast<size_t>(img.pixel_stride()),
             static_cast<size_t>(img.scanline_stride()),
             img.xbegin(),
             img.ybegin(),
             spec.nchannels };
}

template<class T, class ByteT>
inline bool
ChannelsContiguous(const HwyLocalPixelsView<ByteT>& v, int nchannels) noexcept
{
    return size_t(nchannels) * sizeof(T) == v.pixel_bytes;
}

template<class ByteT>
inline ByteT*
PixelBase(const HwyLocalPixelsView<ByteT>& v, int x, int y) noexcept
{
    return v.base + size_t(y - v.ybegin) * v.scanline_bytes
           + size_t(x - v.xbegin) * v.pixel_bytes;
}

template<class T, class ByteT>
inline std::conditional_t<std::is_const_v<ByteT>, const T*, T*>
ChannelPtr(const HwyLocalPixelsView<ByteT>& v, int x, int y, int ch) noexcept
{
    using RetT = std::conditional_t<std::is_const_v<ByteT>, const T, T>;
    return reinterpret_cast<RetT*>(PixelBase(v, x, y) + size_t(ch) * sizeof(T));
}

template<class T, class ByteT>
inline std::conditional_t<std::is_const_v<ByteT>, const T*, T*>
RoiRowPtr(const HwyLocalPixelsView<ByteT>& v, int y, const ROI& roi) noexcept
{
    return ChannelPtr<T>(v, roi.xbegin, y, roi.chbegin);
}


/// Can we use Hwy acceleration with this ImageBuf, over the specified ROI? If
/// not supplied, the ROI defaults to the entire data window of the ImageBuf,
/// and the number of channels defaults to the number of channels in the ROI.
template<typename T>
inline bool
HwySupports(const ImageBuf& A, const ROI& roi = ROI(), int nchannels = 0)
{
    if (nchannels <= 0)
        nchannels = roi.defined() ? roi.nchannels() : A.nchannels();
    return
        // The data type must match what we're looking for (T)
        (A.spec().format.basetype == BaseTypeFromC<T>::value)

        // The ImageBuf has the number of pixels we're expecting
        && A.spec().nchannels == nchannels

        // The scanlines must consist of contiguous pixels in memory (no
        // padding between channels or pixels within a scanline). Note that
        // this test implicitly also ensures "local" in-memory pixels.
        && A.contiguous_scanline()
        // For now, we only support 2D images (no volumes)
        && A.spec().depth == 1
        // The data window must fully encompass the ROI we're operating on
        // (if an ROI was supplied)
        && (!roi.defined() || A.roi().contains(roi));
}


// -----------------------------------------------------------------------
// Type Traits
// -----------------------------------------------------------------------

/// Determine the appropriate SIMD math type for a given result type.
/// Promotes smaller types to float, keeps double as double.
/// Note: uint32_t uses float (not double) for image processing performance.
/// In OIIO, uint32 images are normalized to 0-1 range like uint8/uint16,
/// so float precision (24-bit mantissa) is sufficient and much faster than double.
template<typename T> struct SimdMathType {
    using type = float;
};
template<> struct SimdMathType<double> {
    using type = double;
};

// Half is stored as OIIO::half in memory, but HWY's interleaved load/store uses
// hwy::float16_t lanes.
template<typename T> struct HwyLaneType {
    using type = T;
};
template<> struct HwyLaneType<half> {
    using type = hwy::float16_t;
};
template<typename T> using HwyLaneTypeT = typename HwyLaneType<T>::type;

// Forward declarations (needed for templates that use these helpers before
// their definitions later in this header).
template<class D, typename SrcT>
inline std::tuple<hn::Vec<D>, hn::Vec<D>, hn::Vec<D>, hn::Vec<D>>
LoadInterleaved4Promote(D d, const SrcT* ptr);

template<class D, typename SrcT>
inline std::tuple<hn::Vec<D>, hn::Vec<D>, hn::Vec<D>, hn::Vec<D>>
LoadInterleaved4PromoteN(D d, const SrcT* ptr, size_t count);

template<class D, typename DstT, typename VecMathT, typename VecAlphaLaneT>
inline void StoreInterleaved4RgbAlphaPassthrough(D d, DstT* ptr, VecMathT r,
                                                 VecMathT g, VecMathT b,
                                                 VecAlphaLaneT a_passthrough);

// -----------------------------------------------------------------------
// Load and Promote
// -----------------------------------------------------------------------

/// Load and promote source data to target SIMD type.
/// Handles type conversions from various source formats (uint8_t, int8_t, uint16_t,
/// int16_t, uint32_t, int32_t, uint64_t, int64_t, half, float, double) to the
/// target SIMD computation type.
/// @param d Highway descriptor tag defining the target SIMD type
/// @param ptr Pointer to source data (may be unaligned)
/// @return SIMD vector with promoted values
template<class D, typename SrcT>
inline auto
LoadPromote(D d, const SrcT* ptr)
{
    using MathT = typename D::T;

    if constexpr (std::is_same_v<SrcT, MathT>) {
        return hn::Load(d, ptr);
    } else if constexpr (std::is_same_v<SrcT, half>) {
        using T16 = hwy::float16_t;
        auto d16  = hn::Rebind<T16, D>();
        auto v16  = hn::Load(d16, reinterpret_cast<const T16*>(ptr));
        return hn::PromoteTo(d, v16);
    } else if constexpr (std::is_same_v<SrcT, uint8_t>) {
        auto d_u8       = hn::Rebind<uint8_t, D>();
        auto v_u8       = hn::Load(d_u8, ptr);
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v_u8)));
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 255.0)));
    } else if constexpr (std::is_same_v<SrcT, int8_t>) {
        auto d_i8       = hn::Rebind<int8_t, D>();
        auto v_i8       = hn::Load(d_i8, ptr);
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v_i8)));
        // Normalize: map [-128, 127] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 127.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint16_t>) {
        auto d_u16 = hn::Rebind<uint16_t, D>();
        auto v_u16 = hn::Load(d_u16, ptr);
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v_u16));
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 65535.0)));
    } else if constexpr (std::is_same_v<SrcT, int16_t>) {
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::Load(d_i16, ptr);
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v_i16));
        // Normalize: map [-32768, 32767] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 32767.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint32_t>) {
        // uint32 to float: Load, convert, and normalize to 0-1 range
        auto d_u32      = hn::Rebind<uint32_t, D>();
        auto v_u32      = hn::Load(d_u32, ptr);
        auto v_promoted = hn::ConvertTo(d, v_u32);
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 4294967295.0)));
    } else if constexpr (std::is_same_v<SrcT, int32_t>) {
        // int32 to float: Load, convert, and normalize to approximately [-1.0, 1.0]
        auto d_i32      = hn::Rebind<int32_t, D>();
        auto v_i32      = hn::Load(d_i32, ptr);
        auto v_promoted = hn::ConvertTo(d, v_i32);
        // Normalize: map [-2147483648, 2147483647] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted,
                              hn::Set(d, (MathT)(1.0 / 2147483647.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint64_t>) {
        // uint64 to float: Load and demote to uint32, then convert
        // Note: Precision loss expected for large values (>24 bits)
        auto d_u64 = hn::Rebind<uint64_t, D>();
        auto v_u64 = hn::Load(d_u64, ptr);
        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::DemoteTo(d_u32, v_u64);
        return hn::ConvertTo(d, v_u32);
    } else if constexpr (std::is_same_v<SrcT, int64_t>) {
        // int64 to float: Load and demote to int32, then convert
        auto d_i64 = hn::Rebind<int64_t, D>();
        auto v_i64 = hn::Load(d_i64, ptr);
        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::DemoteTo(d_i32, v_i64);
        return hn::ConvertTo(d, v_i32);
    } else {
        return hn::Zero(d);
    }
}

/// Promote an already-loaded SIMD vector to the math type for `d`.
/// This mirrors LoadPromote()'s conversion and normalization semantics but
/// avoids re-loading from memory (useful for interleaved loads).
template<class D, typename SrcT, typename VecT>
inline auto
PromoteVec(D d, VecT v)
{
    using MathT = typename D::T;
    if constexpr (std::is_same_v<SrcT, MathT>) {
        return v;
    } else if constexpr (std::is_same_v<SrcT, half>) {
        return hn::PromoteTo(d, v);
    } else if constexpr (std::is_same_v<SrcT, uint8_t>) {
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v)));
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 255.0)));
    } else if constexpr (std::is_same_v<SrcT, int8_t>) {
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v)));
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 127.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint16_t>) {
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v));
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 65535.0)));
    } else if constexpr (std::is_same_v<SrcT, int16_t>) {
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v));
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 32767.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint32_t>) {
        auto v_promoted = hn::ConvertTo(d, v);
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 4294967295.0)));
    } else if constexpr (std::is_same_v<SrcT, int32_t>) {
        auto v_promoted = hn::ConvertTo(d, v);
        auto v_norm     = hn::Mul(v_promoted,
                                  hn::Set(d, (MathT)(1.0 / 2147483647.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint64_t>) {
        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::DemoteTo(d_u32, v);
        return hn::ConvertTo(d, v_u32);
    } else if constexpr (std::is_same_v<SrcT, int64_t>) {
        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::DemoteTo(d_i32, v);
        return hn::ConvertTo(d, v_i32);
    } else {
        return hn::Zero(d);
    }
}

/// Load and promote partial source data to target SIMD type.
/// Same as LoadPromote but handles partial vectors (< full lane count).
/// @param d Highway descriptor tag defining the target SIMD type
/// @param ptr Pointer to source data (may be unaligned)
/// @param count Number of elements to load (must be <= lane count)
/// @return SIMD vector with promoted values (undefined in unused lanes)
template<class D, typename SrcT>
inline auto
LoadPromoteN(D d, const SrcT* ptr, size_t count)
{
    using MathT = typename D::T;

    if constexpr (std::is_same_v<SrcT, MathT>) {
        return hn::LoadN(d, ptr, count);
    } else if constexpr (std::is_same_v<SrcT, half>) {
        using T16 = hwy::float16_t;
        auto d16  = hn::Rebind<T16, D>();
        auto v16  = hn::LoadN(d16, reinterpret_cast<const T16*>(ptr), count);
        return hn::PromoteTo(d, v16);
    } else if constexpr (std::is_same_v<SrcT, uint8_t>) {
        auto d_u8       = hn::Rebind<uint8_t, D>();
        auto v_u8       = hn::LoadN(d_u8, ptr, count);
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v_u8)));
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 255.0)));
    } else if constexpr (std::is_same_v<SrcT, int8_t>) {
        auto d_i8       = hn::Rebind<int8_t, D>();
        auto v_i8       = hn::LoadN(d_i8, ptr, count);
        auto v_promoted = hn::ConvertTo(
            d, hn::PromoteTo(hn::Rebind<int32_t, D>(),
                             hn::PromoteTo(hn::Rebind<int16_t, D>(), v_i8)));
        // Normalize: map [-128, 127] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 127.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint16_t>) {
        auto d_u16 = hn::Rebind<uint16_t, D>();
        auto v_u16 = hn::LoadN(d_u16, ptr, count);
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v_u16));
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 65535.0)));
    } else if constexpr (std::is_same_v<SrcT, int16_t>) {
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::LoadN(d_i16, ptr, count);
        auto v_promoted
            = hn::ConvertTo(d, hn::PromoteTo(hn::Rebind<int32_t, D>(), v_i16));
        // Normalize: map [-32768, 32767] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 32767.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint32_t>) {
        // uint32 to float: Load, convert, and normalize to 0-1 range
        auto d_u32      = hn::Rebind<uint32_t, D>();
        auto v_u32      = hn::LoadN(d_u32, ptr, count);
        auto v_promoted = hn::ConvertTo(d, v_u32);
        // Normalize to 0-1 range for image operations
        return hn::Mul(v_promoted, hn::Set(d, (MathT)(1.0 / 4294967295.0)));
    } else if constexpr (std::is_same_v<SrcT, int32_t>) {
        // int32 to float: Load, convert, and normalize to approximately [-1.0, 1.0]
        auto d_i32      = hn::Rebind<int32_t, D>();
        auto v_i32      = hn::LoadN(d_i32, ptr, count);
        auto v_promoted = hn::ConvertTo(d, v_i32);
        // Normalize: map [-2147483648, 2147483647] to approximately [-1.0, 1.0]
        // Clamp INT_MIN so we never produce values < -1.0.
        auto v_norm = hn::Mul(v_promoted,
                              hn::Set(d, (MathT)(1.0 / 2147483647.0)));
        return hn::Max(v_norm, hn::Set(d, (MathT)-1.0));
    } else if constexpr (std::is_same_v<SrcT, uint64_t>) {
        // uint64 to float: Load and demote to uint32, then convert
        auto d_u64 = hn::Rebind<uint64_t, D>();
        auto v_u64 = hn::LoadN(d_u64, ptr, count);
        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::DemoteTo(d_u32, v_u64);
        return hn::ConvertTo(d, v_u32);
    } else if constexpr (std::is_same_v<SrcT, int64_t>) {
        // int64 to float: Load and demote to int32, then convert
        auto d_i64 = hn::Rebind<int64_t, D>();
        auto v_i64 = hn::LoadN(d_i64, ptr, count);
        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::DemoteTo(d_i32, v_i64);
        return hn::ConvertTo(d, v_i32);
    } else {
        return hn::Zero(d);
    }
}

// -----------------------------------------------------------------------
// Demote and Store
// -----------------------------------------------------------------------

/// Demote SIMD values and store to destination type.
/// Handles type conversions from SIMD computation type (float/double) back to
/// various destination formats with proper rounding and clamping for integer types.
/// @param d Highway descriptor tag for the source SIMD type
/// @param ptr Pointer to destination data (may be unaligned)
/// @param v SIMD vector to demote and store
template<class D, typename DstT, typename VecT>
inline void
DemoteStore(D d, DstT* ptr, VecT v)
{
    using MathT = typename D::T;
    using VecD  = hn::Vec<D>;

    if constexpr (std::is_same_v<DstT, MathT>) {
        hn::Store(v, d, ptr);
    } else if constexpr (std::is_same_v<DstT, half>) {
        auto d16 = hn::Rebind<hwy::float16_t, D>();
        auto v16 = hn::DemoteTo(d16, v);
        hn::Store(v16, d16, reinterpret_cast<hwy::float16_t*>(ptr));
    } else if constexpr (std::is_same_v<DstT, uint8_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-255 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)255.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)255.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_u8  = hn::Rebind<uint8_t, D>();
        auto v_u8  = hn::DemoteTo(d_u8, v_i16);
        hn::Store(v_u8, d_u8, ptr);
    } else if constexpr (std::is_same_v<DstT, int8_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from approximately [-1.0, 1.0] range to -128-127 range
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)127.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-128.0);
        VecD v_max     = hn::Set(d, (MathT)127.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_i8  = hn::Rebind<int8_t, D>();
        auto v_i8  = hn::DemoteTo(d_i8, v_i16);
        hn::Store(v_i8, d_i8, ptr);
    } else if constexpr (std::is_same_v<DstT, uint16_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-65535 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)65535.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)65535.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_u16 = hn::Rebind<uint16_t, D>();
        auto v_u16 = hn::DemoteTo(d_u16, vi32);
        hn::Store(v_u16, d_u16, ptr);
    } else if constexpr (std::is_same_v<DstT, int16_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from approximately [-1.0, 1.0] range to -32768-32767 range
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)32767.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-32768.0);
        VecD v_max     = hn::Set(d, (MathT)32767.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        hn::Store(v_i16, d_i16, ptr);
    } else if constexpr (std::is_same_v<DstT, uint32_t>) {
        // float -> uint32: Denormalize from 0-1 to 0-4294967295, round and convert
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-4294967295 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)4294967295.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)4294967295.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::ConvertTo(d_u32, v_clamped);
        hn::Store(v_u32, d_u32, ptr);
    } else if constexpr (std::is_same_v<DstT, int32_t>) {
        // float -> int32: Denormalize from approximately [-1.0, 1.0] to int32 range
        VecD v_val = (VecD)v;
        // Denormalize from approximately [-1.0, 1.0] range to -2147483648-2147483647 range
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)2147483647.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-2147483648.0);
        VecD v_max     = hn::Set(d, (MathT)2147483647.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::ConvertTo(d_i32, v_clamped);
        hn::Store(v_i32, d_i32, ptr);
    } else if constexpr (std::is_same_v<DstT, uint64_t>) {
        // float -> uint64: Promote via uint32
        // Note: Precision loss expected (float has only 24-bit mantissa)
        VecD v_val     = (VecD)v;
        VecD v_rounded = hn::Add(v_val, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_clamped = hn::Max(v_rounded, v_zero);

        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::ConvertTo(d_u32, v_clamped);
        auto d_u64 = hn::Rebind<uint64_t, D>();
        auto v_u64 = hn::PromoteTo(d_u64, v_u32);
        hn::Store(v_u64, d_u64, ptr);
    } else if constexpr (std::is_same_v<DstT, int64_t>) {
        // float -> int64: Promote via int32
        VecD v_val     = (VecD)v;
        VecD v_rounded = hn::Add(v_val, hn::Set(d, (MathT)0.5));

        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::ConvertTo(d_i32, v_rounded);
        auto d_i64 = hn::Rebind<int64_t, D>();
        auto v_i64 = hn::PromoteTo(d_i64, v_i32);
        hn::Store(v_i64, d_i64, ptr);
    }
}

/// Demote a SIMD math vector to the destination lane type (no store).
/// This mirrors DemoteStore()'s rounding/clamping semantics.
template<class D, typename DstT, typename VecT>
inline auto
DemoteVec(D d, VecT v)
{
    using MathT = typename D::T;
    using VecD  = hn::Vec<D>;
    if constexpr (std::is_same_v<DstT, MathT>) {
        return v;
    } else if constexpr (std::is_same_v<DstT, half>) {
        auto d16 = hn::Rebind<hwy::float16_t, D>();
        return hn::DemoteTo(d16, v);
    } else if constexpr (std::is_same_v<DstT, uint8_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)255.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_clamped = hn::Max(v_rounded, hn::Zero(d));
        v_clamped      = hn::Min(v_clamped, hn::Set(d, (MathT)255.0));

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_u8  = hn::Rebind<uint8_t, D>();
        return hn::DemoteTo(d_u8, v_i16);
    } else if constexpr (std::is_same_v<DstT, int8_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)127.0));
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_clamped = hn::Max(v_rounded, hn::Set(d, (MathT)-128.0));
        v_clamped      = hn::Min(v_clamped, hn::Set(d, (MathT)127.0));

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_i8  = hn::Rebind<int8_t, D>();
        return hn::DemoteTo(d_i8, v_i16);
    } else if constexpr (std::is_same_v<DstT, uint16_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)65535.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_clamped = hn::Max(v_rounded, hn::Zero(d));
        v_clamped      = hn::Min(v_clamped, hn::Set(d, (MathT)65535.0));

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_u16 = hn::Rebind<uint16_t, D>();
        return hn::DemoteTo(d_u16, vi32);
    } else if constexpr (std::is_same_v<DstT, int16_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)32767.0));
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_clamped = hn::Max(v_rounded, hn::Set(d, (MathT)-32768.0));
        v_clamped      = hn::Min(v_clamped, hn::Set(d, (MathT)32767.0));

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        return hn::DemoteTo(d_i16, vi32);
    } else if constexpr (std::is_same_v<DstT, uint32_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)4294967295.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_clamped = hn::Max(v_rounded, hn::Zero(d));
        auto d_u32     = hn::Rebind<uint32_t, D>();
        return hn::ConvertTo(d_u32, v_clamped);
    } else if constexpr (std::is_same_v<DstT, int32_t>) {
        VecD v_denorm  = hn::Mul((VecD)v, hn::Set(d, (MathT)2147483647.0));
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_clamped = hn::Max(v_rounded, hn::Set(d, (MathT)-2147483648.0));
        v_clamped      = hn::Min(v_clamped, hn::Set(d, (MathT)2147483647.0));
        auto d_i32     = hn::Rebind<int32_t, D>();
        return hn::ConvertTo(d_i32, v_clamped);
    } else {
        auto d_dst = hn::Rebind<DstT, D>();
        return hn::Zero(d_dst);
    }
}

/// Demote and store partial SIMD values to destination type.
/// Same as DemoteStore but handles partial vectors (< full lane count).
/// @param d Highway descriptor tag for the source SIMD type
/// @param ptr Pointer to destination data (may be unaligned)
/// @param v SIMD vector to demote and store
/// @param count Number of elements to store (must be <= lane count)
template<class D, typename DstT, typename VecT>
inline void
DemoteStoreN(D d, DstT* ptr, VecT v, size_t count)
{
    using MathT = typename D::T;
    using VecD  = hn::Vec<D>;

    if constexpr (std::is_same_v<DstT, MathT>) {
        hn::StoreN(v, d, ptr, count);
    } else if constexpr (std::is_same_v<DstT, half>) {
        auto d16 = hn::Rebind<hwy::float16_t, D>();
        auto v16 = hn::DemoteTo(d16, v);
        hn::StoreN(v16, d16, reinterpret_cast<hwy::float16_t*>(ptr), count);
    } else if constexpr (std::is_same_v<DstT, uint8_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-255 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)255.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)255.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_u8  = hn::Rebind<uint8_t, D>();
        auto v_u8  = hn::DemoteTo(d_u8, v_i16);
        hn::StoreN(v_u8, d_u8, ptr, count);
    } else if constexpr (std::is_same_v<DstT, int8_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from approximately [-1.0, 1.0] range to [-128, 127] range
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)127.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-128.0);
        VecD v_max     = hn::Set(d, (MathT)127.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        auto d_i8  = hn::Rebind<int8_t, D>();
        auto v_i8  = hn::DemoteTo(d_i8, v_i16);
        hn::StoreN(v_i8, d_i8, ptr, count);
    } else if constexpr (std::is_same_v<DstT, uint16_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-65535 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)65535.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)65535.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_u16 = hn::Rebind<uint16_t, D>();
        auto v_u16 = hn::DemoteTo(d_u16, vi32);
        hn::StoreN(v_u16, d_u16, ptr, count);
    } else if constexpr (std::is_same_v<DstT, int16_t>) {
        VecD v_val = (VecD)v;
        // Denormalize from approximately [-1.0, 1.0] range to [-32768, 32767] range
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)32767.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-32768.0);
        VecD v_max     = hn::Set(d, (MathT)32767.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d32   = hn::Rebind<int32_t, D>();
        auto vi32  = hn::ConvertTo(d32, v_clamped);
        auto d_i16 = hn::Rebind<int16_t, D>();
        auto v_i16 = hn::DemoteTo(d_i16, vi32);
        hn::StoreN(v_i16, d_i16, ptr, count);
    } else if constexpr (std::is_same_v<DstT, uint32_t>) {
        // float -> uint32: Denormalize from 0-1 to 0-4294967295, round and convert
        VecD v_val = (VecD)v;
        // Denormalize from 0-1 range to 0-4294967295 range
        VecD v_denorm  = hn::Mul(v_val, hn::Set(d, (MathT)4294967295.0));
        VecD v_rounded = hn::Add(v_denorm, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_max     = hn::Set(d, (MathT)4294967295.0);
        VecD v_clamped = hn::Max(v_rounded, v_zero);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::ConvertTo(d_u32, v_clamped);
        hn::StoreN(v_u32, d_u32, ptr, count);
    } else if constexpr (std::is_same_v<DstT, int32_t>) {
        // float -> int32: Denormalize from approximately [-1.0, 1.0] range to [-2147483648, 2147483647] range
        VecD v_val    = (VecD)v;
        VecD v_denorm = hn::Mul(v_val, hn::Set(d, (MathT)2147483647.0));
        // Symmetric round-to-nearest for signed values (assumes ConvertTo truncates).
        auto is_neg    = hn::Lt(v_denorm, hn::Zero(d));
        auto v_bias    = hn::IfThenElse(is_neg, hn::Set(d, (MathT)-0.5),
                                        hn::Set(d, (MathT)0.5));
        VecD v_rounded = hn::Add(v_denorm, v_bias);
        VecD v_min     = hn::Set(d, (MathT)-2147483648.0);
        VecD v_max     = hn::Set(d, (MathT)2147483647.0);
        VecD v_clamped = hn::Max(v_rounded, v_min);
        v_clamped      = hn::Min(v_clamped, v_max);

        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::ConvertTo(d_i32, v_clamped);
        hn::StoreN(v_i32, d_i32, ptr, count);
    } else if constexpr (std::is_same_v<DstT, uint64_t>) {
        // float -> uint64: Promote via uint32
        VecD v_val     = (VecD)v;
        VecD v_rounded = hn::Add(v_val, hn::Set(d, (MathT)0.5));
        VecD v_zero    = hn::Zero(d);
        VecD v_clamped = hn::Max(v_rounded, v_zero);

        auto d_u32 = hn::Rebind<uint32_t, D>();
        auto v_u32 = hn::ConvertTo(d_u32, v_clamped);
        auto d_u64 = hn::Rebind<uint64_t, D>();
        auto v_u64 = hn::PromoteTo(d_u64, v_u32);
        hn::StoreN(v_u64, d_u64, ptr, count);
    } else if constexpr (std::is_same_v<DstT, int64_t>) {
        // float -> int64: Promote via int32
        VecD v_val     = (VecD)v;
        VecD v_rounded = hn::Add(v_val, hn::Set(d, (MathT)0.5));

        auto d_i32 = hn::Rebind<int32_t, D>();
        auto v_i32 = hn::ConvertTo(d_i32, v_rounded);
        auto d_i64 = hn::Rebind<int64_t, D>();
        auto v_i64 = hn::PromoteTo(d_i64, v_i32);
        hn::StoreN(v_i64, d_i64, ptr, count);
    }
}

// -----------------------------------------------------------------------
// Native Integer Kernel Runners (No Type Conversion)
// -----------------------------------------------------------------------

/// Execute a unary SIMD operation on native integer arrays (no type promotion).
/// For scale-invariant operations like abs, where int_op(a) == denorm(float_op(norm(a))).
/// Much faster than promotion path - operates directly on integer SIMD vectors.
/// @param r Destination array (same type as source)
/// @param a Source array
/// @param n Number of elements to process
/// @param op Lambda/functor taking (descriptor, vector) and returning result vector
///           Example: [](auto d, auto va) { return hn::Abs(va); }
template<typename T, typename OpFunc>
inline void
RunHwyUnaryNativeInt(T* r, const T* a, size_t n, OpFunc op)
{
    const hn::ScalableTag<T> d;
    size_t x     = 0;
    size_t lanes = hn::Lanes(d);
    for (; x + lanes <= n; x += lanes) {
        auto va  = hn::Load(d, a + x);
        auto res = op(d, va);
        hn::Store(res, d, r + x);
    }
    size_t remaining = n - x;
    if (remaining > 0) {
        auto va  = hn::LoadN(d, a + x, remaining);
        auto res = op(d, va);
        hn::StoreN(res, d, r + x, remaining);
    }
}

/// Execute a binary SIMD operation on native integer arrays (no type promotion).
/// For scale-invariant operations like saturated add, min, max, where:
/// int_op(a, b) == denorm(float_op(norm(a), norm(b))).
/// Much faster than promotion path - no conversion overhead.
/// @param r Destination array (same type as sources)
/// @param a First source array
/// @param b Second source array
/// @param n Number of elements to process
/// @param op Lambda/functor taking (descriptor, vector_a, vector_b) and returning result
///           Example: [](auto d, auto va, auto vb) { return hn::SaturatedAdd(va, vb); }
template<typename T, typename OpFunc>
inline void
RunHwyBinaryNativeInt(T* r, const T* a, const T* b, size_t n, OpFunc op)
{
    const hn::ScalableTag<T> d;
    size_t x     = 0;
    size_t lanes = hn::Lanes(d);
    for (; x + lanes <= n; x += lanes) {
        auto va  = hn::Load(d, a + x);
        auto vb  = hn::Load(d, b + x);
        auto res = op(d, va, vb);
        hn::Store(res, d, r + x);
    }
    size_t remaining = n - x;
    if (remaining > 0) {
        auto va  = hn::LoadN(d, a + x, remaining);
        auto vb  = hn::LoadN(d, b + x, remaining);
        auto res = op(d, va, vb);
        hn::StoreN(res, d, r + x, remaining);
    }
}

// -----------------------------------------------------------------------
// Generic Kernel Runners (With Type Conversion)
// -----------------------------------------------------------------------

/// Execute a unary SIMD operation on an array.
/// Processes array elements in SIMD batches, handling type promotion/demotion
/// and partial vectors at the end.
/// @param r Destination array
/// @param a Source array
/// @param n Number of elements to process
/// @param op Lambda/functor taking (descriptor, vector) and returning result vector
///           Example: [](auto d, auto va) { return hn::Sqrt(va); }
template<typename Rtype, typename Atype, typename OpFunc>
inline void
RunHwyUnaryCmd(Rtype* r, const Atype* a, size_t n, OpFunc op)
{
    using MathT = typename SimdMathType<Rtype>::type;
    const hn::ScalableTag<MathT> d;
    size_t x     = 0;
    size_t lanes = hn::Lanes(d);
    for (; x + lanes <= n; x += lanes) {
        auto va  = LoadPromote(d, a + x);
        auto res = op(d, va);
        DemoteStore(d, r + x, res);
    }
    size_t remaining = n - x;
    if (remaining > 0) {
        auto va  = LoadPromoteN(d, a + x, remaining);
        auto res = op(d, va);
        DemoteStoreN(d, r + x, res, remaining);
    }
}

/// Execute a binary SIMD operation on two arrays.
/// Processes array elements in SIMD batches, handling type promotion/demotion
/// and partial vectors at the end.
/// @param r Destination array
/// @param a First source array
/// @param b Second source array
/// @param n Number of elements to process
/// @param op Lambda/functor taking (descriptor, vector_a, vector_b) and returning result
///           Example: [](auto d, auto va, auto vb) { return hn::Add(va, vb); }
template<typename Rtype, typename Atype, typename Btype, typename OpFunc>
inline void
RunHwyCmd(Rtype* r, const Atype* a, const Btype* b, size_t n, OpFunc op)
{
    using MathT = typename SimdMathType<Rtype>::type;
    const hn::ScalableTag<MathT> d;
    size_t x     = 0;
    size_t lanes = hn::Lanes(d);
    for (; x + lanes <= n; x += lanes) {
        auto va  = LoadPromote(d, a + x);
        auto vb  = LoadPromote(d, b + x);
        auto res = op(d, va, vb);
        DemoteStore(d, r + x, res);
    }
    size_t remaining = n - x;
    if (remaining > 0) {
        auto va  = LoadPromoteN(d, a + x, remaining);
        auto vb  = LoadPromoteN(d, b + x, remaining);
        auto res = op(d, va, vb);
        DemoteStoreN(d, r + x, res, remaining);
    }
}

/// Execute a ternary SIMD operation on three arrays.
/// Processes array elements in SIMD batches, handling type promotion/demotion
/// and partial vectors at the end.
/// @param r Destination array
/// @param a First source array
/// @param b Second source array
/// @param c Third source array
/// @param n Number of elements to process
/// @param op Lambda/functor taking (descriptor, vector_a, vector_b, vector_c) and returning result
///           Example: [](auto d, auto va, auto vb, auto vc) { return hn::MulAdd(va, vb, vc); }
template<typename Rtype, typename ABCtype, typename OpFunc>
inline void
RunHwyTernaryCmd(Rtype* r, const ABCtype* a, const ABCtype* b, const ABCtype* c,
                 size_t n, OpFunc op)
{
    using MathT = typename SimdMathType<Rtype>::type;
    const hn::ScalableTag<MathT> d;
    size_t x     = 0;
    size_t lanes = hn::Lanes(d);
    for (; x + lanes <= n; x += lanes) {
        auto va  = LoadPromote(d, a + x);
        auto vb  = LoadPromote(d, b + x);
        auto vc  = LoadPromote(d, c + x);
        auto res = op(d, va, vb, vc);
        DemoteStore(d, r + x, res);
    }
    size_t remaining = n - x;
    if (remaining > 0) {
        auto va  = LoadPromoteN(d, a + x, remaining);
        auto vb  = LoadPromoteN(d, b + x, remaining);
        auto vc  = LoadPromoteN(d, c + x, remaining);
        auto res = op(d, va, vb, vc);
        DemoteStoreN(d, r + x, res, remaining);
    }
}

// -----------------------------------------------------------------------
// Per-pixel Ops (ImageBufAlgo, contiguous interleaved channels)
// -----------------------------------------------------------------------

/// Execute a binary per-pixel HWY operation for interleaved, contiguous
/// channels. The caller is responsible for ensuring that the channel range is
/// contiguous for R/A/B (i.e. no per-pixel padding, and the ROI channel range
/// covers the full pixel).
template<typename Rtype, typename Atype, typename Btype, typename OpFunc>
inline bool
hwy_binary_perpixel_op(ImageBuf& R, const ImageBuf& A, const ImageBuf& B,
                       ROI roi, int nthreads, OpFunc op)
{
    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    ImageBufAlgo::parallel_image(roi, nthreads, [&, op](ROI roi) {
        const int nchannels = roi.nchannels();
        const size_t n      = static_cast<size_t>(roi.width())
                              * static_cast<size_t>(nchannels);
        for (int y = roi.ybegin; y < roi.yend; ++y) {
            Rtype* r_row       = RoiRowPtr<Rtype>(Rv, y, roi);
            const Atype* a_row = RoiRowPtr<Atype>(Av, y, roi);
            const Btype* b_row = RoiRowPtr<Btype>(Bv, y, roi);
            RunHwyCmd<Rtype, Atype, Btype>(r_row, a_row, b_row, n, op);
        }
    });
    return true;
}

/// Execute a ternary per-pixel HWY operation for interleaved, contiguous
/// channels. The caller is responsible for ensuring that the channel range is
/// contiguous for R/A/B/C (i.e. no per-pixel padding, and the ROI channel range
/// covers the full pixel).
template<typename Rtype, typename ABCtype, typename OpFunc>
inline bool
hwy_ternary_perpixel_op(ImageBuf& R, const ImageBuf& A, const ImageBuf& B,
                        const ImageBuf& C, ROI roi, int nthreads, OpFunc op)
{
    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    auto Cv = HwyPixels(C);
    ImageBufAlgo::parallel_image(roi, nthreads, [&, op](ROI roi) {
        const int nchannels = roi.nchannels();
        const size_t n      = static_cast<size_t>(roi.width())
                              * static_cast<size_t>(nchannels);
        for (int y = roi.ybegin; y < roi.yend; ++y) {
            Rtype* r_row         = RoiRowPtr<Rtype>(Rv, y, roi);
            const ABCtype* a_row = RoiRowPtr<ABCtype>(Av, y, roi);
            const ABCtype* b_row = RoiRowPtr<ABCtype>(Bv, y, roi);
            const ABCtype* c_row = RoiRowPtr<ABCtype>(Cv, y, roi);
            RunHwyTernaryCmd<Rtype, ABCtype>(r_row, a_row, b_row, c_row, n, op);
        }
    });
    return true;
}

/// Execute a binary per-pixel HWY operation on native integer arrays (no type
/// promotion/normalization). The caller is responsible for ensuring that the
/// channel range is contiguous for R/A/B.
template<typename T, typename OpFunc>
inline bool
hwy_binary_native_int_perpixel_op(ImageBuf& R, const ImageBuf& A,
                                  const ImageBuf& B, ROI roi, int nthreads,
                                  OpFunc op)
{
    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    ImageBufAlgo::parallel_image(roi, nthreads, [&, op](ROI roi) {
        const int nchannels = roi.nchannels();
        const size_t n      = static_cast<size_t>(roi.width())
                              * static_cast<size_t>(nchannels);
        for (int y = roi.ybegin; y < roi.yend; ++y) {
            T* r_row       = RoiRowPtr<T>(Rv, y, roi);
            const T* a_row = RoiRowPtr<T>(Av, y, roi);
            const T* b_row = RoiRowPtr<T>(Bv, y, roi);
            RunHwyBinaryNativeInt<T>(r_row, a_row, b_row, n, op);
        }
    });
    return true;
}

// -----------------------------------------------------------------------
// Per-pixel Ops (ImageBufAlgo, RGBA packed but ROI is RGB)
// -----------------------------------------------------------------------

/// Store only RGB results for `count` pixels into interleaved RGBA memory,
/// leaving alpha untouched.
template<class D, typename DstT, typename VecT>
inline void
StoreInterleaved3DemoteN(D d, DstT* ptr, VecT r, VecT g, VecT b, size_t count)
{
    DstT r_demoted[hn::MaxLanes(d)];
    DstT g_demoted[hn::MaxLanes(d)];
    DstT b_demoted[hn::MaxLanes(d)];
    DemoteStoreN(d, r_demoted, r, count);
    DemoteStoreN(d, g_demoted, g, count);
    DemoteStoreN(d, b_demoted, b, count);
    for (size_t i = 0; i < count; ++i) {
        ptr[i * 4 + 0] = r_demoted[i];
        ptr[i * 4 + 1] = g_demoted[i];
        ptr[i * 4 + 2] = b_demoted[i];
        // Preserve alpha (i*4+3).
    }
}

/// Execute a binary per-pixel HWY operation for the common "packed RGBA but
/// ROI is RGB" case. This can still SIMD by processing N pixels at a time and
/// passing alpha through unchanged from the destination.
template<typename Rtype, typename Atype, typename Btype, typename OpFunc>
inline bool
hwy_binary_perpixel_op_rgba_rgb_roi(ImageBuf& R, const ImageBuf& A,
                                    const ImageBuf& B, ROI roi, int nthreads,
                                    OpFunc op)
{
    if (roi.chbegin != 0 || roi.chend != 3)
        return false;

    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    if (Rv.nchannels < 4 || Av.nchannels < 4 || Bv.nchannels < 4)
        return false;

    // Require packed RGBA (no padding, exactly 4 channels).
    if (!ChannelsContiguous<Rtype>(Rv, 4) || !ChannelsContiguous<Atype>(Av, 4)
        || !ChannelsContiguous<Btype>(Bv, 4))
        return false;

    ROI roi4     = roi;
    roi4.chbegin = 0;
    roi4.chend   = 4;

    using MathT = typename SimdMathType<Rtype>::type;
    const hn::ScalableTag<MathT> d;
    const size_t lanes = hn::Lanes(d);

    ImageBufAlgo::parallel_image(roi4, nthreads, [&, op](ROI roi4) {
        for (int y = roi4.ybegin; y < roi4.yend; ++y) {
            Rtype* r_row         = RoiRowPtr<Rtype>(Rv, y, roi4);
            const Atype* a_row   = RoiRowPtr<Atype>(Av, y, roi4);
            const Btype* b_row   = RoiRowPtr<Btype>(Bv, y, roi4);
            const size_t npixels = static_cast<size_t>(roi4.width());

            size_t x = 0;
            for (; x + lanes <= npixels; x += lanes) {
                const size_t off = x * 4;

                auto [ar, ag, ab, aa] = LoadInterleaved4Promote(d, a_row + off);
                auto [br, bg, bb, ba] = LoadInterleaved4Promote(d, b_row + off);
                (void)aa;
                (void)ba;

                using DstLaneT = HwyLaneTypeT<Rtype>;
                auto d_dstlane = hn::Rebind<DstLaneT, hn::ScalableTag<MathT>>();
                hn::Vec<decltype(d_dstlane)> dr, dg, db, da;
                hn::LoadInterleaved4(d_dstlane,
                                     reinterpret_cast<const DstLaneT*>(r_row
                                                                       + off),
                                     dr, dg, db, da);
                (void)dr;
                (void)dg;
                (void)db;

                auto rr = op(d, ar, br);
                auto rg = op(d, ag, bg);
                auto rb = op(d, ab, bb);
                StoreInterleaved4RgbAlphaPassthrough(d, r_row + off, rr, rg, rb,
                                                     da);
            }

            const size_t remaining = npixels - x;
            if (remaining > 0) {
                const size_t off      = x * 4;
                auto [ar, ag, ab, aa] = LoadInterleaved4PromoteN(d, a_row + off,
                                                                 remaining);
                auto [br, bg, bb, ba] = LoadInterleaved4PromoteN(d, b_row + off,
                                                                 remaining);
                (void)aa;
                (void)ba;
                auto rr = op(d, ar, br);
                auto rg = op(d, ag, bg);
                auto rb = op(d, ab, bb);
                StoreInterleaved3DemoteN(d, r_row + off, rr, rg, rb, remaining);
            }
        }
    });

    return true;
}

/// Execute a ternary per-pixel HWY operation for the common "packed RGBA but
/// ROI is RGB" case, passing alpha through unchanged from the destination.
template<typename Rtype, typename ABCtype, typename OpFunc>
inline bool
hwy_ternary_perpixel_op_rgba_rgb_roi(ImageBuf& R, const ImageBuf& A,
                                     const ImageBuf& B, const ImageBuf& C,
                                     ROI roi, int nthreads, OpFunc op)
{
    if (roi.chbegin != 0 || roi.chend != 3)
        return false;

    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    auto Cv = HwyPixels(C);
    if (Rv.nchannels < 4 || Av.nchannels < 4 || Bv.nchannels < 4
        || Cv.nchannels < 4)
        return false;

    if (!ChannelsContiguous<Rtype>(Rv, 4) || !ChannelsContiguous<ABCtype>(Av, 4)
        || !ChannelsContiguous<ABCtype>(Bv, 4)
        || !ChannelsContiguous<ABCtype>(Cv, 4))
        return false;

    ROI roi4     = roi;
    roi4.chbegin = 0;
    roi4.chend   = 4;

    using MathT = typename SimdMathType<Rtype>::type;
    const hn::ScalableTag<MathT> d;
    const size_t lanes = hn::Lanes(d);

    ImageBufAlgo::parallel_image(roi4, nthreads, [&, op](ROI roi4) {
        for (int y = roi4.ybegin; y < roi4.yend; ++y) {
            Rtype* r_row         = RoiRowPtr<Rtype>(Rv, y, roi4);
            const ABCtype* a_row = RoiRowPtr<ABCtype>(Av, y, roi4);
            const ABCtype* b_row = RoiRowPtr<ABCtype>(Bv, y, roi4);
            const ABCtype* c_row = RoiRowPtr<ABCtype>(Cv, y, roi4);
            const size_t npixels = static_cast<size_t>(roi4.width());

            size_t x = 0;
            for (; x + lanes <= npixels; x += lanes) {
                const size_t off = x * 4;

                auto [ar, ag, ab, aa] = LoadInterleaved4Promote(d, a_row + off);
                auto [br, bg, bb, ba] = LoadInterleaved4Promote(d, b_row + off);
                auto [cr, cg, cb, ca] = LoadInterleaved4Promote(d, c_row + off);
                (void)aa;
                (void)ba;
                (void)ca;

                using DstLaneT = HwyLaneTypeT<Rtype>;
                auto d_dstlane = hn::Rebind<DstLaneT, hn::ScalableTag<MathT>>();
                hn::Vec<decltype(d_dstlane)> dr, dg, db, da;
                hn::LoadInterleaved4(d_dstlane,
                                     reinterpret_cast<const DstLaneT*>(r_row
                                                                       + off),
                                     dr, dg, db, da);
                (void)dr;
                (void)dg;
                (void)db;

                auto rr = op(d, ar, br, cr);
                auto rg = op(d, ag, bg, cg);
                auto rb = op(d, ab, bb, cb);
                StoreInterleaved4RgbAlphaPassthrough(d, r_row + off, rr, rg, rb,
                                                     da);
            }

            const size_t remaining = npixels - x;
            if (remaining > 0) {
                const size_t off      = x * 4;
                auto [ar, ag, ab, aa] = LoadInterleaved4PromoteN(d, a_row + off,
                                                                 remaining);
                auto [br, bg, bb, ba] = LoadInterleaved4PromoteN(d, b_row + off,
                                                                 remaining);
                auto [cr, cg, cb, ca] = LoadInterleaved4PromoteN(d, c_row + off,
                                                                 remaining);
                (void)aa;
                (void)ba;
                (void)ca;
                auto rr = op(d, ar, br, cr);
                auto rg = op(d, ag, bg, cg);
                auto rb = op(d, ab, bb, cb);
                StoreInterleaved3DemoteN(d, r_row + off, rr, rg, rb, remaining);
            }
        }
    });

    return true;
}

/// Execute a native integer binary operation for the "packed RGBA but ROI is
/// RGB" case. This operates on the raw integer channel values and preserves
/// alpha by masking.
template<typename T, typename OpFunc>
inline bool
hwy_binary_native_int_perpixel_op_rgba_rgb_roi(ImageBuf& R, const ImageBuf& A,
                                               const ImageBuf& B, ROI roi,
                                               int nthreads, OpFunc op)
{
    if (roi.chbegin != 0 || roi.chend != 3)
        return false;

    auto Rv = HwyPixels(R);
    auto Av = HwyPixels(A);
    auto Bv = HwyPixels(B);
    if (Rv.nchannels < 4 || Av.nchannels < 4 || Bv.nchannels < 4)
        return false;
    if (!ChannelsContiguous<T>(Rv, 4) || !ChannelsContiguous<T>(Av, 4)
        || !ChannelsContiguous<T>(Bv, 4))
        return false;

    const hn::ScalableTag<T> d;
    const size_t lanes = hn::Lanes(d);
    if (lanes & 3)
        return false;  // need block alignment so the alpha mask stays aligned

    const auto three      = hn::Set(d, T(3));
    const auto lane_index = hn::Iota(d, T(0));
    const auto alpha_mask = hn::Eq(hn::And(lane_index, three), three);

    ROI roi4     = roi;
    roi4.chbegin = 0;
    roi4.chend   = 4;
    ImageBufAlgo::parallel_image(roi4, nthreads, [&, op](ROI roi4) {
        const size_t n = static_cast<size_t>(roi4.width()) * 4;
        for (int y = roi4.ybegin; y < roi4.yend; ++y) {
            T* r_row       = RoiRowPtr<T>(Rv, y, roi4);
            const T* a_row = RoiRowPtr<T>(Av, y, roi4);
            const T* b_row = RoiRowPtr<T>(Bv, y, roi4);
            size_t i       = 0;
            for (; i + lanes <= n; i += lanes) {
                auto va   = hn::Load(d, a_row + i);
                auto vb   = hn::Load(d, b_row + i);
                auto vold = hn::Load(d, r_row + i);
                auto vnew = op(d, va, vb);
                auto vres = hn::IfThenElse(alpha_mask, vold, vnew);
                hn::Store(vres, d, r_row + i);
            }
            const size_t remaining = n - i;
            if (remaining > 0) {
                auto va   = hn::LoadN(d, a_row + i, remaining);
                auto vb   = hn::LoadN(d, b_row + i, remaining);
                auto vold = hn::LoadN(d, r_row + i, remaining);
                auto vnew = op(d, va, vb);
                auto vres = hn::IfThenElse(alpha_mask, vold, vnew);
                hn::StoreN(vres, d, r_row + i, remaining);
            }
        }
    });

    return true;
}

// -----------------------------------------------------------------------
// Interleaved Channel Load/Store Helpers
// -----------------------------------------------------------------------

/// Load 4 interleaved channels (RGBA) with type promotion.
/// For matching types, uses Highway's native LoadInterleaved4.
/// For type promotion, loads and manually deinterleaves.
/// @param d Highway descriptor tag for the target SIMD type
/// @param ptr Pointer to interleaved RGBA data (R0,G0,B0,A0,R1,G1,B1,A1,...)
/// @return Tuple of (R, G, B, A) SIMD vectors in promoted type
template<class D, typename SrcT>
inline std::tuple<hn::Vec<D>, hn::Vec<D>, hn::Vec<D>, hn::Vec<D>>
LoadInterleaved4Promote(D d, const SrcT* ptr)
{
    using MathT = typename D::T;
    using Vec   = hn::Vec<D>;

    if constexpr (std::is_same_v<SrcT, MathT>) {
        // No promotion needed - use Highway's optimized LoadInterleaved4
        Vec r, g, b, a;
        hn::LoadInterleaved4(d, ptr, r, g, b, a);
        return std::make_tuple(r, g, b, a);
    } else if constexpr (std::is_same_v<SrcT, half>) {
        // Special handling for half type - convert through hwy::float16_t
        using T16 = hwy::float16_t;
        auto d16  = hn::Rebind<T16, D>();

        // Load interleaved half data as float16_t
        hn::Vec<decltype(d16)> r16, g16, b16, a16;
        hn::LoadInterleaved4(d16, reinterpret_cast<const T16*>(ptr), r16, g16,
                             b16, a16);

        // Promote to computation type
        Vec r_vec = hn::PromoteTo(d, r16);
        Vec g_vec = hn::PromoteTo(d, g16);
        Vec b_vec = hn::PromoteTo(d, b16);
        Vec a_vec = hn::PromoteTo(d, a16);

        return std::make_tuple(r_vec, g_vec, b_vec, a_vec);
    } else {
        // Generic type promotion - deinterleave with HWY then promote.
        auto d_src = hn::Rebind<SrcT, D>();
        hn::Vec<decltype(d_src)> r_src, g_src, b_src, a_src;
        hn::LoadInterleaved4(d_src, ptr, r_src, g_src, b_src, a_src);
        auto r_vec = PromoteVec<D, SrcT>(d, r_src);
        auto g_vec = PromoteVec<D, SrcT>(d, g_src);
        auto b_vec = PromoteVec<D, SrcT>(d, b_src);
        auto a_vec = PromoteVec<D, SrcT>(d, a_src);
        return std::make_tuple(r_vec, g_vec, b_vec, a_vec);
    }
}

/// Load 4 interleaved channels (RGBA) with type promotion for a partial vector
/// (count pixels, count <= lanes).
template<class D, typename SrcT>
inline std::tuple<hn::Vec<D>, hn::Vec<D>, hn::Vec<D>, hn::Vec<D>>
LoadInterleaved4PromoteN(D d, const SrcT* ptr, size_t count)
{
    SrcT r_src[hn::MaxLanes(d)];
    SrcT g_src[hn::MaxLanes(d)];
    SrcT b_src[hn::MaxLanes(d)];
    SrcT a_src[hn::MaxLanes(d)];
    for (size_t i = 0; i < count; ++i) {
        r_src[i] = ptr[i * 4 + 0];
        g_src[i] = ptr[i * 4 + 1];
        b_src[i] = ptr[i * 4 + 2];
        a_src[i] = ptr[i * 4 + 3];
    }
    auto r_vec = LoadPromoteN(d, r_src, count);
    auto g_vec = LoadPromoteN(d, g_src, count);
    auto b_vec = LoadPromoteN(d, b_src, count);
    auto a_vec = LoadPromoteN(d, a_src, count);
    return std::make_tuple(r_vec, g_vec, b_vec, a_vec);
}

/// Store 4 interleaved channels (RGBA) with type demotion.
/// For matching types, uses Highway's native StoreInterleaved4.
/// For type demotion, manually interleaves and stores.
/// @param d Highway descriptor tag for the source SIMD type
/// @param ptr Pointer to destination interleaved RGBA data
/// @param r Red channel SIMD vector
/// @param g Green channel SIMD vector
/// @param b Blue channel SIMD vector
/// @param a Alpha channel SIMD vector
template<class D, typename DstT, typename VecT>
inline void
StoreInterleaved4Demote(D d, DstT* ptr, VecT r, VecT g, VecT b, VecT a)
{
    using MathT = typename D::T;

    if constexpr (std::is_same_v<DstT, MathT>) {
        // No demotion needed - use Highway's optimized StoreInterleaved4
        hn::StoreInterleaved4(r, g, b, a, d, ptr);
    } else if constexpr (std::is_same_v<DstT, half>) {
        // Special handling for half type - convert through hwy::float16_t
        using T16 = hwy::float16_t;
        auto d16  = hn::Rebind<T16, D>();

        // Demote to float16_t
        auto r16 = hn::DemoteTo(d16, r);
        auto g16 = hn::DemoteTo(d16, g);
        auto b16 = hn::DemoteTo(d16, b);
        auto a16 = hn::DemoteTo(d16, a);

        // Store interleaved float16_t data
        hn::StoreInterleaved4(r16, g16, b16, a16, d16,
                              reinterpret_cast<T16*>(ptr));
    } else {
        // Generic type demotion - demote to lane vectors and use HWY's interleaved store.
        auto d_dst = hn::Rebind<DstT, D>();
        auto r_dst = DemoteVec<D, DstT>(d, r);
        auto g_dst = DemoteVec<D, DstT>(d, g);
        auto b_dst = DemoteVec<D, DstT>(d, b);
        auto a_dst = DemoteVec<D, DstT>(d, a);
        hn::StoreInterleaved4(r_dst, g_dst, b_dst, a_dst, d_dst, ptr);
    }
}

/// Store 4 interleaved channels (RGBA) demoting RGB from math type and passing
/// alpha through unchanged (alpha is already in the destination lane type).
template<class D, typename DstT, typename VecMathT, typename VecAlphaLaneT>
inline void
StoreInterleaved4RgbAlphaPassthrough(D d, DstT* ptr, VecMathT r, VecMathT g,
                                     VecMathT b, VecAlphaLaneT a_passthrough)
{
    using MathT = typename D::T;
    if constexpr (std::is_same_v<DstT, MathT>) {
        hn::StoreInterleaved4(r, g, b, a_passthrough, d, ptr);
    } else if constexpr (std::is_same_v<DstT, half>) {
        using T16 = hwy::float16_t;
        auto d16  = hn::Rebind<T16, D>();
        auto r16  = hn::DemoteTo(d16, r);
        auto g16  = hn::DemoteTo(d16, g);
        auto b16  = hn::DemoteTo(d16, b);
        hn::StoreInterleaved4(r16, g16, b16, a_passthrough, d16,
                              reinterpret_cast<T16*>(ptr));
    } else {
        auto d_dst = hn::Rebind<DstT, D>();
        auto r_dst = DemoteVec<D, DstT>(d, r);
        auto g_dst = DemoteVec<D, DstT>(d, g);
        auto b_dst = DemoteVec<D, DstT>(d, b);
        hn::StoreInterleaved4(r_dst, g_dst, b_dst, a_passthrough, d_dst, ptr);
    }
}

// -----------------------------------------------------------------------
// Rangecompress/Rangeexpand SIMD Kernels
// -----------------------------------------------------------------------

/// Apply rangecompress formula to a SIMD vector.
/// Formula (courtesy Sony Pictures Imageworks):
///   if (|x| <= 0.18) return x
///   else return copysign(a + b * log(c * |x| + 1), x)
/// where a = -0.545768857, b = 0.183516696, c = 284.357788
/// @param d Highway descriptor tag
/// @param x Input SIMD vector
/// @return Compressed SIMD vector
template<class D, typename VecT>
inline auto
rangecompress_simd(D d, VecT x)
{
    using T = typename D::T;

    // Constants from Sony Pictures Imageworks
    constexpr T x1 = static_cast<T>(0.18);
    constexpr T a  = static_cast<T>(-0.54576885700225830078);
    constexpr T b  = static_cast<T>(0.18351669609546661377);
    constexpr T c  = static_cast<T>(284.3577880859375);

    auto abs_x            = hn::Abs(x);
    auto mask_passthrough = hn::Le(abs_x, hn::Set(d, x1));

    // compressed = a + b * log(c * |x| + 1.0)
    auto c_vec      = hn::Set(d, c);
    auto one        = hn::Set(d, static_cast<T>(1.0));
    auto temp       = hn::MulAdd(c_vec, abs_x, one);  // c * |x| + 1.0
    auto log_val    = hn::Log(d, temp);
    auto b_vec      = hn::Set(d, b);
    auto a_vec      = hn::Set(d, a);
    auto compressed = hn::MulAdd(b_vec, log_val, a_vec);  // a + b * log

    // Apply sign of original x
    auto result = hn::CopySign(compressed, x);

    // If |x| <= x1, return x; else return compressed
    return hn::IfThenElse(mask_passthrough, x, result);
}

/// Apply rangeexpand formula to a SIMD vector (inverse of rangecompress).
/// Formula:
///   if (|y| <= 0.18) return y
///   else x = exp((|y| - a) / b); x = (x - 1) / c
///        if x < 0.18 then x = (-x_intermediate - 1) / c
///        return copysign(x, y)
/// @param d Highway descriptor tag
/// @param y Input SIMD vector (compressed values)
/// @return Expanded SIMD vector
template<class D, typename VecT>
inline auto
rangeexpand_simd(D d, VecT y)
{
    using T = typename D::T;

    // Constants (same as rangecompress)
    constexpr T x1 = static_cast<T>(0.18);
    constexpr T a  = static_cast<T>(-0.54576885700225830078);
    constexpr T b  = static_cast<T>(0.18351669609546661377);
    constexpr T c  = static_cast<T>(284.3577880859375);

    auto abs_y            = hn::Abs(y);
    auto mask_passthrough = hn::Le(abs_y, hn::Set(d, x1));

    // x_intermediate = exp((|y| - a) / b)
    auto a_vec        = hn::Set(d, a);
    auto b_vec        = hn::Set(d, b);
    auto intermediate = hn::Div(hn::Sub(abs_y, a_vec), b_vec);  // (|y| - a) / b
    auto x_intermediate = hn::Exp(d, intermediate);

    // x = (x_intermediate - 1.0) / c
    auto one   = hn::Set(d, static_cast<T>(1.0));
    auto c_vec = hn::Set(d, c);
    auto x     = hn::Div(hn::Sub(x_intermediate, one), c_vec);

    // If x < x1, use alternate solution: (-x_intermediate - 1.0) / c
    auto mask_alternate = hn::Lt(x, hn::Set(d, x1));
    auto x_alternate    = hn::Div(hn::Sub(hn::Neg(x_intermediate), one), c_vec);
    x                   = hn::IfThenElse(mask_alternate, x_alternate, x);

    // Apply sign of input y
    auto result = hn::CopySign(x, y);

    return hn::IfThenElse(mask_passthrough, y, result);
}

OIIO_NAMESPACE_END
