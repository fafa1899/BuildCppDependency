// Copyright Contributors to the OpenImageIO project.
// SPDX-License-Identifier: Apache-2.0
// https://github.com/AcademySoftwareFoundation/OpenImageIO

#include <algorithm>
#include <cmath>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#include <tsl/robin_map.h>

#include <OpenImageIO/Imath.h>

#include <OpenImageIO/color.h>
#include <OpenImageIO/filesystem.h>
#include <OpenImageIO/imagebufalgo.h>
#include <OpenImageIO/imagebufalgo_util.h>
#include <OpenImageIO/strutil.h>
#include <OpenImageIO/sysutil.h>

#include "imageio_pvt.h"
#include "interop_config.h"

#define MAKE_OCIO_VERSION_HEX(maj, min, patch) \
    (((maj) << 24) | ((min) << 16) | (patch))

#include <OpenColorIO/OpenColorIO.h>

namespace OCIO = OCIO_NAMESPACE;


OIIO_NAMESPACE_3_1_BEGIN

namespace {
// Some test colors we use to interrogate transformations
static const int n_test_colors = 5;
static const Imath::C3f test_colors[n_test_colors]
    = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 }, { 1, 1, 1 }, { 0.5, 0.5, 0.5 } };
}  // namespace


#if 1 || !defined(NDEBUG) /* allow color configuration debugging */
static bool colordebug = Strutil::stoi(Sysutil::getenv("OIIO_DEBUG_COLOR"))
                         || Strutil::stoi(Sysutil::getenv("OIIO_DEBUG_ALL"));
#    define DBG(...)    \
        if (colordebug) \
        Strutil::print(__VA_ARGS__)
#else
#    define DBG(...)
#endif


static int disable_ocio = Strutil::stoi(Sysutil::getenv("OIIO_DISABLE_OCIO"));
static int disable_builtin_configs = Strutil::stoi(
    Sysutil::getenv("OIIO_DISABLE_BUILTIN_OCIO_CONFIGS"));
static OCIO::ConstConfigRcPtr ocio_current_config;

// OCIO 2.3 and 2.4 compose back-to-back gamma/exponent ops in the wrong
// direction, so skip that optimization before OCIO 2.5.0 (which has the fix,
// AcademySoftwareFoundation/OpenColorIO#2154).
#if OCIO_VERSION_HEX < MAKE_OCIO_VERSION_HEX(2, 5, 0)
static constexpr auto ocio_optimization = OCIO::OptimizationFlags(
    OCIO::OPTIMIZATION_DEFAULT & ~OCIO::OPTIMIZATION_COMP_GAMMA);
#else
static constexpr auto ocio_optimization = OCIO::OPTIMIZATION_DEFAULT;
#endif



const ColorConfig&
ColorConfig::default_colorconfig()
{
    static ColorConfig config;
    return config;
}



// Class used as the key to index color processors in the cache.
class ColorProcCacheKey {
public:
    ColorProcCacheKey(ustring in, ustring out, ustring key = ustring(),
                      ustring val = ustring(), ustring looks = ustring(),
                      ustring display = ustring(), ustring view = ustring(),
                      ustring file           = ustring(),
                      ustring namedtransform = ustring(), bool inverse = false)
        : inputColorSpace(in)
        , outputColorSpace(out)
        , context_key(key)
        , context_value(val)
        , looks(looks)
        , file(file)
        , namedtransform(namedtransform)
        , inverse(inverse)
    {
        hash = inputColorSpace.hash() + 14033ul * outputColorSpace.hash()
               + 823ul * context_key.hash() + 28411ul * context_value.hash()
               + 1741ul
                     * (looks.hash() + display.hash() + view.hash()
                        + file.hash() + namedtransform.hash())
               + (inverse ? 6421 : 0);
        // N.B. no separate multipliers for looks, display, view, file,
        // namedtransform, because they're never used for the same lookup.
    }

    friend bool operator<(const ColorProcCacheKey& a,
                          const ColorProcCacheKey& b)
    {
        return std::tie(a.hash, a.inputColorSpace, a.outputColorSpace,
                        a.context_key, a.context_value, a.looks, a.display,
                        a.view, a.file, a.namedtransform, a.inverse)
               < std::tie(b.hash, b.inputColorSpace, b.outputColorSpace,
                          b.context_key, b.context_value, b.looks, b.display,
                          b.view, b.file, b.namedtransform, b.inverse);
    }

    friend bool operator==(const ColorProcCacheKey& a,
                           const ColorProcCacheKey& b)
    {
        return std::tie(a.hash, a.inputColorSpace, a.outputColorSpace,
                        a.context_key, a.context_value, a.looks, a.display,
                        a.view, a.file, a.namedtransform, a.inverse)
               == std::tie(b.hash, b.inputColorSpace, b.outputColorSpace,
                           b.context_key, b.context_value, b.looks, b.display,
                           b.view, b.file, b.namedtransform, b.inverse);
    }
    ustring inputColorSpace;
    ustring outputColorSpace;
    ustring context_key;
    ustring context_value;
    ustring looks;
    ustring display;
    ustring view;
    ustring file;
    ustring namedtransform;
    bool inverse;
    size_t hash;
};


struct ColorProcCacheKeyHasher {
    size_t operator()(const ColorProcCacheKey& c) const { return c.hash; }
};


typedef tsl::robin_map<ColorProcCacheKey, ColorProcessorHandle,
                       ColorProcCacheKeyHasher>
    ColorProcessorMap;



bool
ColorConfig::supportsOpenColorIO()
{
    return (disable_ocio == 0);
}



int
ColorConfig::OpenColorIO_version_hex()
{
    return OCIO_VERSION_HEX;
}


struct CSInfo {
    std::string name;  // Name of this color space
    int index;         // More than one can have the same index -- aliases
    enum Flags {
        none               = 0,
        is_linear_response = 1,  // any cs with linear transfer function
        is_scene_linear    = 2,  // equivalent to scene_linear
        is_srgb_display = 4,  // sRGB (primaries, and transfer function) display
        is_srgb_scene   = 8,  // sRGB (primaries, and transfer function) scene
        is_lin_srgb     = 16,   // sRGB/Rec709 primaries, linear response
        is_ACEScg       = 32,   // ACEScg
        is_Rec709       = 64,   // Rec709 primaries and transfer function
        is_data         = 128,  // Non-color-managed data
        is_known = is_srgb_display | is_srgb_scene | is_lin_srgb | is_ACEScg
                   | is_Rec709

    };
    int m_flags   = 0;
    bool examined = false;
    bool active   = true;
    std::string canonical;  // Canonical name for this color space
    OCIO::ConstColorSpaceRcPtr ocio_cs;

    CSInfo(string_view name_, int index_, int flags_ = none,
           string_view canonical_ = "")
        : name(name_), index(index_), m_flags(flags_), canonical(canonical_)
    {
    }

    void setflag(int flagval) { m_flags |= flagval; }

    // Set flag to include any bits in flagval, and also if alias is not yet
    // set, set it to name.
    void setflag(int flagval, std::string& alias)
    {
        m_flags |= flagval;
        if (alias.empty())
            alias = name;
    }

    int flags() const { return m_flags; }
};



// Hidden implementation of ColorConfig
class ColorConfig::Impl {
public:
    OCIO::ConfigRcPtr config_;
    OCIO::ConfigRcPtr builtinconfig_;

    // A color space's chromaticities (in the ColorInteropID table, or null)
    // and transfer function gamma.
    struct Properties {
        const float* xy = nullptr;
        float gamma     = 0.0f;
    };

private:
    std::vector<CSInfo> colorspaces;
    std::string scene_linear_alias;  // Alias for a scene-linear color space
    std::string lin_srgb_alias;
    std::string srgb_display_alias;
    std::string srgb_scene_alias;
    std::string ACEScg_alias;
    std::string Rec709_alias;
    mutable spin_rw_mutex m_mutex;
    mutable std::once_flag m_interop_names_once;
    mutable std::vector<std::array<std::string, 2>> m_interop_names;
    mutable std::string m_error;
    ColorProcessorMap colorprocmap;  // cache of ColorProcessors
    atomic_int colorprocs_requested;
    atomic_int colorprocs_created;
    std::string m_configname;
    ColorConfig* m_self       = nullptr;
    bool m_config_is_built_in = false;
    std::string m_init_filename;
    std::once_flag m_init_flag;
    bool m_init_ok = false;

public:
    Impl(ColorConfig* self, string_view filename)
        : m_self(self), m_init_filename(filename)
    {
    }

    ~Impl()
    {
#if 0
        // Debugging the cache -- make sure we're creating a small number
        // compared to repeated requests.
        if (colorprocs_requested)
            DBG("ColorConfig::Impl : color procs requested: {}, created: {}\n",
                           colorprocs_requested, colorprocs_created);
#endif
    }

    bool init(string_view filename);

    // Load the config on first use: it is expensive, and many operations,
    // such as reading images, never need it.
    bool init_once()
    {
        std::call_once(m_init_flag, [this] {
            OIIO::pvt::LoggedTimer logtime("ColorConfig::init");
            m_init_ok = init(m_init_filename);
        });
        return m_init_ok;
    }

    void add(const std::string& name, int index, int flags = 0)
    {
        spin_rw_write_lock lock(m_mutex);
        colorspaces.emplace_back(name, index, flags);
        // classify(colorspaces.back());
    }

    // Find the CSInfo record for the named color space, or nullptr if it's
    // not a color space we know.
    const CSInfo* find(string_view name) const
    {
        for (auto&& cs : colorspaces)
            if (cs.name == name)
                return &cs;
        return nullptr;
    }
    CSInfo* find(string_view name)
    {
        for (auto&& cs : colorspaces)
            if (cs.name == name)
                return &cs;
        return nullptr;
    }

    // Whether names a and b, which resolve() resolved to ra and rb, name the
    // same color space, as ColorConfig::equivalent() decides.
    bool equivalent(string_view a, string_view ra, string_view b,
                    string_view rb) const;

    // The ColorInteropID table's IDs and legacy aliases, as resolve()
    // resolves them in this config, worked out on first use.
    const std::vector<std::array<std::string, 2>>& interop_names() const;

    // Search for a matching ColorProcessor, return it if found (otherwise
    // return an empty handle).
    ColorProcessorHandle findproc(const ColorProcCacheKey& key)
    {
        ++colorprocs_requested;
        spin_rw_read_lock lock(m_mutex);
        auto found = colorprocmap.find(key);
        return (found == colorprocmap.end()) ? ColorProcessorHandle()
                                             : found->second;
    }

    // Add the given color processor. Be careful -- if a matching one is
    // already in the table, just return the existing one. If they pass
    // in an empty handle, just return it.
    ColorProcessorHandle addproc(const ColorProcCacheKey& key,
                                 ColorProcessorHandle handle)
    {
        if (!handle)
            return handle;
        spin_rw_write_lock lock(m_mutex);
        auto found = colorprocmap.find(key);
        if (found == colorprocmap.end()) {
            // No equivalent item in the map. Add this one.
            colorprocmap[key] = handle;
            ++colorprocs_created;
        } else {
            // There's already an equivalent one. Oops. Discard this one and
            // return the one already in the map.
            handle = found->second;
        }
        return handle;
    }

    // The properties get_chromaticities() and get_transfer_function_gamma()
    // report.
    Properties properties(string_view colorspace) const;

    int getNumColorSpaces() const { return (int)colorspaces.size(); }

    const char* getColorSpaceNameByIndex(int index) const
    {
        return colorspaces[index].name.c_str();
    }

    string_view resolve(string_view name) const;

    // Note: Uses std::format syntax
    template<typename... Args>
    void error(const char* fmt, const Args&... args) const
    {
        spin_rw_write_lock lock(m_mutex);
        m_error = Strutil::fmt::format(fmt, args...);
    }
    std::string geterror(bool clear = true) const
    {
        std::string err;
        spin_rw_write_lock lock(m_mutex);
        if (clear) {
            std::swap(err, m_error);
        } else {
            err = m_error;
        }
        return err;
    }
    bool haserror() const
    {
        spin_rw_read_lock lock(m_mutex);
        return !m_error.empty();
    }
    void clear_error()
    {
        spin_rw_write_lock lock(m_mutex);
        m_error.clear();
    }

    const std::string& configname() const { return m_configname; }
    void configname(string_view name) { m_configname = name; }

    OCIO::ConstCPUProcessorRcPtr
    get_to_builtin_cpu_proc(const char* my_from, const char* builtin_to) const;

    bool isColorSpaceLinear(string_view name) const;

    bool isData(string_view name) const;

private:
    // Return the CSInfo flags for the given color space name
    int flags(string_view name)
    {
        CSInfo* cs = find(name);
        if (!cs)
            return 0;
        examine(cs);
        spin_rw_read_lock lock(m_mutex);
        return cs->flags();
    }

    // Set cs.flag to include any bits in flagval.
    void setflag(CSInfo& cs, int flagval)
    {
        spin_rw_write_lock lock(m_mutex);
        cs.setflag(flagval);
    }

    // Set cs.flag to include any bits in flagval, and also if alias is not
    // yet set, set it to cs.name.
    void setflag(CSInfo& cs, int flagval, std::string& alias)
    {
        spin_rw_write_lock lock(m_mutex);
        cs.setflag(flagval, alias);
    }

    void inventory();

    // Set the flags for the given color space and canonical name, if we can
    // make a guess based on the name. This is very inexpensive. This should
    // only be called from within a lock of the mutex.
    void classify_by_name(CSInfo& cs);

    // Set the flags for the given color space and canonical name, trying some
    // tricks to deduce the color space from the primaries, white point, and
    // transfer function. This is more expensive, and might only work for OCIO
    // 2.2 and above. This should only be called from within a lock of the
    // mutex.
    void classify_by_conversions(CSInfo& cs);

    // Apply more heuristics to try to deduce more color space information.
    void reclassify_heuristics(CSInfo& cs);

    // If the CSInfo hasn't yet been "examined" (fully classified by all
    // heuristics), do so. This should NOT be called from within a lock of the
    // mutex.
    void examine(CSInfo* cs)
    {
        if (!cs->examined) {
            spin_rw_write_lock lock(m_mutex);
            if (!cs->examined) {
                classify_by_name(*cs);
                classify_by_conversions(*cs);
                reclassify_heuristics(*cs);
                cs->examined = true;
            }
        }
    }

    void debug_print_aliases()
    {
        DBG("Aliases: scene_linear={}   lin_srgb={}   srgb_display={}   srgb_scene={}   ACEScg={}   Rec709={}\n",
            scene_linear_alias, lin_srgb_alias, srgb_display_alias,
            srgb_scene_alias, ACEScg_alias, Rec709_alias);
    }

    // For OCIO 2.3+, we can ask for the equivalent of some built-in
    // color spaces.
    void identify_builtin_equivalents();

    bool check_same_as_builtin_transform(const char* my_from,
                                         const char* builtin_to) const;
    bool test_conversion_yields(const char* from, const char* to,
                                cspan<Imath::C3f> test_colors,
                                cspan<Imath::C3f> result_colors) const;
    const char* IdentifyBuiltinColorSpace(const char* name) const;
};



// ColorConfig utility to take inventory of the color spaces available.
// It sets up knowledge of "linear", "srgb_rec709_display", "Rec709", etc,
// even if the underlying OCIO configuration lacks them.
void
ColorConfig::Impl::inventory()
{
    DBG("inventorying config {}\n", configname());
    if (config_ && !disable_ocio) {
        try {
            bool nonraw = false;
            // In older ACES configs the display color spaces are inactive but
            // they are essential for interop IDs like srgb_rec709_display to
            // work.
            const int numcolorspaces
                = config_->getNumColorSpaces(OCIO::SEARCH_REFERENCE_SPACE_ALL,
                                             OCIO::COLORSPACE_ALL);
            for (int i = 0; i < numcolorspaces; ++i)
                nonraw |= !Strutil::iequals(config_->getColorSpaceNameByIndex(
                                                OCIO::SEARCH_REFERENCE_SPACE_ALL,
                                                OCIO::COLORSPACE_ALL, i),
                                            "raw");
            if (nonraw) {
                for (int i = 0; i < numcolorspaces; ++i) {
                    add(config_->getColorSpaceNameByIndex(
                            OCIO::SEARCH_REFERENCE_SPACE_ALL,
                            OCIO::COLORSPACE_ALL, i),
                        i);
                }
                for (auto&& cs : colorspaces)
                    cs.active = false;
                const int numactive = config_->getNumColorSpaces(
                    OCIO::SEARCH_REFERENCE_SPACE_ALL, OCIO::COLORSPACE_ACTIVE);
                for (int i = 0; i < numactive; ++i) {
                    if (CSInfo* cs = find(config_->getColorSpaceNameByIndex(
                            OCIO::SEARCH_REFERENCE_SPACE_ALL,
                            OCIO::COLORSPACE_ACTIVE, i))) {
                        cs->active = true;
                    }
                }
                for (auto&& cs : colorspaces)
                    classify_by_name(cs);
                OCIO::ConstColorSpaceRcPtr lin = config_->getColorSpace(
                    "scene_linear");
                if (lin)
                    scene_linear_alias = lin->getName();
                return;  // If any non-"raw" spaces were defined, we're done
            }
        } catch (std::exception& e) {
            DBG("OCIO exception in inventory: {}", e.what());
        }
    }

    // If we had some kind of bogus configuration that seemed to define
    // only a "raw" color space and nothing else, that's useless, so
    // figure out our own way to move forward.
    config_.reset();

    // If there was no configuration, or we didn't compile with OCIO
    // support at all, register a few basic names we know about.
    // For the "no OCIO / no config" case, we assume an unsophisticated
    // color pipeline where "linear" and the like are all assumed to use
    // Rec709/sRGB color primaries.
    int linflags = CSInfo::is_linear_response | CSInfo::is_scene_linear
                   | CSInfo::is_lin_srgb;
    add("linear", 0, linflags);
    add("scene_linear", 0, linflags);
    add("default", 0, linflags);
    add("rgb", 0, linflags);
    add("RGB", 0, linflags);
    add("lin_rec709_scene", 0, linflags);
    add("lin_srgb", 0, linflags);
    add("lin_rec709", 0, linflags);
    add("srgb_rec709_display", 1, CSInfo::is_srgb_display);
    add("srgb_rec709_scene", 1, CSInfo::is_srgb_scene);
    add("sRGB", 1, CSInfo::is_srgb_scene);
    add("Rec709", 2, CSInfo::is_Rec709);

    for (auto&& cs : colorspaces)
        classify_by_name(cs);
}



inline bool
close_colors(cspan<Imath::C3f> a, cspan<Imath::C3f> b)
{
    OIIO_DASSERT(a.size() == b.size());
    for (size_t i = 0, e = a.size(); i < e; ++i)
        if (std::abs(a[i].x - b[i].x) > 1.0e-3f
            || std::abs(a[i].y - b[i].y) > 1.0e-3f
            || std::abs(a[i].z - b[i].z) > 1.0e-3f)
            return false;
    return true;
}



OCIO::ConstCPUProcessorRcPtr
ColorConfig::Impl::get_to_builtin_cpu_proc(const char* my_from,
                                           const char* builtin_to) const
{
    try {
        auto proc = OCIO::Config::GetProcessorToBuiltinColorSpace(config_,
                                                                  my_from,
                                                                  builtin_to);
        return proc ? proc->getOptimizedCPUProcessor(ocio_optimization)
                    : OCIO::ConstCPUProcessorRcPtr();
    } catch (...) {
        return {};
    }
}



// Is this config's `my_from` color space equivalent to the built-in
// `builtin_to` color space? Find out by transforming the primaries, white,
// and half white and see if the results indicate that it was the identity
// transform (or close enough).
bool
ColorConfig::Impl::check_same_as_builtin_transform(const char* my_from,
                                                   const char* builtin_to) const
{
    if (disable_builtin_configs)
        return false;
    auto proc = get_to_builtin_cpu_proc(my_from, builtin_to);
    if (proc) {
        Imath::C3f colors[n_test_colors];
        std::copy(test_colors, test_colors + n_test_colors, colors);
        proc->apply(OCIO::PackedImageDesc(colors, n_test_colors, 1, 3));
        if (close_colors(colors, test_colors))
            return true;
    }
    return false;
}



// If we transform test_colors from "from" to "to" space, do we get
// result_colors? This is a building block for deducing some color spaces.
bool
ColorConfig::Impl::test_conversion_yields(const char* from, const char* to,
                                          cspan<Imath::C3f> test_colors,
                                          cspan<Imath::C3f> result_colors) const
{
    auto proc = m_self->createColorProcessor(from, to);
    if (!proc)
        return false;
    OIIO_DASSERT(test_colors.size() == result_colors.size());
    auto n             = test_colors.size();
    Imath::C3f* colors = OIIO_ALLOCA(Imath::C3f, n);
    std::copy(test_colors.data(), test_colors.data() + n, colors);
    proc->apply((float*)colors, int(n), 1, 3, sizeof(float), 3 * sizeof(float),
                int(n) * 3 * sizeof(float));
    return close_colors({ colors, n }, result_colors);
}



static bool
transform_has_Lut3D(string_view name, OCIO::ConstTransformRcPtr transform)
{
    using namespace OCIO;
    auto ttype = transform ? transform->getTransformType() : -1;
    if (ttype == TRANSFORM_TYPE_LUT3D || ttype == TRANSFORM_TYPE_COLORSPACE
        || ttype == TRANSFORM_TYPE_FILE || ttype == TRANSFORM_TYPE_LOOK
        || ttype == TRANSFORM_TYPE_DISPLAY_VIEW) {
        return true;
    }
    if (ttype == TRANSFORM_TYPE_GROUP) {
        auto group = dynamic_cast<const GroupTransform*>(transform.get());
        for (int i = 0, n = group->getNumTransforms(); i < n; ++i) {
            if (transform_has_Lut3D("", group->getTransform(i)))
                return true;
        }
    }
    if (name.size() && ttype >= 0)
        DBG("{} has type {}\n", name, ttype);
    return false;
}



void
ColorConfig::Impl::classify_by_name(CSInfo& cs)
{
    // General heuristics based on the names -- for a few canonical names,
    // believe them! Woe be unto the poor soul who names a color space "sRGB"
    // or "ACEScg" and it's really something entirely different.
    if (Strutil::iequals(cs.name, "srgb_rec709_display")
        || Strutil::iequals(cs.name, "srgb_display")
        || Strutil::iequals(cs.name, "sRGB - Display")) {
        cs.setflag(CSInfo::is_srgb_display, srgb_display_alias);
    } else if (Strutil::iequals(cs.name, "srgb_rec709_scene")
               || Strutil::iequals(cs.name, "srgb_tx")
               || Strutil::iequals(cs.name, "srgb_texture")
               || Strutil::iequals(cs.name, "srgb texture")
               || Strutil::iequals(cs.name, "sRGB - Texture")
               || Strutil::iequals(cs.name, "sRGB")) {
        cs.setflag(CSInfo::is_srgb_scene, srgb_scene_alias);
    } else if (Strutil::iequals(cs.name, "lin_rec709_scene")
               || Strutil::iequals(cs.name, "lin_rec709")
               || Strutil::iequals(cs.name, "Linear Rec.709 (sRGB)")
               || Strutil::iequals(cs.name, "lin_srgb")
               || Strutil::iequals(cs.name, "linear")) {
        cs.setflag(CSInfo::is_lin_srgb | CSInfo::is_linear_response,
                   lin_srgb_alias);
    } else if (Strutil::iequals(cs.name, "ACEScg")
               || Strutil::iequals(cs.name, "lin_ap1_scene")
               || Strutil::iequals(cs.name, "lin_ap1")) {
        cs.setflag(CSInfo::is_ACEScg | CSInfo::is_linear_response,
                   ACEScg_alias);
    } else if (Strutil::iequals(cs.name, "Rec709")) {
        cs.setflag(CSInfo::is_Rec709, Rec709_alias);
    } else if (config_
               && Strutil::iequals(cs.name, config_->getCanonicalName("data"))) {
        cs.setflag(CSInfo::is_data);
    }
#ifdef OIIO_SITE_spi
    // Ugly SPI-specific hacks, so sorry
    else if (Strutil::starts_with(cs.name, "cgln")) {
        cs.setflag(CSInfo::is_ACEScg | CSInfo::is_linear_response,
                   ACEScg_alias);
    } else if (cs.name == "srgbf" || cs.name == "srgbh" || cs.name == "srgb16"
               || cs.name == "srgb8") {
        cs.setflag(CSInfo::is_srgb_scene, srgb_scene_alias);
    } else if (cs.name == "srgblnf" || cs.name == "srgblnh"
               || cs.name == "srgbln16" || cs.name == "srgbln8") {
        cs.setflag(CSInfo::is_lin_srgb, lin_srgb_alias);
    } else if (Strutil::starts_with(cs.name, "nc")) {
        cs.setflag(CSInfo::is_data);
        DBG("Classifying {} as data based on SPI name\n", cs.name);
    }
#endif

    // Set up some canonical names
    if (cs.flags() & CSInfo::is_srgb_display)
        cs.canonical = "srgb_rec709_display";
    else if (cs.flags() & CSInfo::is_srgb_scene)
        cs.canonical = "srgb_rec709_scene";
    else if (cs.flags() & CSInfo::is_lin_srgb)
        cs.canonical = "lin_rec709_scene";
    else if (cs.flags() & CSInfo::is_ACEScg)
        cs.canonical = "lin_ap1_scene";
    else if (cs.flags() & CSInfo::is_Rec709)
        cs.canonical = "Rec709";
    if (cs.canonical.size()) {
        DBG("classify by name identified '{}' as canonical {}\n", cs.name,
            cs.canonical);
        cs.examined = true;
    }
}



void
ColorConfig::Impl::classify_by_conversions(CSInfo& cs)
{
    DBG("classifying by conversions {}\n", cs.name);
    if (cs.examined)
        return;  // Already classified

    if (isColorSpaceLinear(cs.name))
        cs.setflag(CSInfo::is_linear_response);
    if (cs.ocio_cs && cs.ocio_cs->isData()) {
        cs.setflag(CSInfo::is_data);
        DBG("Classifying {} as data isData() [1]\n", cs.name);
    }

    // If the name didn't already tell us what it is, and we have a new enough
    // OCIO that has built-in configs, test whether this color space is
    // equivalent to one of a few particular built-in color spaces. That lets
    // us identify some color spaces even if they are named something
    // nonstandard. Skip this part if the color space we're classifying is
    // itself part of the built-in config -- in that case, it will already be
    // tagged correctly by the name above.
    if (!(cs.flags() & CSInfo::is_known) && config_ && !disable_ocio
        && !m_config_is_built_in) {
        using namespace OCIO;
        try {
            cs.ocio_cs = config_->getColorSpace(cs.name.c_str());
            if (transform_has_Lut3D(cs.name, cs.ocio_cs->getTransform(
                                                 COLORSPACE_DIR_TO_REFERENCE))
                || transform_has_Lut3D(cs.name,
                                       cs.ocio_cs->getTransform(
                                           COLORSPACE_DIR_FROM_REFERENCE))) {
                // Skip things with LUT3d because they are expensive due to LUT
                // inversion costs, and they're not gonna be our favourite
                // canonical spaces anyway.
                // DBG("{} has LUT3\n", cs.name);
            } else if (check_same_as_builtin_transform(cs.name.c_str(),
                                                       "srgb_display")) {
                cs.setflag(CSInfo::is_srgb_display, srgb_display_alias);
            } else if (check_same_as_builtin_transform(cs.name.c_str(),
                                                       "srgb_tx")) {
                cs.setflag(CSInfo::is_srgb_scene, srgb_scene_alias);
            } else if (check_same_as_builtin_transform(cs.name.c_str(),
                                                       "lin_srgb")) {
                cs.setflag(CSInfo::is_lin_srgb | CSInfo::is_linear_response,
                           lin_srgb_alias);
            } else if (check_same_as_builtin_transform(cs.name.c_str(),
                                                       "ACEScg")) {
                cs.setflag(CSInfo::is_ACEScg | CSInfo::is_linear_response,
                           ACEScg_alias);
            }
            if (cs.ocio_cs->isData()) {
                cs.setflag(CSInfo::is_data);
                DBG("Classifying {} as data isData() [2]\n", cs.name);
            }
        } catch (std::exception& e) {
            DBG("OCIO exception in classify_by_conversions: {}", e.what());
        }
    }

    // Set up some canonical names
    if (cs.flags() & CSInfo::is_srgb_display)
        cs.canonical = "srgb_rec709_display";
    else if (cs.flags() & CSInfo::is_srgb_scene)
        cs.canonical = "srgb_rec709_scene";
    else if (cs.flags() & CSInfo::is_lin_srgb)
        cs.canonical = "lin_rec709_scene";
    else if (cs.flags() & CSInfo::is_ACEScg)
        cs.canonical = "lin_ap1_scene";
    else if (cs.flags() & CSInfo::is_Rec709)
        cs.canonical = "Rec709";
}



void
ColorConfig::Impl::reclassify_heuristics(CSInfo& cs)
{
#if OCIO_VERSION_HEX < MAKE_OCIO_VERSION_HEX(2, 2, 0)
    // Extra checks for OCIO < 2.2. For >= 2.2, there is no need, we
    // already figured this out using the built-in configs.
    if (!(cs.flags() & CSInfo::is_known)) {
        // If this isn't one of the known color spaces, let's try some
        // tricks!
        static float srgb05 = linear_to_sRGB(0.5f);
        static Imath::C3f lin_srgb_to_srgb_results[n_test_colors]
            = { { 1, 0, 0 },
                { 0, 1, 0 },
                { 0, 0, 1 },
                { 1, 1, 1 },
                { srgb05, srgb05, srgb05 } };
        // If there is a known srgb space, and transforming our test
        // colors from "this cs" to srgb gives us what we expect for a
        // lin_srgb->srgb, then guess what? -- this is lin_srgb!
        const std::string& srgb_alias = srgb_scene_alias.size()
                                            ? srgb_scene_alias
                                            : srgb_display_alias;
        if (srgb_alias.size()
            && test_conversion_yields(cs.name.c_str(), srgb_alias.c_str(),
                                      test_colors, lin_srgb_to_srgb_results)) {
            setflag(cs, CSInfo::is_lin_srgb | CSInfo::is_linear_response,
                    lin_srgb_alias);
            cs.canonical = "lin_srgb";
        }
    }
#endif
}



void
ColorConfig::Impl::identify_builtin_equivalents()
{
    if (disable_builtin_configs)
        return;
    Timer timer;
    if (auto n = IdentifyBuiltinColorSpace("srgb_display")) {
        if (CSInfo* cs = find(n)) {
            cs->setflag(CSInfo::is_srgb_display, srgb_display_alias);
            DBG("Identified {} = builtin '{}'\n", "srgb_rec709_display",
                cs->name);
        }
    } else {
        DBG("No config space identified as srgb_display\n");
    }
    if (auto n = IdentifyBuiltinColorSpace("srgb_tx")) {
        if (CSInfo* cs = find(n)) {
            cs->setflag(CSInfo::is_srgb_scene, srgb_scene_alias);
            DBG("Identified {} = builtin '{}'\n", "srgb_rec709_scene",
                cs->name);
        }
    } else {
        DBG("No config space identified as srgb_scene\n");
    }
    DBG("identify_builtin_equivalents srgb took {:0.2f}s\n", timer.lap());
    if (auto n = IdentifyBuiltinColorSpace("lin_srgb")) {
        if (CSInfo* cs = find(n)) {
            cs->setflag(CSInfo::is_lin_srgb | CSInfo::is_linear_response,
                        lin_srgb_alias);
            DBG("Identified {} = builtin '{}'\n", "lin_rec709_scene", cs->name);
        }
    } else {
        DBG("No config space identified as lin_srgb\n");
    }
    DBG("identify_builtin_equivalents lin_srgb took {:0.2f}s\n", timer.lap());
    if (auto n = IdentifyBuiltinColorSpace("ACEScg")) {
        if (CSInfo* cs = find(n)) {
            cs->setflag(CSInfo::is_ACEScg | CSInfo::is_linear_response,
                        ACEScg_alias);
            DBG("Identified {} = builtin '{}'\n", "ACEScg", cs->name);
        }
    } else {
        DBG("No config space identified as acescg\n");
    }
    DBG("identify_builtin_equivalents acescg took {:0.2f}s\n", timer.lap());
}



const char*
ColorConfig::Impl::IdentifyBuiltinColorSpace(const char* name) const
{
    if (!config_ || disable_builtin_configs)
        return nullptr;
    try {
        return OCIO::Config::IdentifyBuiltinColorSpace(config_, builtinconfig_,
                                                       name);
    } catch (std::exception& e) {
        DBG("OCIO exception in IdentifyBuiltinColorSpace: {}", e.what());
    }
    return nullptr;
}



ColorConfig::ColorConfig(string_view filename)
    : m_impl(new ColorConfig::Impl(this, filename))
{
}



ColorConfig::~ColorConfig()
{
}



// OCIO before 2.3.2 drops the default view transform name when copying a
// config, which changes display transforms; keep it.
static OCIO::ConfigRcPtr
copy_config(const OCIO::ConstConfigRcPtr& config)
{
    auto copy = config->createEditableCopy();
#if OCIO_VERSION_HEX < MAKE_OCIO_VERSION_HEX(2, 3, 2)
    const char* view_transform = config->getDefaultViewTransformName();
    if (view_transform && *view_transform)
        copy->setDefaultViewTransformName(view_transform);
#endif
    return copy;
}



// OIIO doctoring of OCIO configs for different default file rules. Currently,
// we only do this for built-in configs.
static void
fix_config_file_rules(OCIO::ConfigRcPtr& config)
{
    OIIO_CONTRACT_ASSERT(config);
    DBG("Fixing up rules:\n");
#if 1
    // Just start with a clean slate
    auto rules = OCIO::FileRules::Create();
#else
    // Alternate universe: Start with the existing rules
    auto rules = config->getFileRules()->createEditableCopy();
#endif
    for (size_t i = 0, e = rules->getNumEntries(); i != e; ++i) {
        DBG("  rule {}/{}: pat='{}' ext='{}' -> \"{}\"\n", i, rules->getName(i),
            rules->getRegex(i), rules->getExtension(i),
            rules->getColorSpace(i));
#if 0
        // If we wanted to doctor just the exr rule, here's how:
        if (Strutil::iequals(rules->getExtension(i), "exr")) {
            // Change the rule for exr extension, if it exists, to "unknown".
            // Make no assumptions. OCIO's built-in configs think it should be
            // ACES2065-1, which is almost never right.
            rules->setColorSpace(i, "unknown");
            DBG("    changed cs to \"{}\"\n", rules->getColorSpace(i));
        } else
#endif
        if (!strcmp(rules->getName(i), "Default")) {
            // Default rule or one that matches everything -- for OIIO, we
            // just want to change this to unknown. We made decisions about
            // default per-file-format color space decisions in the individual
            // readers. We don't even consider file extension to be reliable
            // evidence of the file type.
            rules->setColorSpace(i, "unknown");
            DBG("    changed cs to \"{}\"\n", rules->getColorSpace(i));
        }
    }

    // But make the path search rule (look for the right-most color space name
    // embedded in the path) have precedence over file naming rules.
    rules->insertPathSearchRule(0);
    config->setFileRules(rules);
}



bool
ColorConfig::Impl::init(string_view filename)
{
    OIIO_MAYBE_UNUSED Timer timer;
    bool ok = true;

    auto oldlog = OCIO::GetLoggingLevel();
    OCIO::SetLoggingLevel(OCIO::LOGGING_LEVEL_NONE);

    try {
        auto cfg = OCIO::Config::CreateFromFile("ocio://default");
        OIIO_CONTRACT_ASSERT(cfg);
        builtinconfig_ = copy_config(cfg);
        fix_config_file_rules(builtinconfig_);
    } catch (std::exception& e) {
        error("Error making OCIO built-in config: {}", e.what());
    }

    // If no filename was specified, use env $OCIO
    if (filename.empty())
        filename = Sysutil::getenv("OCIO");
    if (filename.empty() && !disable_builtin_configs)
        filename = "ocio://default";
    if (filename.size() && !OIIO::Filesystem::exists(filename)
        && !Strutil::istarts_with(filename, "ocio://")) {
        error("Requested non-existent OCIO config \"{}\"", filename);
    } else {
        // Either filename passed, or taken from $OCIO, and it seems to exist
        try {
            configname(filename);
            auto cfg = OCIO::Config::CreateFromFile(
                std::string(filename).c_str());
            if (cfg)
                config_ = copy_config(cfg);
            if (config_ && Strutil::istarts_with(filename, "ocio://"))
                fix_config_file_rules(config_);
        } catch (std::exception& e) {
            error("Error reading OCIO config \"{}\": {}", filename, e.what());
        } catch (...) {
            error("Error reading OCIO config \"{}\"", filename);
        }
    }
    OCIO::SetLoggingLevel(oldlog);

    ok = config_.get() != nullptr;

    DBG("OCIO config {} loaded in {:0.2f} seconds\n", filename, timer.lap());

    inventory();
    // NOTE: inventory already does classify_by_name

    DBG("\nIDENTIFY BUILTIN EQUIVALENTS\n");
    identify_builtin_equivalents();  // OCIO 2.3+ only
    DBG("OCIO 2.3+ builtin equivalents in {:0.2f} seconds\n", timer.lap());

#if 1
    for (auto&& cs : colorspaces) {
        // examine(&cs);
        DBG("Color space '{}':\n", cs.name);
        if (cs.flags() & CSInfo::is_srgb_display)
            DBG("'{}' is srgb_display\n", cs.name);
        if (cs.flags() & CSInfo::is_srgb_scene)
            DBG("'{}' is srgb_scene\n", cs.name);
        if (cs.flags() & CSInfo::is_lin_srgb)
            DBG("'{}' is lin_srgb\n", cs.name);
        if (cs.flags() & CSInfo::is_ACEScg)
            DBG("'{}' is ACEScg\n", cs.name);
        if (cs.flags() & CSInfo::is_Rec709)
            DBG("'{}' is Rec709\n", cs.name);
        if (cs.flags() & CSInfo::is_linear_response)
            DBG("'{}' has linear response\n", cs.name);
        if (cs.flags() & CSInfo::is_scene_linear)
            DBG("'{}' is scene_linear\n", cs.name);
        if (cs.flags())
            DBG("\n");
    }
#endif
    debug_print_aliases();
    DBG("OCIO config {} classified in {:0.2f} seconds\n", filename,
        timer.lap());

    return ok;
}



bool
ColorConfig::reset(string_view filename)
{
    if (m_impl
        && (filename == getImpl()->configname()
            || (filename == ""
                && getImpl()->configname() == "ocio://default"))) {
        // Request to reset to the config we're already using. Just return,
        // don't do anything expensive.
        return true;
    }

    m_impl.reset(new ColorConfig::Impl(this, filename));
    return m_impl->init_once();
}



ColorConfig::Impl*
ColorConfig::getImpl() const
{
    m_impl->init_once();
    return m_impl.get();
}



bool
ColorConfig::has_error() const
{
    return (getImpl()->haserror());
}



std::string
ColorConfig::geterror(bool clear) const
{
    return getImpl()->geterror(clear);
}



int
ColorConfig::getNumColorSpaces() const
{
    return (int)getImpl()->getNumColorSpaces();
}



const char*
ColorConfig::getColorSpaceNameByIndex(int index) const
{
    return getImpl()->getColorSpaceNameByIndex(index);
}



int
ColorConfig::getColorSpaceIndex(string_view name) const
{
    // Check for exact matches
    for (int i = 0, e = getNumColorSpaces(); i < e; ++i)
        if (Strutil::iequals(getColorSpaceNameByIndex(i), name))
            return i;
    // Check for aliases and equivalents
    for (int i = 0, e = getNumColorSpaces(); i < e; ++i)
        if (equivalent(getColorSpaceNameByIndex(i), name))
            return i;
    return -1;
}



const char*
ColorConfig::getColorSpaceFamilyByName(string_view name) const
{
    if (getImpl()->config_ && !disable_ocio) {
        try {
            OCIO::ConstColorSpaceRcPtr c = getImpl()->config_->getColorSpace(
                std::string(name).c_str());
            if (c)
                return c->getFamily();
        } catch (std::exception& e) {
            DBG("OCIO exception in getColorSpaceFamilyByName: {}", e.what());
        }
    }
    return nullptr;
}



std::vector<std::string>
ColorConfig::getColorSpaceNames() const
{
    std::vector<std::string> result;
    int n = getNumColorSpaces();
    result.reserve(n);
    for (int i = 0; i < n; ++i)
        result.emplace_back(getColorSpaceNameByIndex(i));
    return result;
}

int
ColorConfig::getNumRoles() const
{
    if (getImpl()->config_ && !disable_ocio)
        return getImpl()->config_->getNumRoles();
    return 0;
}

const char*
ColorConfig::getRoleByIndex(int index) const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getRoleName(index);
    } catch (std::exception& e) {
        DBG("OCIO exception in getRoleByIndex: {}", e.what());
    }
    return nullptr;
}


std::vector<std::string>
ColorConfig::getRoles() const
{
    std::vector<std::string> result;
    for (int i = 0, e = getNumRoles(); i != e; ++i)
        result.emplace_back(getRoleByIndex(i));
    return result;
}



int
ColorConfig::getNumLooks() const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getNumLooks();
    } catch (std::exception& e) {
        DBG("OCIO exception in getNumLooks: {}", e.what());
    }
    return 0;
}



const char*
ColorConfig::getLookNameByIndex(int index) const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getLookNameByIndex(index);
    } catch (std::exception& e) {
        DBG("OCIO exception in getLookNameByIndex: {}", e.what());
    }
    return nullptr;
}



std::vector<std::string>
ColorConfig::getLookNames() const
{
    std::vector<std::string> result;
    for (int i = 0, e = getNumLooks(); i != e; ++i)
        result.emplace_back(getLookNameByIndex(i));
    return result;
}



bool
ColorConfig::isColorSpaceLinear(string_view name) const
{
    return getImpl()->isColorSpaceLinear(name);
}



bool
ColorConfig::isColorSpaceActive(string_view name) const
{
    const CSInfo* cs = getImpl()->find(getImpl()->resolve(name));
    return cs ? cs->active : true;
}



bool
ColorConfig::Impl::isColorSpaceLinear(string_view name) const
{
    if (config_ && !disable_builtin_configs && !disable_ocio) {
        try {
            return config_->isColorSpaceLinear(c_str(name),
                                               OCIO::REFERENCE_SPACE_SCENE)
                   || config_->isColorSpaceLinear(c_str(name),
                                                  OCIO::REFERENCE_SPACE_DISPLAY);
        } catch (...) {
            return false;
        }
    }
    return Strutil::iequals(name, "linear")
           || Strutil::istarts_with(name, "linear ")
           || Strutil::istarts_with(name, "linear_")
           || Strutil::istarts_with(name, "lin_")
           || Strutil::iends_with(name, "_linear")
           || Strutil::iends_with(name, "_lin");
}



bool
ColorConfig::isData(string_view name) const
{
    return getImpl()->isData(name);
}



bool
ColorConfig::Impl::isData(string_view name) const
{
    // Look the name up as conversions do (names, aliases and roles, in any
    // case, and namespaced IDs), and honor the color space's own isdata.
    OCIO::ConstColorSpaceRcPtr cs;
    if (config_ && !disable_ocio) {
        try {
            cs = config_->getColorSpace(c_str(resolve(name)));
        } catch (...) {
        }
        if (cs && cs->isData())
            return true;
    }
    const CSInfo* csi = find(cs ? string_view(cs->getName()) : name);
    return csi && (csi->flags() & CSInfo::is_data);
}



std::vector<std::string>
ColorConfig::getAliases(string_view color_space) const
{
    std::vector<std::string> result;
    auto config = getImpl()->config_;
    if (config) {
        auto cs = config->getColorSpace(c_str(color_space));
        if (cs) {
            for (int i = 0, e = cs->getNumAliases(); i < e; ++i)
                result.emplace_back(cs->getAlias(i));
        }
    }
    return result;
}



const char*
ColorConfig::getColorSpaceNameByRole(string_view role) const
{
    if (getImpl()->config_ && !disable_ocio) {
        try {
            OCIO::ConstColorSpaceRcPtr c = getImpl()->config_->getColorSpace(
                std::string(role).c_str());
            // DBG("looking first for named color space {} -> {}\n", role,
            //     c ? c->getName() : "not found");
            // Catch special case of obvious name synonyms
            if (!c
                && (Strutil::iequals(role, "RGB")
                    || Strutil::iequals(role, "default")))
                role = string_view("linear");
            if (!c && Strutil::iequals(role, "linear"))
                c = getImpl()->config_->getColorSpace("scene_linear");
            if (!c && Strutil::iequals(role, "scene_linear"))
                c = getImpl()->config_->getColorSpace("linear");
            if (!c && Strutil::iequals(role, "srgb")) {
                c = getImpl()->config_->getColorSpace("sRGB - Texture");
                // DBG("Unilaterally substituting {} -> '{}'\n", role,
                //                c->getName());
            }

            if (c) {
                // DBG("found color space {} for role {}\n", c->getName(),
                //                role);
                return c->getName();
            }
        } catch (std::exception& e) {
            DBG("OCIO exception in getColorSpaceNameByRole: {}", e.what());
        }
    }

    // No OCIO at build time, or no OCIO configuration at run time
    if (Strutil::iequals(role, "linear")
        || Strutil::iequals(role, "scene_linear"))
        return "linear";

    return nullptr;  // Dunno what role
}



TypeDesc
ColorConfig::getColorSpaceDataType(string_view name, int* bits) const
{
    if (getImpl()->config_ && !disable_ocio) {
        try {
            OCIO::ConstColorSpaceRcPtr c = getImpl()->config_->getColorSpace(
                std::string(name).c_str());
            if (c) {
                OCIO::BitDepth b = c->getBitDepth();
                switch (b) {
                case OCIO::BIT_DEPTH_UNKNOWN: return TypeDesc::UNKNOWN;
                case OCIO::BIT_DEPTH_UINT8: *bits = 8; return TypeDesc::UINT8;
                case OCIO::BIT_DEPTH_UINT10:
                    *bits = 10;
                    return TypeDesc::UINT16;
                case OCIO::BIT_DEPTH_UINT12:
                    *bits = 12;
                    return TypeDesc::UINT16;
                case OCIO::BIT_DEPTH_UINT14:
                    *bits = 14;
                    return TypeDesc::UINT16;
                case OCIO::BIT_DEPTH_UINT16:
                    *bits = 16;
                    return TypeDesc::UINT16;
                case OCIO::BIT_DEPTH_UINT32:
                    *bits = 32;
                    return TypeDesc::UINT32;
                case OCIO::BIT_DEPTH_F16: *bits = 16; return TypeDesc::HALF;
                case OCIO::BIT_DEPTH_F32: *bits = 32; return TypeDesc::FLOAT;
                }
            }
        } catch (std::exception& e) {
            DBG("OCIO exception in getColorSpaceDataType: {}", e.what());
        }
    }
    return TypeUnknown;
}



int
ColorConfig::getNumDisplays() const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getNumDisplays();
    } catch (std::exception& e) {
        DBG("OCIO exception in getNumDisplays: {}", e.what());
    }
    return 0;
}



const char*
ColorConfig::getDisplayNameByIndex(int index) const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getDisplay(index);
    } catch (std::exception& e) {
        DBG("OCIO exception in getDisplayNameByIndex: {}", e.what());
    }
    return nullptr;
}



std::vector<std::string>
ColorConfig::getDisplayNames() const
{
    std::vector<std::string> result;
    for (int i = 0, e = getNumDisplays(); i != e; ++i)
        result.emplace_back(getDisplayNameByIndex(i));
    return result;
}



int
ColorConfig::getNumViews(string_view display) const
{
    if (display.empty())
        display = getDefaultDisplayName();
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getNumViews(
                std::string(display).c_str());
    } catch (std::exception& e) {
        DBG("OCIO exception in getNumViews: {}", e.what());
    }
    return 0;
}



const char*
ColorConfig::getViewNameByIndex(string_view display, int index) const
{
    if (display.empty())
        display = getDefaultDisplayName();
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getView(std::string(display).c_str(),
                                               index);
    } catch (std::exception& e) {
        DBG("OCIO exception in getViewNameByIndex: {}", e.what());
    }
    return nullptr;
}



std::vector<std::string>
ColorConfig::getViewNames(string_view display) const
{
    std::vector<std::string> result;
    if (display.empty())
        display = getDefaultDisplayName();
    for (int i = 0, e = getNumViews(display); i != e; ++i)
        result.emplace_back(getViewNameByIndex(display, i));
    return result;
}



const char*
ColorConfig::getDefaultDisplayName() const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getDefaultDisplay();
    } catch (std::exception& e) {
        DBG("OCIO exception in getDefaultDisplayName: {}", e.what());
    }
    return nullptr;
}



const char*
ColorConfig::getDefaultViewName(string_view display) const
{
    if (display.empty() || display == "default")
        display = getDefaultDisplayName();
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getDefaultView(c_str(display));
    } catch (std::exception& e) {
        DBG("OCIO exception in getDefaultViewName: {}", e.what());
    }
    return nullptr;
}


static ustring viewing_rules_space(const OCIO::ConstConfigRcPtr& config,
                                   ustring name);

const char*
ColorConfig::getDefaultViewName(string_view display,
                                string_view inputColorSpace) const
{
    try {
        if (display.empty() || display == "default")
            display = getDefaultDisplayName();
        if (inputColorSpace.empty() || inputColorSpace == "default")
            inputColorSpace = getImpl()->config_->getColorSpaceFromFilepath(
                c_str(inputColorSpace));
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getDefaultView(
                c_str(display), viewing_rules_space(getImpl()->config_,
                                                    ustring(inputColorSpace))
                                    .c_str());
    } catch (std::exception& e) {
        DBG("OCIO exception in getDefaultViewName: {}", e.what());
    }
    return nullptr;
}


const char*
ColorConfig::getDisplayViewColorSpaceName(const std::string& display,
                                          const std::string& view) const
{
    if (getImpl()->config_ && !disable_ocio) {
        try {
            string_view name = getImpl()->config_->getDisplayViewColorSpaceName(
                c_str(display), c_str(view));
            // Handle certain Shared View cases
            if (strcmp(c_str(name), "<USE_DISPLAY_NAME>") == 0)
                name = display;
            return c_str(name);
        } catch (std::exception& e) {
            DBG("OCIO exception in getDisplayViewColorSpaceName: {}", e.what());
        }
    }
    return nullptr;
}



const char*
ColorConfig::getDisplayViewLooks(const std::string& display,
                                 const std::string& view) const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getDisplayViewLooks(display.c_str(),
                                                           view.c_str());
    } catch (std::exception& e) {
        DBG("OCIO exception in getDisplayViewLooks: {}", e.what());
    }
    return nullptr;
}



int
ColorConfig::getNumNamedTransforms() const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getNumNamedTransforms();
    } catch (std::exception& e) {
        DBG("OCIO exception in getNumNamedTransforms: {}", e.what());
    }
    return 0;
}



const char*
ColorConfig::getNamedTransformNameByIndex(int index) const
{
    try {
        if (getImpl()->config_ && !disable_ocio)
            return getImpl()->config_->getNamedTransformNameByIndex(index);
    } catch (std::exception& e) {
        DBG("OCIO exception in getNamedTransformNameByIndex: {}", e.what());
    }
    return nullptr;
}



std::vector<std::string>
ColorConfig::getNamedTransformNames() const
{
    std::vector<std::string> result;
    for (int i = 0, e = getNumNamedTransforms(); i != e; ++i)
        result.emplace_back(getNamedTransformNameByIndex(i));
    return result;
}



std::vector<std::string>
ColorConfig::getNamedTransformAliases(string_view named_transform) const
{
    std::vector<std::string> result;
    auto config = getImpl()->config_;
    if (config) {
        auto nt = config->getNamedTransform(c_str(named_transform));
        if (nt) {
            for (int i = 0, e = nt->getNumAliases(); i < e; ++i)
                result.emplace_back(nt->getAlias(i));
        }
    }
    return result;
}



std::string
ColorConfig::configname() const
{
    if (getImpl()->config_ && !disable_ocio)
        return getImpl()->configname();
    return "built-in";
}



string_view
ColorConfig::resolve(string_view name) const
{
    return getImpl()->resolve(name);
}



// Whether `id` follows the Color Interop ID syntax: lowercase tokens of the
// allowed characters, at most two ':' separators, and a non-empty base. See
// https://github.com/AcademySoftwareFoundation/ColorInterop/blob/main/Recommendations/03_ColorInteropID/ColorInteropID.md
static bool
valid_interop_id(string_view id)
{
    int colons       = 0;
    size_t token_len = 0;
    for (unsigned char c : id) {
        if (c == ':') {
            if (++colons > 2 || (token_len == 0 && colons == 1))
                return false;
            token_len = 0;
            continue;
        }
        const bool allowed = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                             || (c && strchr(".-_~/*#%^+()[]|", c));
        if (!allowed)
            return false;
        ++token_len;
    }
    return token_len != 0;
}



// A name sanitized into an ID token, as that recommendation's Annex C
// specifies, so that generated and searched IDs agree.
static std::string
sanitize_id_token(string_view name)
{
    std::vector<uint32_t> codepoints;
    Strutil::utf8_to_unicode(name, codepoints);
    std::string result;
    result.reserve(codepoints.size());
    for (uint32_t c : codepoints) {
        if (c > 127)
            result += '^';
        else if (c >= 'A' && c <= 'Z')
            result += char(c - 'A' + 'a');
        else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                 || (c && strchr(".-_~/*#%^+()[]|", int(c))))
            result += char(c);
        else {
            switch (c) {
            case ' ':
            case '\t':
            case '\n':
            case '\r': result += '_'; break;
            case '{':
            case '<': result += '('; break;
            case '}':
            case '>': result += ')'; break;
            case ',': result += '.'; break;
            case ';':
            case ':': result += '|'; break;
            case '\'':
            case '"': result += '#'; break;
            case '\\': result += '/'; break;
            default: result += '*'; break;
            }
        }
    }
    return result;
}



// The Color Interop ID search fallbacks, for a namespaced ID the config does
// not otherwise know: drop the leftmost namespace once and look for a color
// space with that name or alias (never a role), then try an on-demand
// "<config>:local:<base>" ID, which matches only this config's sanitized name.
static string_view
resolve_namespaced_id(const OCIO::Config& config, string_view name)
{
    const size_t colon = name.find(':');
    if (colon == string_view::npos || !valid_interop_id(name))
        return {};
    const std::string stripped(name.substr(colon + 1));
    if (!config.hasRole(stripped.c_str()))
        if (auto cs = config.getColorSpace(stripped.c_str()))
            return cs->getName();
    const size_t second = name.find(':', colon + 1);
    if (second == string_view::npos
        || name.substr(colon + 1, second - colon - 1) != "local"
        || !config.getName()[0]
        || name.substr(0, colon) != sanitize_id_token(config.getName()))
        return {};
    const string_view base = name.substr(second + 1);
    for (int i = 0,
             n = config.getNumColorSpaces(OCIO::SEARCH_REFERENCE_SPACE_ALL,
                                          OCIO::COLORSPACE_ALL);
         i < n; ++i) {
        auto cs = config.getColorSpace(
            config.getColorSpaceNameByIndex(OCIO::SEARCH_REFERENCE_SPACE_ALL,
                                            OCIO::COLORSPACE_ALL, i));
        if (!cs)
            continue;
        if (sanitize_id_token(cs->getName()) == base)
            return cs->getName();
        for (int a = 0, e = cs->getNumAliases(); a < e; ++a)
            if (sanitize_id_token(cs->getAlias(a)) == base)
                return cs->getName();
    }
    return {};
}



string_view
ColorConfig::Impl::resolve(string_view name) const
{
    OCIO::ConstConfigRcPtr config = config_;
    if (config && !disable_ocio) {
        try {
            OCIO::ConstColorSpaceRcPtr cs = config->getColorSpace(c_str(name));
            if (cs)
                return cs->getName();
            string_view id = resolve_namespaced_id(*config, name);
            if (!id.empty())
                return id;
        } catch (std::exception& e) {
            DBG("OCIO exception in resolve: {}", e.what());
        }
    }
    // OCIO did not know this name as a color space, role, or alias.

    // Maybe it's an informal alias of common names?
    spin_rw_write_lock lock(m_mutex);
    if ((Strutil::iequals(name, "sRGB")
         || Strutil::iequals(name, "srgb_rec709_scene"))
        && !srgb_scene_alias.empty())
        return srgb_scene_alias;
    if (Strutil::iequals(name, "srgb_rec709_display")
        && !srgb_display_alias.empty())
        return srgb_display_alias;
    if ((Strutil::iequals(name, "lin_srgb")
         || Strutil::iequals(name, "lin_rec709")
         || Strutil::iequals(name, "lin_rec709_scene")
         || Strutil::iequals(name, "linear"))
        && lin_srgb_alias.size())
        return lin_srgb_alias;
    if ((Strutil::iequals(name, "ACEScg")
         || Strutil::iequals(name, "lin_ap1_scene"))
        && !ACEScg_alias.empty())
        return ACEScg_alias;
    if (Strutil::iequals(name, "scene_linear") && !scene_linear_alias.empty()) {
        return scene_linear_alias;
    }
    if (Strutil::iequals(name, "Rec709") && Rec709_alias.size())
        return Rec709_alias;

    return name;
}



bool
ColorConfig::equivalent(string_view color_space1,
                        string_view color_space2) const
{
    // Empty color spaces never match
    if (color_space1.empty() || color_space2.empty())
        return false;
    // Easy case: matching names are the same!
    if (Strutil::iequals(color_space1, color_space2))
        return true;
    return getImpl()->equivalent(color_space1, resolve(color_space1),
                                 color_space2, resolve(color_space2));
}



bool
ColorConfig::Impl::equivalent(string_view color_space1, string_view resolved1,
                              string_view color_space2,
                              string_view resolved2) const
{
    // Empty color spaces never match
    if (color_space1.empty() || color_space2.empty())
        return false;
    // Easy case: matching names are the same!
    if (Strutil::iequals(color_space1, color_space2))
        return true;

    // If "resolved" names (after converting aliases and roles to color
    // spaces) match, they are equivalent. OCIO matches names in any case and
    // resolves them to its own spelling, so this comparison can be exact.
    if (resolved1.empty() || resolved2.empty())
        return false;
    if (resolved1 == resolved2)
        return true;

    // If the color spaces' flags (when masking only the bits that refer to
    // specific known color spaces) match, consider them equivalent.
    const int mask     = CSInfo::is_srgb_display | CSInfo::is_srgb_scene
                         | CSInfo::is_lin_srgb | CSInfo::is_ACEScg
                         | CSInfo::is_Rec709;
    const CSInfo* csi1 = find(resolved1);
    const CSInfo* csi2 = find(resolved2);
    if (csi1 && csi2) {
        int flags1 = csi1->flags() & mask;
        int flags2 = csi2->flags() & mask;
        if ((flags1 | flags2) && csi1->flags() == csi2->flags())
            return true;
        if ((csi1->canonical.size() && csi2->canonical.size())
            && Strutil::iequals(csi1->canonical, csi2->canonical))
            return true;
    }

    return false;
}



bool
equivalent_colorspace(string_view a, string_view b)
{
    return ColorConfig::default_colorconfig().equivalent(a, b);
}



inline OCIO::BitDepth
ocio_bitdepth(TypeDesc type)
{
    if (type == TypeDesc::UINT8)
        return OCIO::BIT_DEPTH_UINT8;
    if (type == TypeDesc::UINT16)
        return OCIO::BIT_DEPTH_UINT16;
    if (type == TypeDesc::UINT32)
        return OCIO::BIT_DEPTH_UINT32;
    // N.B.: OCIOv2 also supports 10, 12, and 14 bit int, but we won't
    // ever have data in that format at this stage.
    if (type == TypeDesc::HALF)
        return OCIO::BIT_DEPTH_F16;
    if (type == TypeDesc::FLOAT)
        return OCIO::BIT_DEPTH_F32;
    return OCIO::BIT_DEPTH_UNKNOWN;
}



// Custom ColorProcessor that wraps an OpenColorIO Processor.
class ColorProcessor_OCIO final : public ColorProcessor {
public:
    ColorProcessor_OCIO(OCIO::ConstProcessorRcPtr p)
        : m_p(p), m_cpuproc(p->getOptimizedCPUProcessor(ocio_optimization))
    {
    }
    ~ColorProcessor_OCIO() override {}

    bool isNoOp() const override { return m_p->isNoOp(); }
    bool hasChannelCrosstalk() const override
    {
        return m_p->hasChannelCrosstalk();
    }
    void apply(float* data, int width, int height, int channels,
               stride_t chanstride, stride_t xstride,
               stride_t ystride) const override
    {
        try {
            OCIO::PackedImageDesc pid(data, width, height, channels,
                                      OCIO::BIT_DEPTH_F32,  // For now, only float
                                      chanstride, xstride, ystride);
            m_cpuproc->apply(pid);
        } catch (std::exception& e) {
            OIIO::errorfmt("OCIO error in apply: {}\n", e.what());
            // FIXME -- some day, we should make ColorProcessor::apply return
            // a status, and we should indicate here that it failed.
        }
    }

private:
    OCIO::ConstProcessorRcPtr m_p;
    OCIO::ConstCPUProcessorRcPtr m_cpuproc;
};



// ColorProcessor that implements a matrix multiply color transformation.
class ColorProcessor_Matrix final : public ColorProcessor {
public:
    ColorProcessor_Matrix(const Imath::M44f& Matrix, bool inverse)
        : ColorProcessor(), m_M(Matrix)
    {
        if (inverse)
            m_M = m_M.inverse();
    }
    ~ColorProcessor_Matrix() override {}

    void apply(float* data, int width, int height, int channels,
               stride_t chanstride, stride_t xstride,
               stride_t ystride) const override
    {
        using namespace simd;
        if (channels == 3 && chanstride == sizeof(float)) {
            for (int y = 0; y < height; ++y) {
                char* d = (char*)data + y * ystride;
                for (int x = 0; x < width; ++x, d += xstride) {
                    vfloat4 color;
                    color.load((float*)d, 3);
                    vfloat4 xcolor = color * m_M;
                    xcolor.store((float*)d, 3);
                }
            }
        } else if (channels >= 4 && chanstride == sizeof(float)) {
            for (int y = 0; y < height; ++y) {
                char* d = (char*)data + y * ystride;
                for (int x = 0; x < width; ++x, d += xstride) {
                    vfloat4 color;
                    color.load((float*)d);
                    vfloat4 xcolor = color * m_M;
                    xcolor.store((float*)d);
                }
            }
        } else {
            channels = std::min(channels, 4);
            for (int y = 0; y < height; ++y) {
                char* d = (char*)data + y * ystride;
                for (int x = 0; x < width; ++x, d += xstride) {
                    vfloat4 color;
                    char* dc = d;
                    for (int c = 0; c < channels; ++c, dc += chanstride)
                        color[c] = *(float*)dc;
                    vfloat4 xcolor = color * m_M;
                    for (int c = 0; c < channels; ++c, dc += chanstride)
                        *(float*)dc = xcolor[c];
                }
            }
        }
    }

private:
    simd::matrix44 m_M;
};



// OpenImageIO's built-in config of color interop identities, one color space
// per ID, named by it. Parsed once, the first time a conversion needs it.
static OCIO::ConstConfigRcPtr
interop_identities_config()
{
    static const OCIO::ConstConfigRcPtr config = [] {
        std::istringstream text(
            reinterpret_cast<const char*>(interop_config_bytes));
        return OCIO::Config::CreateFromStream(text);
    }();
    return config;
}



// A conversion endpoint the active config doesn't define, but that is named
// exactly as a color interop ID, comes from the built-in identities config.
// Names, aliases, roles and named transforms the config defines keep their
// meaning. The OIIO_DISABLE_BUILTIN_OCIO_CONFIGS environment variable opts
// out.
//
// `endpoint` and `ctx` are left alone unless the identities config supplies
// the endpoint.
static void
external_endpoint(const OCIO::ConstConfigRcPtr& config, ustring name,
                  OCIO::ConstConfigRcPtr& endpoint,
                  OCIO::ConstContextRcPtr& ctx)
{
    if (disable_builtin_configs || config->getColorSpace(name.c_str())
        || config->getNamedTransform(name.c_str()))
        return;
    auto identities = interop_identities_config();
    auto cs         = identities->getColorSpace(name.c_str());
    if (cs && Strutil::iequals(name, cs->getName())) {
        endpoint = identities;
        ctx      = identities->getCurrentContext();
    }
}



// The interchange role a color space of another config reaches this config
// through: the display one for a display-referred space, the scene one
// otherwise.
static const char*
interchange_role(const OCIO::ConstColorSpaceRcPtr& cs)
{
    return cs && cs->getReferenceSpaceType() == OCIO::REFERENCE_SPACE_DISPLAY
               ? OCIO::ROLE_INTERCHANGE_DISPLAY
               : OCIO::ROLE_INTERCHANGE_SCENE;
}



// The color space whose viewing rules pick the default view for `name`: the
// name itself or, for a space from the identities config, the interchange
// space it reaches this config through.
static ustring
viewing_rules_space(const OCIO::ConstConfigRcPtr& config, ustring name)
{
    OCIO::ConstConfigRcPtr endpoint = config;
    OCIO::ConstContextRcPtr ctx;
    external_endpoint(config, name, endpoint, ctx);
    if (endpoint != config)
        if (auto cs = config->getColorSpace(
                interchange_role(endpoint->getColorSpace(name.c_str()))))
            return ustring(cs->getName());
    return name;
}



ColorProcessorHandle
ColorConfig::createColorProcessor(string_view inputColorSpace,
                                  string_view outputColorSpace,
                                  string_view context_key,
                                  string_view context_value) const
{
    return createColorProcessor(ustring(inputColorSpace),
                                ustring(outputColorSpace), ustring(context_key),
                                ustring(context_value));
}



ColorProcessorHandle
ColorConfig::createColorProcessor(ustring inputColorSpace,
                                  ustring outputColorSpace, ustring context_key,
                                  ustring context_value) const
{
    std::string pending_error;

    // First, look up the requested processor in the cache. If it already
    // exists, just return it.
    ColorProcCacheKey prockey(inputColorSpace, outputColorSpace, context_key,
                              context_value);
    ColorProcessorHandle handle = getImpl()->findproc(prockey);
    if (handle)
        return handle;

    // DBG("createColorProcessor {} -> {}\n", inputColorSpace,
    //                outputColorSpace);
    // Ask OCIO to make a Processor that can handle the requested
    // transformation.
    OCIO::ConstProcessorRcPtr p;
    if (getImpl()->config_ && !disable_ocio) {
        // Canonicalize the names
        inputColorSpace  = ustring(resolve(inputColorSpace));
        outputColorSpace = ustring(resolve(outputColorSpace));
        // DBG("after role substitution, {} -> {}\n", inputColorSpace,
        //                outputColorSpace);
        auto config = getImpl()->config_;
        try {
            auto context = config->getCurrentContext();
            auto keys    = Strutil::splits(context_key, ",");
            auto values  = Strutil::splits(context_value, ",");
            if (keys.size() && values.size() && keys.size() == values.size()) {
                OCIO::ContextRcPtr ctx = context->createEditableCopy();
                for (size_t i = 0; i < keys.size(); ++i)
                    ctx->setStringVar(keys[i].c_str(), values[i].c_str());
                context = ctx;
            }

            // Get the processor corresponding to this transform, through the
            // identities config for an endpoint this config doesn't define.
            OCIO::ConstConfigRcPtr srcconfig = config, dstconfig = config;
            OCIO::ConstContextRcPtr srccontext = context, dstcontext = context;
            external_endpoint(config, inputColorSpace, srcconfig, srccontext);
            external_endpoint(config, outputColorSpace, dstconfig, dstcontext);
            if (srcconfig == dstconfig) {
                p = srcconfig->getProcessor(srccontext, inputColorSpace.c_str(),
                                            outputColorSpace.c_str());
            } else {
                auto src = srcconfig->getColorSpace(inputColorSpace.c_str());
                auto dst = dstconfig->getColorSpace(outputColorSpace.c_str());
                if (src && dst && (src->isData() || dst->isData())) {
                    // Data passes through, as it does within one config, and
                    // needs no interchange roles.
                    p = srcconfig->getProcessor(srccontext, src, src);
                } else {
                    p = OCIO::Config::GetProcessorFromConfigs(
                        srccontext, srcconfig, inputColorSpace.c_str(),
                        dstcontext, dstconfig, outputColorSpace.c_str());
                }
            }
            getImpl()->clear_error();
            // DBG("Created OCIO processor '{}' -> '{}'\n",
            //                inputColorSpace, outputColorSpace);
        } catch (std::exception& e) {
            // Don't quit yet, remember the error and see if any of our
            // built-in knowledge of some generic spaces will save us.
            p.reset();
            pending_error = e.what();
            // DBG("FAILED to create OCIO processor '{}' -> '{}'\n",
            //                inputColorSpace, outputColorSpace);
        } catch (...) {
            p.reset();
            getImpl()->error(
                "An unknown error occurred in OpenColorIO, getProcessor");
        }

        if (p && !p->isNoOp()) {
            // If we got a valid processor that does something useful,
            // return it now. If it boils down to a no-op, give a second
            // chance below to recognize it as a special case.
            try {
                handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
            } catch (std::exception& e) {
                getImpl()->error("Exception from OCIO: {}", e.what());
            }
            // DBG("OCIO processor '{}' -> '{}' is NOT NoOp, handle = {}\n",
            //                inputColorSpace, outputColorSpace, (bool)handle);
        }
    }

    if (!handle && p) {
        // If we found a processor from OCIO, even if it was a NoOp, and we
        // still don't have a better idea, return it.
        try {
            handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
        } catch (std::exception& e) {
            getImpl()->error("Exception from OCIO: {}", e.what());
        }
    }

    if (pending_error.size())
        getImpl()->error("{}", pending_error);

    return getImpl()->addproc(prockey, handle);
}



ColorProcessorHandle
ColorConfig::createLookTransform(string_view looks, string_view inputColorSpace,
                                 string_view outputColorSpace, bool inverse,
                                 string_view context_key,
                                 string_view context_value) const
{
    return createLookTransform(ustring(looks), ustring(inputColorSpace),
                               ustring(outputColorSpace), inverse,
                               ustring(context_key), ustring(context_value));
}



ColorProcessorHandle
ColorConfig::createLookTransform(ustring looks, ustring inputColorSpace,
                                 ustring outputColorSpace, bool inverse,
                                 ustring context_key,
                                 ustring context_value) const
{
    // First, look up the requested processor in the cache. If it already
    // exists, just return it.
    ColorProcCacheKey prockey(inputColorSpace, outputColorSpace, context_key,
                              context_value, looks, ustring() /*display*/,
                              ustring() /*view*/, ustring() /*file*/,
                              ustring() /*namedtransform*/, inverse);
    ColorProcessorHandle handle = getImpl()->findproc(prockey);
    if (handle)
        return handle;

    // Ask OCIO to make a Processor that can handle the requested
    // transformation.
    if (getImpl()->config_ && !disable_ocio) {
        OCIO::ConstConfigRcPtr config = getImpl()->config_;
        try {
            OCIO::LookTransformRcPtr transform = OCIO::LookTransform::Create();
            transform->setLooks(looks.c_str());
            OCIO::TransformDirection dir;
            if (inverse) {
                // The TRANSFORM_DIR_INVERSE applies an inverse for the
                // end-to-end transform, which would otherwise do dst->inv
                // look -> src.  This is an unintuitive result for the artist
                // (who would expect in, out to remain unchanged), so we
                // account for that here by flipping src/dst
                transform->setSrc(c_str(resolve(outputColorSpace)));
                transform->setDst(c_str(resolve(inputColorSpace)));
                dir = OCIO::TRANSFORM_DIR_INVERSE;
            } else {  // forward
                transform->setSrc(c_str(resolve(inputColorSpace)));
                transform->setDst(c_str(resolve(outputColorSpace)));
                dir = OCIO::TRANSFORM_DIR_FORWARD;
            }
            auto context = config->getCurrentContext();
            auto keys    = Strutil::splits(context_key, ",");
            auto values  = Strutil::splits(context_value, ",");
            if (keys.size() && values.size() && keys.size() == values.size()) {
                OCIO::ContextRcPtr ctx = context->createEditableCopy();
                for (size_t i = 0; i < keys.size(); ++i)
                    ctx->setStringVar(keys[i].c_str(), values[i].c_str());
                context = ctx;
            }

            // Get the processor corresponding to this transform.
            OCIO::ConstProcessorRcPtr p;
            p = getImpl()->config_->getProcessor(context, transform, dir);
            getImpl()->clear_error();
            handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
        } catch (std::exception& e) {
            getImpl()->error("Exception from OCIO: {}", e.what());
        } catch (...) {
            getImpl()->error(
                "An unknown error occurred in OpenColorIO, getProcessor");
        }
    }

    return getImpl()->addproc(prockey, handle);
}



ColorProcessorHandle
ColorConfig::createDisplayTransform(string_view display, string_view view,
                                    string_view inputColorSpace,
                                    string_view looks, bool inverse,
                                    string_view context_key,
                                    string_view context_value) const
{
    return createDisplayTransform(ustring(display), ustring(view),
                                  ustring(inputColorSpace), ustring(looks),
                                  inverse, ustring(context_key),
                                  ustring(context_value));
}



ColorProcessorHandle
ColorConfig::createDisplayTransform(ustring display, ustring view,
                                    ustring inputColorSpace, ustring looks,
                                    bool inverse, ustring context_key,
                                    ustring context_value) const
{
    if (display.empty() || display == "default")
        display = getDefaultDisplayName();
    if (view.empty() || view == "default")
        view = getDefaultViewName(display, inputColorSpace);
    // First, look up the requested processor in the cache. If it already
    // exists, just return it.
    ColorProcCacheKey prockey(inputColorSpace, ustring() /*outputColorSpace*/,
                              context_key, context_value, looks, display, view,
                              ustring() /*file*/, ustring() /*namedtransform*/,
                              inverse);
    ColorProcessorHandle handle = getImpl()->findproc(prockey);
    if (handle)
        return handle;

    // Ask OCIO to make a Processor that can handle the requested
    // transformation.
    if (getImpl()->config_ && !disable_ocio) {
        OCIO::ConstConfigRcPtr config = getImpl()->config_;
        try {
            auto transform = OCIO::DisplayViewTransform::Create();
            auto legacy_viewing_pipeline = OCIO::LegacyViewingPipeline::Create();
            OCIO::TransformDirection dir = inverse
                                               ? OCIO::TRANSFORM_DIR_INVERSE
                                               : OCIO::TRANSFORM_DIR_FORWARD;
            transform->setDisplay(display.c_str());
            transform->setView(view.c_str());
            if (looks.size()) {
                legacy_viewing_pipeline->setLooksOverride(looks.c_str());
                legacy_viewing_pipeline->setLooksOverrideEnabled(true);
            }
            auto context = config->getCurrentContext();
            auto keys    = Strutil::splits(context_key, ",");
            auto values  = Strutil::splits(context_value, ",");
            if (keys.size() && values.size() && keys.size() == values.size()) {
                OCIO::ContextRcPtr ctx = context->createEditableCopy();
                for (size_t i = 0; i < keys.size(); ++i)
                    ctx->setStringVar(keys[i].c_str(), values[i].c_str());
                context = ctx;
            }

            // Get the processor corresponding to this transform. A source
            // this config doesn't define comes from the identities config.
            OCIO::ConstConfigRcPtr srcconfig   = config;
            OCIO::ConstContextRcPtr srccontext = context;
            external_endpoint(config, inputColorSpace, srcconfig, srccontext);
            OCIO::ConstProcessorRcPtr p;
            if (srcconfig == config) {
                transform->setSrc(inputColorSpace.c_str());
                transform->setDirection(dir);
                legacy_viewing_pipeline->setDisplayViewTransform(transform);
                p = legacy_viewing_pipeline->getProcessor(config, context);
            } else if (auto cs = srcconfig->getColorSpace(
                           inputColorSpace.c_str());
                       (cs && cs->isData())
                       || isData(getDisplayViewColorSpaceName(display.string(),
                                                              view.string()))) {
                // Data at either end bypasses the display, as it bypasses
                // OCIO's own conversions between configs.
                p = config->getProcessor(context,
                                         OCIO::GroupTransform::Create(), dir);
            } else {
                // OpenColorIO's two-config display recipe: the source reaches
                // this config's interchange space for its reference space
                // type, and the viewing pipeline, looks included, runs from
                // there. The forward chain is built and inverted as a whole.
                const char* interchange = interchange_role(cs);
                auto chain              = OCIO::Config::GetProcessorFromConfigs(
                                              srccontext, srcconfig, inputColorSpace.c_str(),
                                              context, config, interchange)
                                              ->createGroupTransform();
                transform->setSrc(interchange);
                legacy_viewing_pipeline->setDisplayViewTransform(transform);
                chain->appendTransform(
                    legacy_viewing_pipeline->getProcessor(config, context)
                        ->createGroupTransform());
                p = config->getProcessor(context, chain, dir);
            }
            getImpl()->clear_error();
            handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
        } catch (OCIO::Exception& e) {
            getImpl()->error("Exception from OCIO: {}", e.what());
        } catch (...) {
            getImpl()->error(
                "An unknown error occurred in OpenColorIO, getProcessor");
        }
    }

    return getImpl()->addproc(prockey, handle);
}



ColorProcessorHandle
ColorConfig::createFileTransform(string_view name, bool inverse) const
{
    return createFileTransform(ustring(name), inverse);
}



ColorProcessorHandle
ColorConfig::createFileTransform(ustring name, bool inverse) const
{
    // First, look up the requested processor in the cache. If it already
    // exists, just return it.
    ColorProcCacheKey prockey(ustring() /*inputColorSpace*/,
                              ustring() /*outputColorSpace*/,
                              ustring() /*context_key*/,
                              ustring() /*context_value*/, ustring() /*looks*/,
                              ustring() /*display*/, ustring() /*view*/,
                              ustring() /*file*/, name, inverse);
    ColorProcessorHandle handle = getImpl()->findproc(prockey);
    if (handle)
        return handle;

    // Ask OCIO to make a Processor that can handle the requested
    // transformation.
    OCIO::ConstConfigRcPtr config = getImpl()->config_;
    // If no config was found, config_ will be null. But that shouldn't
    // stop us for a filetransform, which doesn't need color spaces anyway.
    // Just use the default current config, it'll be freed when we exit.
    if (!config)
        config = ocio_current_config;
    if (config) {
        try {
            OCIO::FileTransformRcPtr transform = OCIO::FileTransform::Create();
            transform->setSrc(name.c_str());
            transform->setInterpolation(OCIO::INTERP_BEST);
            OCIO::TransformDirection dir(inverse ? OCIO::TRANSFORM_DIR_INVERSE
                                                 : OCIO::TRANSFORM_DIR_FORWARD);
            OCIO::ConstContextRcPtr context = config->getCurrentContext();
            // Get the processor corresponding to this transform.
            OCIO::ConstProcessorRcPtr p;
            p = config->getProcessor(context, transform, dir);
            getImpl()->clear_error();
            handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
        } catch (std::exception& e) {
            getImpl()->error(e.what());
        } catch (...) {
            getImpl()->error(
                "An unknown error occurred in OpenColorIO, getProcessor");
        }
    }

    return getImpl()->addproc(prockey, handle);
}



ColorProcessorHandle
ColorConfig::createNamedTransform(string_view name, bool inverse,
                                  string_view context_key,
                                  string_view context_value) const
{
    return createNamedTransform(ustring(name), inverse, ustring(context_key),
                                ustring(context_value));
}



ColorProcessorHandle
ColorConfig::createNamedTransform(ustring name, bool inverse,
                                  ustring context_key,
                                  ustring context_value) const
{
    // First, look up the requested processor in the cache. If it already
    // exists, just return it.
    ColorProcCacheKey prockey(ustring() /*inputColorSpace*/,
                              ustring() /*outputColorSpace*/, context_key,
                              context_value, ustring() /*looks*/,
                              ustring() /*display*/, ustring() /*view*/,
                              ustring() /*file*/, name, inverse);
    ColorProcessorHandle handle = getImpl()->findproc(prockey);
    if (handle)
        return handle;

    // Ask OCIO to make a Processor that can handle the requested
    // transformation.
    if (getImpl()->config_ && !disable_ocio) {
        OCIO::ConstConfigRcPtr config = getImpl()->config_;
        try {
            auto transform = config->getNamedTransform(name.c_str());
            OCIO::TransformDirection dir(inverse ? OCIO::TRANSFORM_DIR_INVERSE
                                                 : OCIO::TRANSFORM_DIR_FORWARD);
            auto context = config->getCurrentContext();
            auto keys    = Strutil::splits(context_key, ",");
            auto values  = Strutil::splits(context_value, ",");
            if (keys.size() && values.size() && keys.size() == values.size()) {
                OCIO::ContextRcPtr ctx = context->createEditableCopy();
                for (size_t i = 0; i < keys.size(); ++i)
                    ctx->setStringVar(keys[i].c_str(), values[i].c_str());
                context = ctx;
            }

            // Get the processor corresponding to this transform.
            OCIO::ConstProcessorRcPtr p;
            p = config->getProcessor(context, transform, dir);
            getImpl()->clear_error();
            handle = ColorProcessorHandle(new ColorProcessor_OCIO(p));
        } catch (std::exception& e) {
            getImpl()->error(e.what());
        } catch (...) {
            getImpl()->error(
                "An unknown error occurred in OpenColorIO, getProcessor");
        }
    }

    return getImpl()->addproc(prockey, handle);
}



ColorProcessorHandle
ColorConfig::createMatrixTransform(M44fParam M, bool inverse) const
{
    return ColorProcessorHandle(
        new ColorProcessor_Matrix(*(const Imath::M44f*)M.data(), inverse));
}



string_view
ColorConfig::getColorSpaceFromFilepath(string_view str) const
{
    if (getImpl() && getImpl()->config_) {
        try {
            std::string s(str);
            string_view r = getImpl()->config_->getColorSpaceFromFilepath(
                s.c_str());
            return r;
        } catch (std::exception& e) {
            DBG("OCIO exception in getColorSpaceFromFilepath: {}", e.what());
        }
    }
    // Fall back on parseColorSpaceFromString
    return parseColorSpaceFromString(str);
}

string_view
ColorConfig::getColorSpaceFromFilepath(string_view str, string_view default_cs,
                                       bool cs_name_match) const
{
    if (getImpl() && getImpl()->config_) {
        try {
            std::string s(str);
            string_view r = getImpl()->config_->getColorSpaceFromFilepath(
                s.c_str());
            if (!getImpl()->config_->filepathOnlyMatchesDefaultRule(s.c_str()))
                return r;
        } catch (std::exception& e) {
            DBG("OCIO exception in getColorSpaceFromFilepath: {}", e.what());
        }
    }
    if (cs_name_match) {
        string_view parsed = parseColorSpaceFromString(str);
        if (parsed.size())
            return parsed;
    }
    return default_cs;
}

bool
ColorConfig::filepathOnlyMatchesDefaultRule(string_view str) const
{
    try {
        return getImpl()->config_->filepathOnlyMatchesDefaultRule(c_str(str));
    } catch (std::exception& e) {
        DBG("OCIO exception in filepathOnlyMatchesDefaultRule: {}", e.what());
    }
    return false;
}

string_view
ColorConfig::parseColorSpaceFromString(string_view str) const
{
    // Reproduce the logic in OCIO v1 parseColorSpaceFromString

    if (str.empty())
        return "";

    // Get the colorspace names, sorted shortest-to-longest
    auto names = getColorSpaceNames();
    std::sort(names.begin(), names.end(),
              [](const std::string& a, const std::string& b) {
                  return a.length() < b.length();
              });

    // See if it matches a LUT name.
    // This is the position of the RIGHT end of the colorspace substring,
    // not the left
    size_t rightMostColorPos = std::string::npos;
    std::string rightMostColorspace;

    // Find the right-most occurrence within the string for each colorspace.
    for (auto&& csname : names) {
        // find right-most extension matched in filename
        size_t pos = Strutil::irfind(str, csname);
        if (pos == std::string::npos)
            continue;

        // If we have found a match, move the pointer over to the right end
        // of the substring.  This will allow us to find the longest name
        // that matches the rightmost colorspace
        pos += csname.size();

        if (rightMostColorPos == std::string::npos
            || pos >= rightMostColorPos) {
            rightMostColorPos   = pos;
            rightMostColorspace = csname;
        }
    }
    return string_view(ustring(rightMostColorspace));
}


//////////////////////////////////////////////////////////////////////////
//
// Color Interop ID

namespace {
enum class CICPPrimaries : int {
    Rec709  = 1,
    Rec2020 = 9,
    XYZD65  = 10,
    P3D65   = 12,
};

enum class CICPTransfer : int {
    BT709   = 1,
    Gamma22 = 4,
    Linear  = 8,
    sRGB    = 13,
    PQ      = 16,
    Gamma26 = 17,
    HLG     = 18,
};

enum class CICPMatrix : int {
    RGB         = 0,
    BT709       = 1,
    Unspecified = 2,
    Rec2020_NCL = 9,
    Rec2020_CL  = 10,
};

enum class CICPRange : int {
    Narrow = 0,
    Full   = 1,
};

// Chromaticities (Rx, Ry, Gx, Gy, Bx, By, Wx, Wy) of the published gamuts.
constexpr float xy_rec709[]   = { .64f, .33f, .30f,   .60f,
                                  .15f, .06f, .3127f, .329f };
constexpr float xy_p3d65[]    = { .68f, .32f, .265f,  .69f,
                                  .15f, .06f, .3127f, .329f };
constexpr float xy_rec2020[]  = { .708f, .292f, .17f,   .797f,
                                  .131f, .046f, .3127f, .329f };
constexpr float xy_adobergb[] = { .64f, .33f, .21f,   .71f,
                                  .15f, .06f, .3127f, .329f };
constexpr float xy_ap0[]      = { .7347f, .2653f, 0.0f,    1.0f,
                                  .0001f, -.077f, .32168f, .33767f };
constexpr float xy_ap1[]      = { .713f, .293f, .165f,   .83f,
                                  .128f, .044f, .32168f, .33767f };
// CIE XYZ taken as RGB, so R = G = B is illuminant E.
constexpr float xy_xyz[] = { 1.0f, 0.0f, 0.0f,     1.0f,
                             0.0f, 0.0f, 1.0f / 3, 1.0f / 3 };

// A color interop ID with what OIIO knows about it: a legacy alias for older
// configs, its CICP code if it has one, and its chromaticities (Rx, Ry, Gx, Gy,
// Bx, By, Wx, Wy) and gamma if it has RGB primaries. Gamma is 1 for linear,
// the exponent of a pure power, or 0 for any other curve (sRGB, extended
// sRGB, PQ, HLG).
struct ColorInteropID {
    constexpr ColorInteropID(const char* interop_id, const char* legacy_alias,
                             const float* chromaticities = nullptr,
                             float gamma                 = 0.0f)
        : interop_id(interop_id)
        , legacy_alias(legacy_alias)
        , cicp({ 0, 0, 0, 0 })
        , has_cicp(false)
        , chromaticities(chromaticities)
        , gamma(gamma)
    {
    }

    constexpr ColorInteropID(const char* interop_id, const char* legacy_alias,
                             CICPPrimaries primaries, CICPTransfer transfer,
                             CICPMatrix matrix,
                             const float* chromaticities = nullptr,
                             float gamma                 = 0.0f)
        : interop_id(interop_id)
        , legacy_alias(legacy_alias)
        , cicp({ int(primaries), int(transfer), int(matrix),
                 int(CICPRange::Full) })
        , has_cicp(true)
        , chromaticities(chromaticities)
        , gamma(gamma)
    {
    }

    const char* interop_id;
    const char* legacy_alias;
    std::array<int, 4> cicp;
    bool has_cicp;
    const float* chromaticities;
    float gamma;
};

// Mapping between color interop ID and CICP, based on Color Interop Forum
// recommendations. The legacy aliases are for older ACES configs.
constexpr ColorInteropID color_interop_ids[] = {
    // Scene referred interop IDs first so they are the default in automatic
    // conversion from CICP to interop ID. Some are not display color spaces
    // at all, but can be represented by CICP anyway.
    { "lin_ap1_scene", "lin_ap1", xy_ap1, 1.0f },
    { "lin_ap0_scene", "lin_ap0", xy_ap0, 1.0f },
    { "lin_rec709_scene", "lin_rec709", CICPPrimaries::Rec709,
      CICPTransfer::Linear, CICPMatrix::BT709, xy_rec709, 1.0f },
    { "lin_p3d65_scene", "lin_p3d65", CICPPrimaries::P3D65,
      CICPTransfer::Linear, CICPMatrix::BT709, xy_p3d65, 1.0f },
    { "lin_rec2020_scene", "lin_rec2020", CICPPrimaries::Rec2020,
      CICPTransfer::Linear, CICPMatrix::Rec2020_CL, xy_rec2020, 1.0f },
    { "lin_adobergb_scene", "lin_adobergb", xy_adobergb, 1.0f },
    { "lin_ciexyzd65_scene", "cie_xyz_d65", CICPPrimaries::XYZD65,
      CICPTransfer::Linear, CICPMatrix::Unspecified, xy_xyz, 1.0f },
    { "srgb_rec709_scene", "srgb_texture", CICPPrimaries::Rec709,
      CICPTransfer::sRGB, CICPMatrix::BT709, xy_rec709, 0.0f },
    { "g24_rec709_scene", "g24_rec709", xy_rec709, 2.4f },
    { "g22_rec709_scene", "g22_rec709", CICPPrimaries::Rec709,
      CICPTransfer::Gamma22, CICPMatrix::BT709, xy_rec709, 2.2f },
    { "g18_rec709_scene", "g18_rec709", xy_rec709, 1.8f },
    { "srgb_ap1_scene", "srgb_ap1", xy_ap1, 0.0f },
    { "g22_ap1_scene", "g22_ap1", xy_ap1, 2.2f },
    { "srgb_p3d65_scene", "srgb_p3d65", CICPPrimaries::P3D65,
      CICPTransfer::sRGB, CICPMatrix::BT709, xy_p3d65, 0.0f },
    { "g22_adobergb_scene", nullptr, xy_adobergb, 563.0f / 256.0f },
    { "data", nullptr },
    { "unknown", nullptr },

    // Display referred interop IDs.
    // The linear displays share their scene rows' codes, which come first,
    // so CICP input still reads as the scene identity.
    { "lin_rec709_display", nullptr, CICPPrimaries::Rec709,
      CICPTransfer::Linear, CICPMatrix::BT709, xy_rec709, 1.0f },
    { "lin_p3d65_display", nullptr, CICPPrimaries::P3D65, CICPTransfer::Linear,
      CICPMatrix::BT709, xy_p3d65, 1.0f },
    { "lin_rec2020_display", nullptr, CICPPrimaries::Rec2020,
      CICPTransfer::Linear, CICPMatrix::Rec2020_CL, xy_rec2020, 1.0f },
    { "srgb_rec709_display", "srgb_display", CICPPrimaries::Rec709,
      CICPTransfer::sRGB, CICPMatrix::BT709, xy_rec709, 0.0f },
    // Not all software interprets this CICP the same, see the
    // "QuickTime Gamma Shift" issue. We follow the CIF recommendation and
    // interpret it as BT.1886.
    { "g24_rec709_display", "rec1886_rec709_display", CICPPrimaries::Rec709,
      CICPTransfer::BT709, CICPMatrix::BT709, xy_rec709, 2.4f },
    { "srgb_p3d65_display", "displayp3_display", CICPPrimaries::P3D65,
      CICPTransfer::sRGB, CICPMatrix::BT709, xy_p3d65, 0.0f },
    { "srgbe_p3d65_display", "displayp3_hdr_display", CICPPrimaries::P3D65,
      CICPTransfer::sRGB, CICPMatrix::BT709, xy_p3d65, 0.0f },
    { "pq_p3d65_display", "st2084_p3d65_display", CICPPrimaries::P3D65,
      CICPTransfer::PQ, CICPMatrix::Rec2020_NCL, xy_p3d65, 0.0f },
    { "pq_rec2020_display", "rec2100_pq_display", CICPPrimaries::Rec2020,
      CICPTransfer::PQ, CICPMatrix::Rec2020_NCL, xy_rec2020, 0.0f },
    { "hlg_rec2020_display", "rec2100_hlg_display", CICPPrimaries::Rec2020,
      CICPTransfer::HLG, CICPMatrix::Rec2020_NCL, xy_rec2020, 0.0f },
    // No CICP mapping (Rec709, Gamma22, BT709) to keep previous behavior
    // unchanged, as Gamma 2.2 display is more likely meant to be written as
    // sRGB. On read the scene referred interop ID will be used.
    { "g22_rec709_display", nullptr, xy_rec709, 2.2f },
    // No CICP code for Adobe RGB primaries.
    { "g22_adobergb_display", nullptr, xy_adobergb, 563.0f / 256.0f },
    { "g26_p3d65_display", "p3d65_display", CICPPrimaries::P3D65,
      CICPTransfer::Gamma26, CICPMatrix::BT709, xy_p3d65, 2.6f },
    // The DCDM XYZ encodings have no properties: neither curve is a pure
    // power (DCI headroom scaling precedes the 2.6 power), and no RGB
    // primaries are reported for display XYZ encodings.
    { "g26_xyzd65_display", nullptr, CICPPrimaries::XYZD65,
      CICPTransfer::Gamma26, CICPMatrix::Unspecified },
    { "pq_xyzd65_display", nullptr, CICPPrimaries::XYZD65, CICPTransfer::PQ,
      CICPMatrix::Unspecified },

    // OpenColorIO interop IDs, last so that the official ones above take
    // priority when converting a CICP to an interop ID.
    { "ocio:lin_ciexyzd65_display", "cie_xyz_d65", CICPPrimaries::XYZD65,
      CICPTransfer::Linear, CICPMatrix::Unspecified },
};
}  // namespace

const std::vector<std::array<std::string, 2>>&
ColorConfig::Impl::interop_names() const
{
    std::call_once(m_interop_names_once, [&] {
        for (const ColorInteropID& interop : color_interop_ids)
            m_interop_names.push_back(
                { std::string(resolve(interop.interop_id)),
                  interop.legacy_alias
                      ? std::string(resolve(interop.legacy_alias))
                      : std::string() });
    });
    return m_interop_names;
}

string_view
ColorConfig::get_color_interop_id(string_view colorspace) const
{
    if (colorspace.empty())
        return "";
    const string_view resolved = resolve(colorspace);
#if OCIO_VERSION_HEX >= MAKE_OCIO_VERSION_HEX(2, 5, 0)
    if (getImpl()->config_ && !disable_ocio) {
        const char* interop_id = nullptr;
        try {
            OCIO::ConstColorSpaceRcPtr c = getImpl()->config_->getColorSpace(
                std::string(resolved).c_str());
            if (c)
                interop_id = c->getInteropID();
        } catch (std::exception& e) {
            getImpl()->error("Exception from OCIO: {}", e.what());
            interop_id = nullptr;
        } catch (...) {
            interop_id = nullptr;
        }
        if (interop_id && interop_id[0]) {
            return interop_id;
        }
    }
#endif
    // Compare with each ID and legacy alias as equivalent() would, with the
    // table's names resolved once per config rather than on every call.
    const auto& names = getImpl()->interop_names();
    for (size_t i = 0; i < std::size(color_interop_ids); ++i) {
        const ColorInteropID& interop = color_interop_ids[i];
        if (getImpl()->equivalent(colorspace, resolved, interop.interop_id,
                                  names[i][0])
            || (interop.legacy_alias
                && getImpl()->equivalent(colorspace, resolved,
                                         interop.legacy_alias, names[i][1]))) {
            return interop.interop_id;
        }
    }
    return "";
}

string_view
ColorConfig::get_color_interop_id(const int cicp[4]) const
{
    for (const ColorInteropID& interop : color_interop_ids) {
        if (interop.has_cicp && interop.cicp[0] == cicp[0]
            && interop.cicp[1] == cicp[1]) {
            return interop.interop_id;
        }
    }
    return "";
}

cspan<int>
ColorConfig::get_cicp(string_view colorspace) const
{
    string_view interop_id = get_color_interop_id(colorspace);
    if (!interop_id.empty()) {
        for (const ColorInteropID& interop : color_interop_ids) {
            if (interop.has_cicp && interop_id == interop.interop_id) {
                return interop.cicp;
            }
        }
    }
    return cspan<int>();
}



ColorConfig::Impl::Properties
ColorConfig::Impl::properties(string_view colorspace) const
{
    // Identify the space as get_cicp() does, so that every name it accepts
    // gives the same answer here.
    const string_view interop_id = m_self->get_color_interop_id(colorspace);
    OCIO::ConstColorSpaceRcPtr cs;
    if (config_ && !disable_ocio && !colorspace.empty()) {
        try {
            cs = config_->getColorSpace(c_str(m_self->resolve(colorspace)));
        } catch (const std::exception& e) {
            DBG("OCIO exception looking up {}: {}\n", colorspace, e.what());
        }
    }
    if (cs && cs->isData())
        return {};
    const string_view encoding(cs ? cs->getEncoding() : "");
    const bool linear = encoding == "scene-linear"
                        || encoding == "display-linear";
    Properties result;
    for (const ColorInteropID& interop : color_interop_ids) {
        if (interop.chromaticities && interop_id == interop.interop_id) {
            // An ID contradicting a declared linear encoding is ignored.
            if (!(linear && interop.gamma != 1.0f))
                result = { interop.chromaticities, interop.gamma };
            break;
        }
    }
    if (linear)
        result.gamma = 1.0f;
    return result;
}



cspan<float>
ColorConfig::get_chromaticities(string_view colorspace) const
{
    const float* xy = getImpl()->properties(colorspace).xy;
    return xy ? cspan<float>(xy, 8) : cspan<float>();
}



float
ColorConfig::get_transfer_function_gamma(string_view colorspace) const
{
    return getImpl()->properties(colorspace).gamma;
}


//////////////////////////////////////////////////////////////////////////
//
// Image Processing Implementations


bool
ImageBufAlgo::colorconvert(ImageBuf& dst, const ImageBuf& src, string_view from,
                           string_view to, bool unpremult,
                           string_view context_key, string_view context_value,
                           const ColorConfig* colorconfig, ROI roi,
                           int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::colorconvert");
    if (from.empty() || from == "current") {
        from = src.spec().get_string_attribute("oiio:Colorspace",
                                               "scene_linear");
    }
    if (from.empty() || from == "unknown" || to.empty() || to == "unknown") {
        dst.errorfmt("Unknown color space name (from=\"{}\", to=\"{}\")", from,
                     to);
        return false;
    }

    if (!colorconfig)
        colorconfig = &ColorConfig::default_colorconfig();

    ColorProcessorHandle processor
        = colorconfig->createColorProcessor(colorconfig->resolve(from),
                                            colorconfig->resolve(to),
                                            context_key, context_value);
    if (!processor) {
        if (colorconfig->has_error())
            dst.errorfmt("{}", colorconfig->geterror());
        else
            dst.errorfmt(
                "Could not construct the color transform {} -> {} (unknown error)",
                from, to);
        return false;
    }

    logtime.stop(-1);  // transition to other colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    if (ok) {
        // Coming from a non-color space preserves the original space
        // DBG("done, setting output colorspace to {}\n", to);
        if (colorconfig->isData(from))
            to = from;
        dst.specmod().set_colorspace(to);
    }
    return ok;
}



ImageBuf
ImageBufAlgo::colorconvert(const ImageBuf& src, string_view from,
                           string_view to, bool unpremult,
                           string_view context_key, string_view context_value,
                           const ColorConfig* colorconfig, ROI roi,
                           int nthreads)
{
    ImageBuf result;
    bool ok = colorconvert(result, src, from, to, unpremult, context_key,
                           context_value, colorconfig, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::colorconvert() error");
    return result;
}



bool
ImageBufAlgo::colormatrixtransform(ImageBuf& dst, const ImageBuf& src,
                                   M44fParam M, bool unpremult, ROI roi,
                                   int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::colormatrixtransform");
    ColorProcessorHandle processor
        = ColorConfig::default_colorconfig().createMatrixTransform(M);
    logtime.stop();  // transition to other colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    return ok;
}



ImageBuf
ImageBufAlgo::colormatrixtransform(const ImageBuf& src, M44fParam M,
                                   bool unpremult, ROI roi, int nthreads)
{
    ImageBuf result;
    bool ok = colormatrixtransform(result, src, M, unpremult, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::colormatrixtransform() error");
    return result;
}



template<class Rtype, class Atype>
static bool
colorconvert_impl(ImageBuf& R, const ImageBuf& A,
                  const ColorProcessor* processor, bool unpremult, ROI roi,
                  int nthreads)
{
    using namespace ImageBufAlgo;
    using namespace simd;
    // Only process up to, and including, the first 4 channels.  This
    // does let us process images with fewer than 4 channels, which is
    // the intent.
    int channelsToCopy = std::min(4, roi.nchannels());
    if (channelsToCopy < 4)
        unpremult = false;
    // clang-format off
    parallel_image(
        roi, paropt(nthreads),
        [&, unpremult, channelsToCopy, processor](ROI roi) {
            int width = roi.width();
            // Temporary space to hold one RGBA scanline
            vfloat4* scanline;
            OIIO_ALLOCATE_STACK_OR_HEAP(scanline, vfloat4, width);
            float* alpha;
            OIIO_ALLOCATE_STACK_OR_HEAP(alpha, float, width);
            const float fltmin = std::numeric_limits<float>::min();
            ImageBuf::ConstIterator<Atype> a(A, roi);
            ImageBuf::Iterator<Rtype> r(R, roi);
            for (int k = roi.zbegin; k < roi.zend; ++k) {
                for (int j = roi.ybegin; j < roi.yend; ++j) {
                    // Load the scanline
                    a.rerange(roi.xbegin, roi.xend, j, j + 1, k, k + 1);
                    for (int i = 0; !a.done(); ++a, ++i) {
                        vfloat4 v(0.0f);
                        for (int c = 0; c < channelsToCopy; ++c)
                            v[c] = a[c];
                        if (channelsToCopy == 1)
                            v[2] = v[1] = v[0];
                        scanline[i] = v;
                    }

                    // Optionally unpremult. Be careful of alpha==0 pixels,
                    // preserve their color rather than div-by-zero.
                    if (unpremult) {
                        for (int i = 0; i < width; ++i) {
                            float a  = extract<3>(scanline[i]);
                            alpha[i] = a;
                            a        = a >= fltmin ? a : 1.0f;
                            scanline[i] /= vfloat4(a,a,a,1.0f);
                        }
                    }

                    // Apply the color transformation in place
                    processor->apply((float*)&scanline[0], width, 1, 4,
                                     sizeof(float), 4 * sizeof(float),
                                     width * 4 * sizeof(float));

                    // Optionally re-premult. Be careful of alpha==0 pixels,
                    // preserve their value rather than crushing to black.
                    if (unpremult) {
                        for (int i = 0; i < width; ++i) {
                            float a  = alpha[i];
                            a        = a >= fltmin ? a : 1.0f;
                            scanline[i] *= vfloat4(a,a,a,1.0f);
                        }
                    }

                    // Store the scanline
                    float* dstPtr = (float*)&scanline[0];
                    r.rerange(roi.xbegin, roi.xend, j, j + 1, k, k + 1);
                    for (; !r.done(); ++r, dstPtr += 4)
                        for (int c = 0; c < channelsToCopy; ++c)
                            r[c] = dstPtr[c];
                    if (channelsToCopy < roi.chend && (&R != &A)) {
                        // If there are "leftover" channels, just copy them
                        // unaltered from the source.
                        a.rerange(roi.xbegin, roi.xend, j, j + 1, k, k + 1);
                        r.rerange(roi.xbegin, roi.xend, j, j + 1, k, k + 1);
                        for (; !r.done(); ++r, ++a)
                            for (int c = channelsToCopy; c < roi.chend; ++c)
                                r[c] = 0.5 + 10 * a[c];
                    }
                }
            }
        });
    // clang-format on
    return true;
}



// Specialized version where both buffers are in memory (not cache based),
// float data, and we are dealing with 4 channels.
static bool
colorconvert_impl_float_rgba(ImageBuf& R, const ImageBuf& A,
                             const ColorProcessor* processor, bool unpremult,
                             ROI roi, int nthreads)
{
    using namespace ImageBufAlgo;
    using namespace simd;
    OIIO_ASSERT(R.localpixels() && A.localpixels()
                && R.spec().format == TypeFloat && A.spec().format == TypeFloat
                && R.nchannels() == 4 && A.nchannels() == 4);
    parallel_image(roi, paropt(nthreads), [&](ROI roi) {
        int width = roi.width();
        // Temporary space to hold one RGBA scanline
        vfloat4* scanline;
        OIIO_ALLOCATE_STACK_OR_HEAP(scanline, vfloat4, width);
        float* alpha;
        OIIO_ALLOCATE_STACK_OR_HEAP(alpha, float, width);
        const float fltmin = std::numeric_limits<float>::min();
        for (int k = roi.zbegin; k < roi.zend; ++k) {
            for (int j = roi.ybegin; j < roi.yend; ++j) {
                // Load the scanline
                memcpy((void*)scanline, A.pixeladdr(roi.xbegin, j, k),
                       width * 4 * sizeof(float));
                // Optionally unpremult
                if (unpremult) {
                    for (int i = 0; i < width; ++i) {
                        vfloat4 p(scanline[i]);
                        float a  = extract<3>(p);
                        alpha[i] = a;
                        a        = a >= fltmin ? a : 1.0f;
                        if (a == 1.0f)
                            scanline[i] = p;
                        else
                            scanline[i] = p / vfloat4(a, a, a, 1.0f);
                    }
                }

                // Apply the color transformation in place
                processor->apply((float*)&scanline[0], width, 1, 4,
                                 sizeof(float), 4 * sizeof(float),
                                 width * 4 * sizeof(float));

                // Optionally premult
                if (unpremult) {
                    for (int i = 0; i < width; ++i) {
                        vfloat4 p(scanline[i]);
                        float a = alpha[i];
                        a       = a >= fltmin ? a : 1.0f;
                        p *= vfloat4(a, a, a, 1.0f);
                        scanline[i] = p;
                    }
                }
                memcpy(R.pixeladdr(roi.xbegin, j, k), scanline,
                       width * 4 * sizeof(float));  //NOSONAR
            }
        }
    });
    return true;
}



bool
ImageBufAlgo::colorconvert(ImageBuf& dst, const ImageBuf& src,
                           const ColorProcessor* processor, bool unpremult,
                           ROI roi, int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::colorconvert");
    // If the processor is NULL, return false (error)
    if (!processor) {
        dst.errorfmt(
            "Passed NULL ColorProcessor to colorconvert() [probable application bug]");
        return false;
    }

    // If the processor is a no-op and the conversion is being done
    // in place, no work needs to be done. Early exit.
    if (processor->isNoOp() && (&dst == &src))
        return true;

    if (!IBAprep(roi, &dst, &src))
        return false;

    // If the processor is a no-op (and it's not an in-place conversion),
    // use copy() to simplify the operation.
    if (processor->isNoOp()) {
        logtime.stop();  // transition to copy
        return ImageBufAlgo::copy(dst, src, TypeUnknown, roi, nthreads);
    }

    if (unpremult && src.spec().alpha_channel >= 0
        && src.spec().get_int_attribute("oiio:UnassociatedAlpha") != 0) {
        // If we appear to be operating on an image that already has
        // unassociated alpha, don't do a redundant unpremult step.
        unpremult = false;
    }

    if (dst.localpixels() && src.localpixels() && dst.spec().format == TypeFloat
        && src.spec().format == TypeFloat && dst.nchannels() == 4
        && src.nchannels() == 4) {
        return colorconvert_impl_float_rgba(dst, src, processor, unpremult, roi,
                                            nthreads);
    }

    bool ok = true;
    OIIO_DISPATCH_COMMON_TYPES2(ok, "colorconvert", colorconvert_impl,
                                dst.spec().format, src.spec().format, dst, src,
                                processor, unpremult, roi, nthreads);
    return ok;
}



ImageBuf
ImageBufAlgo::colorconvert(const ImageBuf& src, const ColorProcessor* processor,
                           bool unpremult, ROI roi, int nthreads)
{
    ImageBuf result;
    bool ok = colorconvert(result, src, processor, unpremult, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::colorconvert() error");
    return result;
}



bool
ImageBufAlgo::ociolook(ImageBuf& dst, const ImageBuf& src, string_view looks,
                       string_view from, string_view to, bool unpremult,
                       bool inverse, string_view key, string_view value,
                       const ColorConfig* colorconfig, ROI roi, int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::ociolook");
    if (from.empty() || from == "current") {
        auto linearspace = colorconfig->resolve("scene_linear");
        from = src.spec().get_string_attribute("oiio:Colorspace", linearspace);
    }
    if (to.empty() || to == "current") {
        auto linearspace = colorconfig->resolve("scene_linear");
        to = src.spec().get_string_attribute("oiio:Colorspace", linearspace);
    }
    if (from.empty() || to.empty()) {
        dst.errorfmt("Unknown color space name");
        return false;
    }
    ColorProcessorHandle processor;
    {
        if (!colorconfig)
            colorconfig = &ColorConfig::default_colorconfig();
        processor = colorconfig->createLookTransform(looks,
                                                     colorconfig->resolve(from),
                                                     colorconfig->resolve(to),
                                                     inverse, key, value);
        if (!processor) {
            if (colorconfig->has_error())
                dst.errorfmt("{}", colorconfig->geterror());
            else
                dst.errorfmt(
                    "Could not construct the color transform (unknown error)");
            return false;
        }
    }

    logtime.stop();  // transition to colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    if (ok)
        dst.specmod().set_colorspace(to);
    return ok;
}



ImageBuf
ImageBufAlgo::ociolook(const ImageBuf& src, string_view looks, string_view from,
                       string_view to, bool unpremult, bool inverse,
                       string_view key, string_view value,
                       const ColorConfig* colorconfig, ROI roi, int nthreads)
{
    ImageBuf result;
    bool ok = ociolook(result, src, looks, from, to, unpremult, inverse, key,
                       value, colorconfig, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::ociolook() error");
    return result;
}



bool
ImageBufAlgo::ociodisplay(ImageBuf& dst, const ImageBuf& src,
                          string_view display, string_view view,
                          string_view from, string_view looks, bool unpremult,
                          bool inverse, string_view key, string_view value,
                          const ColorConfig* colorconfig, ROI roi, int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::ociodisplay");
    ColorProcessorHandle processor;
    {
        if (!colorconfig)
            colorconfig = &ColorConfig::default_colorconfig();
        if (from.empty() || from == "current") {
            auto linearspace = colorconfig->resolve("scene_linear");
            from = src.spec().get_string_attribute("oiio:ColorSpace",
                                                   linearspace);
        }
        if (from.empty()) {
            dst.errorfmt("Unknown color space name");
            return false;
        }
        processor
            = colorconfig->createDisplayTransform(display, view,
                                                  colorconfig->resolve(from),
                                                  looks, inverse, key, value);
        if (!processor) {
            if (colorconfig->has_error())
                dst.errorfmt("{}", colorconfig->geterror());
            else
                dst.errorfmt(
                    "Could not construct the color transform (unknown error)");
            return false;
        }
    }

    logtime.stop();  // transition to colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    if (ok) {
        if (inverse)
            dst.specmod().set_colorspace(colorconfig->resolve(from));
        else {
            if (display.empty() || display == "default")
                display = colorconfig->getDefaultDisplayName();
            if (view.empty() || view == "default")
                view = colorconfig->getDefaultViewName(display,
                                                       colorconfig->resolve(
                                                           from));
            dst.specmod().set_colorspace(
                colorconfig->getDisplayViewColorSpaceName(display, view));
        }
    }
    return ok;
}



ImageBuf
ImageBufAlgo::ociodisplay(const ImageBuf& src, string_view display,
                          string_view view, string_view from, string_view looks,
                          bool unpremult, bool inverse, string_view key,
                          string_view value, const ColorConfig* colorconfig,
                          ROI roi, int nthreads)
{
    ImageBuf result;
    bool ok = ociodisplay(result, src, display, view, from, looks, unpremult,
                          inverse, key, value, colorconfig, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::ociodisplay() error");
    return result;
}



bool
ImageBufAlgo::ociofiletransform(ImageBuf& dst, const ImageBuf& src,
                                string_view name, bool unpremult, bool inverse,
                                const ColorConfig* colorconfig, ROI roi,
                                int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::ociofiletransform");
    if (name.empty()) {
        dst.errorfmt("Unknown filetransform name");
        return false;
    }
    ColorProcessorHandle processor;
    {
        if (!colorconfig)
            colorconfig = &ColorConfig::default_colorconfig();
        processor = colorconfig->createFileTransform(name, inverse);
        if (!processor) {
            if (colorconfig->has_error())
                dst.errorfmt("{}", colorconfig->geterror());
            else
                dst.errorfmt(
                    "Could not construct the color transform (unknown error)");
            return false;
        }
    }

    logtime.stop();  // transition to colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    if (ok)
        // If we can parse a color space from the file name, and we're not inverting
        // the transform, then we'll use the color space name from the file.
        // Otherwise, we'll leave `oiio:ColorSpace` alone.
        // TODO: Use OCIO to extract InputDescription and OutputDescription CLF
        // metadata attributes, if present.
        if (!colorconfig->filepathOnlyMatchesDefaultRule(name))
            dst.specmod().set_colorspace(
                colorconfig->getColorSpaceFromFilepath(name));
    return ok;
}



ImageBuf
ImageBufAlgo::ociofiletransform(const ImageBuf& src, string_view name,
                                bool unpremult, bool inverse,
                                const ColorConfig* colorconfig, ROI roi,
                                int nthreads)
{
    ImageBuf result;
    bool ok = ociofiletransform(result, src, name, unpremult, inverse,
                                colorconfig, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::ociofiletransform() error");
    return result;
}



bool
ImageBufAlgo::ocionamedtransform(ImageBuf& dst, const ImageBuf& src,
                                 string_view name, bool unpremult, bool inverse,
                                 string_view key, string_view value,
                                 const ColorConfig* colorconfig, ROI roi,
                                 int nthreads)
{
    OIIO::pvt::LoggedTimer logtime("IBA::ocionamedtransform");
    ColorProcessorHandle processor;
    {
        if (!colorconfig)
            colorconfig = &ColorConfig::default_colorconfig();
        processor = colorconfig->createNamedTransform(name, inverse, key,
                                                      value);
        if (!processor) {
            if (colorconfig->has_error())
                dst.errorfmt("{}", colorconfig->geterror());
            else
                dst.errorfmt(
                    "Could not construct the color transform (unknown error)");
            return false;
        }
    }

    logtime.stop();  // transition to colorconvert
    bool ok = colorconvert(dst, src, processor.get(), unpremult, roi, nthreads);
    return ok;
}



ImageBuf
ImageBufAlgo::ocionamedtransform(const ImageBuf& src, string_view name,
                                 bool unpremult, bool inverse, string_view key,
                                 string_view value,
                                 const ColorConfig* colorconfig, ROI roi,
                                 int nthreads)
{
    ImageBuf result;
    bool ok = ocionamedtransform(result, src, name, unpremult, inverse, key,
                                 value, colorconfig, roi, nthreads);
    if (!ok && !result.has_error())
        result.errorfmt("ImageBufAlgo::ocionamedtransform() error");
    return result;
}



bool
ImageBufAlgo::colorconvert(span<float> color, const ColorProcessor* processor,
                           bool unpremult)
{
    // If the processor is NULL, return false (error)
    if (!processor) {
        return false;
    }

    // If the processor is a no-op, no work needs to be done. Early exit.
    if (processor->isNoOp())
        return true;

    // Load the pixel
    float rgba[4]      = { 0.0f, 0.0f, 0.0f, 0.0f };
    int channelsToCopy = std::min(4, (int)color.size());
    memcpy(rgba, color.data(), channelsToCopy * sizeof(float));

    const float fltmin = std::numeric_limits<float>::min();

    // Optionally unpremult
    if ((channelsToCopy >= 4) && unpremult) {
        float alpha = rgba[3];
        if (alpha > fltmin) {
            rgba[0] /= alpha;
            rgba[1] /= alpha;
            rgba[2] /= alpha;
        }
    }

    // Apply the color transformation
    processor->apply(rgba, 1, 1, 4, sizeof(float), 4 * sizeof(float),
                     4 * sizeof(float));

    // Optionally premult
    if ((channelsToCopy >= 4) && unpremult) {
        float alpha = rgba[3];
        if (alpha > fltmin) {
            rgba[0] *= alpha;
            rgba[1] *= alpha;
            rgba[2] *= alpha;
        }
    }

    // Store the scanline
    memcpy(color.data(), rgba, channelsToCopy * sizeof(float));

    return true;
}



void
ColorConfig::set_colorspace(ImageSpec& spec, string_view colorspace) const
{
    // If we're not changing color space, don't mess with anything
    string_view oldspace = spec.get_string_attribute("oiio:ColorSpace");
    if (oldspace.size() && colorspace.size() && oldspace == colorspace)
        return;

    // Set or clear the main "oiio:ColorSpace" attribute
    if (colorspace.empty()) {
        spec.erase_attribute("oiio:ColorSpace");
    } else {
        spec.attribute("oiio:ColorSpace", colorspace);
    }

    // Clear a bunch of other metadata that might contradict the colorspace,
    // including some format-specific things that we don't want to propagate
    // from input to output if we know that color space transformations have
    // occurred.
    // Only an existing "Exif:ColorSpace" needs the config, to judge sRGB.
    if (spec.find_attribute("Exif:ColorSpace")
        && colorspace != "srgb_rec709_scene"
        && !equivalent(colorspace, "srgb_rec709_scene"))
        spec.erase_attribute("Exif:ColorSpace");
    spec.erase_attribute("tiff:ColorSpace");
    spec.erase_attribute("tiff:PhotometricInterpretation");
    spec.erase_attribute("oiio:Gamma");
}



void
ColorConfig::set_colorspace_rec709_gamma(ImageSpec& spec, float gamma) const
{
    // Round gamma to the nearest hundredth to prevent stupid precision choices
    // and make it easier for apps to make decisions based on known gamma values.
    float g_rounded = std::round(gamma * 100.0f) / 100.0f;
    if (fabsf(g_rounded - 1.0f) <= 0.01f) {
        set_colorspace(spec, "lin_rec709_scene");
    } else if (fabsf(g_rounded - 1.8f) <= 0.01f) {
        set_colorspace(spec, "g18_rec709_scene");
        spec.attribute("oiio:Gamma", 1.8f);
    } else if (fabsf(g_rounded - 2.2f) <= 0.01f) {
        set_colorspace(spec, "g22_rec709_scene");
        spec.attribute("oiio:Gamma", 2.2f);
    } else if (fabsf(g_rounded - 2.4f) <= 0.01f) {
        set_colorspace(spec, "g24_rec709_scene");
        spec.attribute("oiio:Gamma", 2.4f);
    } else {
        set_colorspace(spec,
                       Strutil::fmt::format("g{}_rec709_scene",
                                            std::lround(g_rounded * 10.0f)));
        // Preserve the original gamma value for use in color conversions.
        spec.attribute("oiio:Gamma", gamma);
    }
}


void
set_colorspace(ImageSpec& spec, string_view colorspace)
{
    ColorConfig::default_colorconfig().set_colorspace(spec, colorspace);
}

void
set_colorspace_rec709_gamma(ImageSpec& spec, float gamma)
{
    ColorConfig::default_colorconfig().set_colorspace_rec709_gamma(spec, gamma);
}

bool
is_colorspace_srgb(const ImageSpec& spec, bool default_to_srgb)
{
    string_view colorspace = spec.get_string_attribute("oiio:ColorSpace");
    if (default_to_srgb && colorspace.empty()) {
        return true;
    }

    const ColorConfig& colorconfig(ColorConfig::default_colorconfig());
    string_view interop_id = colorconfig.get_color_interop_id(colorspace);

    return (interop_id == "srgb_rec709_scene"
            || interop_id == "srgb_rec709_display");
}

std::vector<uint8_t>
get_colorspace_icc_profile(const ImageSpec& spec, bool /*from_colorspace*/)
{
    std::vector<uint8_t> icc_profile;
    const ParamValue* p = spec.find_attribute("ICCProfile");
    if (p) {
        cspan<uint8_t> icc_profile_span = p->as_cspan<uint8_t>();
        icc_profile.assign(icc_profile_span.begin(), icc_profile_span.end());
    }
    return icc_profile;
}

cspan<int>
get_colorspace_cicp(const ImageSpec& spec, bool from_colorspace)
{
    const ParamValue* p = spec.find_attribute("CICP",
                                              TypeDesc(TypeDesc::INT, 4));
    if (p)
        return p->as_cspan<int>();
    if (!from_colorspace)
        return cspan<int>();
    const ColorConfig& colorconfig(ColorConfig::default_colorconfig());
    return colorconfig.get_cicp(spec.get_string_attribute("oiio:ColorSpace"));
}

OIIO_NAMESPACE_3_1_END

OIIO_NAMESPACE_BEGIN

// Parse a color space name of the form "g<NN>_rec709_(scene|display)".
static float
rec709_colorspace_gamma(string_view colorspace)
{
    if (!Strutil::parse_prefix(colorspace, "g"))
        return 0.0f;
    int g10 = 0;
    if (!Strutil::parse_int(colorspace, g10) || g10 <= 0)
        return 0.0f;
    if (colorspace != "_rec709_scene" && colorspace != "_rec709_display")
        return 0.0f;
    return float(g10) / 10.0f;
}

float
pvt::get_colorspace_rec709_gamma(const ImageSpec& spec)
{
    const ColorConfig& colorconfig(ColorConfig::default_colorconfig());
    string_view colorspace = spec.get_string_attribute("oiio:ColorSpace");
    string_view interop_id = colorconfig.get_color_interop_id(colorspace);

    // Gamma interop IDs, as well as arbitrary names that do not have an
    // official interop ID as generated by set_colorspace_rec709_gamma().
    const float gamma = rec709_colorspace_gamma(
        interop_id.empty() ? colorspace : interop_id);

    // Backwards compatibility, scene_linear is not necessarily Rec.709
    if (colorconfig.equivalent(colorspace, "linear")
        || colorconfig.equivalent(colorspace, "scene_linear")
        || interop_id == "lin_rec709_scene")
        return 1.0f;
    else if (gamma != 0.0f)
        return gamma;
    // Backwards compatibility, this is DEPRECATED(3.1)
    else if (Strutil::istarts_with(colorspace, "Gamma")) {
        Strutil::parse_word(colorspace);
        float g = Strutil::from_string<float>(colorspace);
        if (g >= 0.01f && g <= 10.0f /* sanity check */)
            return g;
    }

    // Obsolete "oiio:Gamma" attribute for backwards compatibility
    return spec.get_float_attribute("oiio:Gamma", 0.0f);
}

OIIO_NAMESPACE_END
