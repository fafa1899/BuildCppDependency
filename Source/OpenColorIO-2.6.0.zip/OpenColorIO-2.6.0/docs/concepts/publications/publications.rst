..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _publications:

Presentations & Publications
============================

* ASWF Open Source Days 2025 -- Project Update `video <https://youtu.be/w-T64bqFh5E?feature=shared>`_

* Color Interop Forum -- "Color Space Encodings for Texture Assets and CG Rendering" 
  `Recommendation <https://github.com/AcademySoftwareFoundation/ColorInterop/blob/main/Recommendations/01_TextureAssetColorSpaces/TextureAssetColorSpaces.md>`_

* ASWF Open Source Days 2024 -- NanoColor `video <https://youtu.be/ym1kfYmGz-M?feature=shared>`_

* ASWF Open Source Days 2024 -- Project Update `video <https://youtu.be/zizC0ORvwnc?feature=shared>`_

* OCIO honored with the SMPTE Workflow Systems Medal! `article <https://www.aswf.io/blog/opencolorio-receives-smpte-workflow-systems-medal/>`_

* ASWF Open Source Days 2023 `video <https://www.youtube.com/watch?v=y-oq693Wl8g>`_

* OCIO receives the Pipeline Tool award at DigiPro 2022! `video <https://vimeo.com/742052701>`_

* ASWF Open Source Days 2022 `video <https://www.youtube.com/watch?v=WzFlz1HeNdI>`_

* HPA Tech Retreat 2022 "Color Processing with OCIO v2 and the Academy/ASC Common LUT Format"
  `Slides & Tutorial <https://drive.google.com/drive/folders/1ZRTIYE6kFb-7sTUtYIYFNJndhY6tmJee?usp=share_link>`_

* OCIO v2 receives an Engineering Excellence award from the Hollywood Post Alliance! 
  `article <https://www.hollywoodreporter.com/movies/movie-news/hpa-engineering-excellence-award-recipients-announced-1234995410/>`_

* SIGGRAPH 2021 course "Color management with OpenColorIO V2" 
  `video <https://vimeo.com/689093714>`__  `PDF <https://drive.google.com/file/d/1v37Bz7s1wbJNg-ULsBqnGPA9h7pWNfhU/view?usp=share_link>`__  `ACM <https://dl.acm.org/doi/10.1145/3450508.3464600>`_

* ASWF Open Source Days 2021 `video <https://youtu.be/FSzLwSTJjWo>`_

* DigiPro 2020 "The ASWF takes OpenColorIO to the Next Level" `video <https://vimeo.com/458011669>`__  `PDF <https://drive.google.com/file/d/1y_0ZEftivHH0zoKwvKZx3gH_u_cDm1bD/view?usp=sharing>`__  `ACM <https://dl.acm.org/doi/abs/10.1145/3403736.3403942>`_

* ASWF Open Source Days 2020 `video <https://www.youtube.com/watch?v=7e0SSka8Ar8>`_

* ASWF Open Source Days 2019 `video <https://youtu.be/L5dpFtgZuhQ>`_

* `Cinematic Color <http://cinematiccolor.org/>`_
