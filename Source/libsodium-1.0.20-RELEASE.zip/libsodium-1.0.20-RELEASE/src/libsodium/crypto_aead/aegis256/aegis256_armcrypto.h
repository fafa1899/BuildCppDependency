#ifndef aegis256_armcrypto_H
#define aegis256_armcrypto_H

#include "implementations.h"

extern struct aegis256_implementation aegis256_armcrypto_implementation;

#endif