openssl x509 -in ../server.crt -out server.pem -outform PEM
openssl x509 -in ../test-root-ca.crt -out test-root-ca.pem -outform PEM
