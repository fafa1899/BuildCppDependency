Code of Conduct
===============

See [the GEOS Code of Conduct](https://libgeos.org/project/coc/).
