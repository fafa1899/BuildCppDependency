//------------------------------------------------------------------------------
// CHOLMOD/GPU/cholmod_l_gpu.c: int64_t version of cholmod_gpu
//------------------------------------------------------------------------------

// CHOLMOD/GPU Module.  Copyright (C) 2005-2022, Timothy A. Davis
// All Rights Reserved.
// SPDX-License-Identifier: GPL-2.1+

//------------------------------------------------------------------------------

#define CHOLMOD_INT64
#include "cholmod_gpu.c"

