//------------------------------------------------------------------------------
// AMD/Source/amd_l2.c: int64_t version of amd_2
//------------------------------------------------------------------------------

// AMD, Copyright (c) 1996-2022, Timothy A. Davis, Patrick R. Amestoy, and
// Iain S. Duff.  All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------

#define DLONG
#include "amd_2.c"

