function [P, stats] = ccolamdtestmex (A, knobs)				    %#ok
% CCOLAMDTESTMEX test function for ccolamd
% Example:
%   [ P, stats ] = ccolamdtest (A, knobs) ;
% See also ccolamd

% CCOLAMD, Copyright (c) 2005-2022, Univ. of Florida, All Rights Reserved.
% Authors: Timothy A. Davis, Sivasankaran Rajamanickam, and Stefan Larimore.
% SPDX-License-Identifier: BSD-3-clause

error ('ccolamdtestmex mexFunction not found') ;
