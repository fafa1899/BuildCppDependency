function [P, stats] = csymamdtestmex (A, knobs)				    %#ok
% CSYMAMDTESTMEX test function for csymamd
% Example:
%   [ P, stats ] = csymamdtest (A, knobs) ;
% See also csymamd

% CCOLAMD, Copyright (c) 2005-2022, Univ. of Florida, All Rights Reserved.
% Authors: Timothy A. Davis, Sivasankaran Rajamanickam, and Stefan Larimore.
% SPDX-License-Identifier: BSD-3-clause

error ('csymamdtestmex mexFunction not found') ;
