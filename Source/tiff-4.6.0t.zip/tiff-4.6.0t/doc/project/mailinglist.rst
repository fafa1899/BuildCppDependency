Mailing List
============


Overview
--------

The `tiff@lists.osgeo.org <tiff@lists.osgeo.org>`_ mailing list is for users of the LibTIFF software, and
discussion TIFF issues in general.


Subscription
------------

The mailing list managed with the Mailman software, and the web interface for subscribing
and managing your access to the list is at: `<http://lists.osgeo.org/mailman/listinfo/tiff/>`_

Posts to the list are only accepted from members of the list.


Archive
-------

A `Long Term Archive <http://www.awaresystems.be/imaging/tiff/tml.html>`_
including recent messages, and most messages back to 1993,
with search capabilities is available.  This archive has been prepared
and hosted by `AWare Systems <http://www.awaresystems.be>`_.
